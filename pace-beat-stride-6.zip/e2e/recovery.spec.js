/**
 * Stage B Phase 1 — browser regression suite for run recovery (Scenarios A–E)
 * plus explicit regression detectors for the three suspected defects (P-1..P-3).
 *
 * ⚠️ SIMULATION, NOT PRODUCTION EVIDENCE
 * - The suite runs the REAL app (React UI, run tracker, checkpoint logic,
 *   localStorage, reloads, two tabs) against an in-memory FAKE backend
 *   (e2e/fakeBackend.js) served via request interception. Production Base44
 *   servers are never contacted; no real user data or credentials are used.
 * - The fake backend EMULATES the terminal-status conditional write
 *   (filter `status: { $nin: ['completed','abandoned'] }` → updated: 0/1).
 *   This does NOT prove the real backend's atomicity, authentication or RLS —
 *   those were verified separately against live servers (Stage B2/B3 probes).
 * - Test identity: a normal, non-admin "user" whose access exists only inside
 *   the simulator as an active Subscription record. No admin role, no
 *   production grants, no authentication bypass deployable to production.
 *
 * P-1 and P-2 are marked with test.fail(): they currently reproduce KNOWN
 * defects, so their failure is the expected, passing outcome. If a fix lands,
 * Playwright reports them as "unexpectedly passed" — remove test.fail() then.
 */
import { test, expect } from '@playwright/test';
import { backend, handleApiRoute } from './fakeBackend.js';
import { geoStubScript } from './geoStub.js';

// Deterministic clock origin and GPS route: each emit is ~100 m north of the
// previous one, one second of faked clock apart. Distance comes from explicit
// coordinate deltas — never from a stationary location.
const T0 = Date.parse('2026-10-13T09:00:00Z');
const START = { lat: 51.5, lng: -0.12 };
const STEP_DEG = 0.0009; // ≈ 100.07 m
const MIRROR_PREFIX = 'liverun_checkpoint_';

test.describe.configure({ mode: 'serial' });

test.beforeEach(async ({ page }) => {
  backend.reset();
  await page.addInitScript(geoStubScript);
  await page.route('**/api/**', (route) => handleApiRoute(route));
  // External assets are not part of what these tests verify — keep them local.
  await page.route(/fonts\.googleapis\.com|fonts\.gstatic\.com/, (route) =>
    route.fulfill({ status: 200, contentType: 'text/css', body: '' }));
  await page.route(/unsplash\.com|media\.base44\.com|base44\.app/, (route) => route.abort());
});

test.afterEach(async ({}, testInfo) => {
  // Evidence: the exact final state of every simulated record, every API
  // request, checkpoint-sequence history and the P-3 concurrency counters.
  await testInfo.attach('final-store', {
    body: JSON.stringify(backend.snapshot(), null, 2),
    contentType: 'application/json',
  });
});

// ---- helpers ----

async function installClock(page) {
  await page.clock.install({ time: T0 });
}

async function gotoRun(page, id) {
  await page.goto(`/live-run/${id}?access_token=e2e-test-token&app_id=e2e-mock-app`);
}

async function gotoHome(page) {
  await page.goto('/?access_token=e2e-test-token&app_id=e2e-mock-app');
}

async function startRun(page, runId) {
  const start = page.getByRole('button', { name: 'Start Live Run' });
  await expect(start).toBeVisible();
  await start.click();
  await expect.poll(() => backend.run(runId)?.status, { timeout: 20_000 }).toBe('active');
}

/** Advance the faked clock, then emit one GPS fix ~100 m north of the last. */
async function emitStep(page, i, stepMs = 1000) {
  await page.clock.runFor(stepMs);
  await page.evaluate(([lat, lng]) => window.__geo.emit(lat, lng), [START.lat + i * STEP_DEG, START.lng]);
}

/** Emit the same fix to two tabs (shared deterministic GPS feed). */
async function emitStepTo(pages, i, stepMs = 1000) {
  await pages[0].clock.runFor(stepMs); // context clock: shared by both pages
  const pos = [START.lat + i * STEP_DEG, START.lng];
  for (const page of pages) {
    await page.evaluate(([lat, lng]) => window.__geo.emit(lat, lng), pos);
  }
}

/** Read a StatCard/dashboard value ("Distance", "Time", "Elapsed"). */
async function readStat(page, label) {
  return page.evaluate((lbl) => {
    const els = [...document.querySelectorAll('p')];
    const el = els.find((p) => p.textContent.trim() === lbl);
    const value = el?.nextElementSibling?.textContent || el?.previousElementSibling?.textContent;
    return value ? value.trim() : null;
  }, label);
}

const secsOf = (mmss) => {
  const [m, s] = String(mmss).split(':').map(Number);
  return m * 60 + s;
};

async function setupTwoTabs(browser, runId) {
  const context = await browser.newContext();
  await context.addInitScript(geoStubScript);
  await context.clock.install({ time: T0 });
  await context.route('**/api/**', (route) => handleApiRoute(route));
  await context.route(/fonts\.googleapis\.com|fonts\.gstatic\.com/, (route) =>
    route.fulfill({ status: 200, contentType: 'text/css', body: '' }));
  await context.route(/unsplash\.com|media\.base44\.com|base44\.app/, (route) => route.abort());
  const pageA = await context.newPage();
  const pageB = await context.newPage();
  await gotoRun(pageA, runId);
  await gotoRun(pageB, runId);
  await startRun(pageA, runId);
  await startRun(pageB, runId);
  return { context, pageA, pageB };
}

// ---- Scenario A: refresh recovery ----

test('A — refresh recovery: reload restores distance, time and route, then completes', async ({ page }) => {
  await installClock(page);
  const run = backend.seedRun({ target_distance_km: 2, target_time_min: 20, target_pace_per_km: 10 });
  await gotoRun(page, run.id);
  await startRun(page, run.id);

  // ~1.1 km of deterministic GPS; the 1 km crossing confirms a server checkpoint.
  for (let i = 1; i <= 12; i++) await emitStep(page, i);
  await expect.poll(() => backend.run(run.id)?.checkpoint?.seq, { timeout: 20_000 }).toBeGreaterThanOrEqual(1);
  const checkpointBefore = structuredClone(backend.run(run.id).checkpoint);
  expect(checkpointBefore.distance_m).toBeGreaterThan(900);
  const routeBefore = checkpointBefore.route.map((p) => p.t);

  // Refresh mid-run.
  await page.reload();
  await expect(page.getByText('Unfinished run', { exact: true })).toBeVisible();
  // Recovery screen restores distance and pause-excluded elapsed time.
  await expect(page.getByText((checkpointBefore.distance_m / 1000).toFixed(2), { exact: true })).toBeVisible();
  // The chosen checkpoint may be the server copy or the newer local mirror;
  // both restore the same elapsed value within this window.
  await expect(page.getByText(/^0:00:1[0-4]$/, { exact: true })).toBeVisible();

  // Resume: tracking continues from the restored state.
  await page.getByRole('button', { name: 'Resume Run' }).click();
  await expect(page.getByText(`${(checkpointBefore.distance_m / 1000).toFixed(2)} / 2.0 km`)).toBeVisible();
  for (let i = 13; i <= 21; i++) await emitStep(page, i);
  await expect(page.getByText('2.00 / 2.0 km')).toBeVisible();

  await page.getByRole('button', { name: 'End Run' }).click();
  await expect(page.getByRole('heading', { name: 'Run Complete!' })).toBeVisible();
  await expect.poll(() => backend.run(run.id)?.status, { timeout: 20_000 }).toBe('completed');

  // Persisted record vs final UI.
  const saved = backend.run(run.id);
  expect(saved.actual_distance_km).toBeGreaterThan(1.95);
  expect(saved.checkpoint).toBeNull();
  expect(await readStat(page, 'Distance')).toBe(`${saved.actual_distance_km.toFixed(2)} km`);
  expect(await readStat(page, 'Time')).toBe(requireFormat(Math.round(saved.actual_time_min * 60)));

  // Route: strictly increasing timestamps, zero duplicate points; checkpoint
  // route survives the reload boundary and the final route is a superset.
  const ts = saved.route.map((p) => p.t);
  expect(new Set(ts).size).toBe(ts.length);
  for (let i = 1; i < ts.length; i++) expect(ts[i]).toBeGreaterThan(ts[i - 1]);
  for (const t of routeBefore) expect(ts).toContain(t);
});

// ---- Scenario B: pause-excluded timing ----

test('B — paused duration is excluded from elapsed running time', async ({ page }) => {
  await installClock(page);
  const run = backend.seedRun({ target_distance_km: 1, target_time_min: 10, target_pace_per_km: 10 });
  await gotoRun(page, run.id);
  await startRun(page, run.id);

  for (let i = 1; i <= 5; i++) await emitStep(page, i);
  expect(secsOf(await readStat(page, 'Elapsed'))).toBe(5);

  await page.getByRole('button', { name: 'Pause' }).click();
  await expect.poll(() => backend.run(run.id)?.status, { timeout: 20_000 }).toBe('paused');

  // Reliable 60+ second pause: the faked clock is fast-forwarded, no real wait.
  await page.clock.runFor(65_000);

  await page.reload();
  await expect(page.getByText('Unfinished run', { exact: true })).toBeVisible();
  // Recovery screen shows active time only — the ongoing pause is excluded.
  await expect(page.getByText('0:00:05', { exact: true })).toBeVisible();
  await expect(page.getByText('0.40', { exact: true })).toBeVisible();

  await page.getByRole('button', { name: 'Resume Run' }).click();
  await expect(page.getByText('PAUSED', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Resume', exact: true }).click();

  for (let i = 6; i <= 7; i++) await emitStep(page, i);
  const elapsedAfter = secsOf(await readStat(page, 'Elapsed'));
  expect(elapsedAfter).toBeLessThanOrEqual(10); // 5 s pre-pause + ~2 s — the 65 s pause vanished

  await page.getByRole('button', { name: 'End Run' }).click();
  await expect.poll(() => backend.run(run.id)?.status, { timeout: 20_000 }).toBe('completed');
  const saved = backend.run(run.id);
  // A wall-clock implementation would show ~72 s; the pause must be excluded.
  expect(saved.actual_time_min * 60).toBeGreaterThanOrEqual(3);
  expect(saved.actual_time_min * 60).toBeLessThan(20);
  await expect.poll(() => backend.run(run.id)?.checkpoint?.clock?.paused_ms ?? 0, { timeout: 20_000 })
    .toBeGreaterThanOrEqual(55_000);
  expect(await readStat(page, 'Time')).toBe(
    requireFormat(Math.round(saved.actual_time_min * 60)));
});

function requireFormat(seconds) {
  const m = Math.floor(seconds / 60), s = seconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

// ---- Scenario C: offline recovery ----

test('C — offline checkpoints flush on reconnect; no duplicate runs or route points', async ({ page }) => {
  await installClock(page);
  const run = backend.seedRun({ target_distance_km: 2, target_time_min: 20, target_pace_per_km: 10 });
  await gotoRun(page, run.id);
  await startRun(page, run.id);
  for (let i = 1; i <= 3; i++) await emitStep(page, i);
  const before = structuredClone(backend.run(run.id));

  // Go offline: the fake backend aborts every /api call; the page reports offline.
  backend.offline = true;
  await page.evaluate(() => { window.__netOnline = false; window.dispatchEvent(new Event('offline')); });
  const failedRequests = [];
  page.on('requestfailed', (req) => {
    if (req.url().includes('/api/')) failedRequests.push({ url: req.url(), error: req.failure()?.errorText });
  });

  // Keep running offline: local distance keeps growing, nothing lands server-side.
  for (let i = 4; i <= 8; i++) await emitStep(page, i);
  await page.clock.runFor(15_000); // let flush retries fire
  expect(failedRequests.length).toBeGreaterThan(0);
  expect(backend.stats.updateMany.offlineAborts).toBeGreaterThan(0);
  expect(backend.run(run.id).checkpoint).toEqual(before.checkpoint);

  // Restore connectivity.
  backend.offline = false;
  await page.evaluate(() => { window.__netOnline = true; window.dispatchEvent(new Event('online')); });
  const seqBefore = before.checkpoint?.seq ?? 0;
  await expect.poll(() => backend.run(run.id)?.checkpoint?.seq ?? 0, { timeout: 20_000 })
    .toBeGreaterThan(seqBefore);
  const after = backend.run(run.id);
  expect(after.checkpoint.distance_m).toBeGreaterThan(before.checkpoint?.distance_m ?? 0);

  // No duplicate route points; timestamps strictly increasing; exactly one run.
  const ts = after.checkpoint.route.map((p) => p.t);
  expect(new Set(ts).size).toBe(ts.length);
  for (let i = 1; i < ts.length; i++) expect(ts[i]).toBeGreaterThan(ts[i - 1]);
  expect(backend.liveRuns.length).toBe(1);

  // P-3 regression: no overlapping save attempts, no runaway retry volume.
  expect(backend.stats.updateMany.maxConcurrent).toBeLessThanOrEqual(1);
  expect(backend.stats.updateMany.attempts).toBeLessThan(100);
});

// ---- Scenario D: two-tab completion race ----

test('D — two-tab completion race: first finish wins, second tab converges and cannot overwrite', async ({ browser }) => {
  const run = backend.seedRun({ target_distance_km: 2, target_time_min: 20, target_pace_per_km: 10 });
  const { context, pageA, pageB } = await setupTwoTabs(browser, run.id);

  for (let i = 1; i <= 5; i++) await emitStepTo([pageA, pageB], i);

  await pageA.getByRole('button', { name: 'End Run' }).click();
  await expect.poll(() => backend.run(run.id)?.status, { timeout: 20_000 }).toBe('completed');
  const winner = structuredClone(backend.run(run.id));
  expect(winner.actual_distance_km).toBeGreaterThan(0.3);

  // Tab B's next checkpoint write is refused (simulated terminal guard: updated 0).
  await context.clock.runFor(22_000);
  await expect(pageB.getByRole('heading', { name: 'Run Complete!' })).toBeVisible({ timeout: 30_000 });

  // The persisted record is exactly the first finisher's — nothing overwritten.
  const after = backend.run(run.id);
  expect(after.status).toBe('completed');
  expect(after.actual_distance_km).toBe(winner.actual_distance_km);
  expect(after.actual_time_min).toBe(winner.actual_time_min);
  expect(after.actual_pace_per_km).toBe(winner.actual_pace_per_km);
  expect(after.checkpoint).toBeNull();
  expect(backend.liveRuns.length).toBe(1);

  // Tab B offers no resume / restart of the terminal run.
  await expect(pageB.getByRole('button', { name: 'Resume', exact: true })).toHaveCount(0);
  await expect(pageB.getByRole('button', { name: 'Start Live Run' })).toHaveCount(0);
  await context.close();
});

// ---- Scenario E: resume, failed discard and successful discard ----

test('E — unfinished-run prompts, failed discard keeps the run recoverable, successful discard clears prompts', async ({ page }) => {
  await installClock(page);
  const run = backend.seedRun({
    status: 'active',
    start_time: new Date(T0 - 120_000).toISOString(),
    checkpoint: {
      seq: 2,
      at_ms: T0 - 60_000,
      distance_m: 300,
      clock: { start_time_ms: T0 - 120_000, paused_ms: 0, pause_started_at_ms: null },
      splits: [],
      route: [
        { lat: START.lat, lng: START.lng, t: T0 - 118_000 },
        { lat: START.lat + 2 * STEP_DEG, lng: START.lng, t: T0 - 114_000 },
      ],
      last_point: { lat: START.lat + 2 * STEP_DEG, lng: START.lng, t: T0 - 114_000 },
    },
  });

  // Home entry point shows the prompt.
  await gotoHome(page);
  await expect(page.getByText('Unfinished run detected')).toBeVisible();
  await expect(page.getByText(/0\.30 km saved/)).toBeVisible();

  // Live setup entry point shows the same prompt.
  await page.goto('/live-run?access_token=e2e-test-token&app_id=e2e-mock-app');
  await expect(page.getByText('Unfinished run detected')).toBeVisible();

  // The run record itself offers recovery.
  await gotoRun(page, run.id);
  await expect(page.getByText('Unfinished run', { exact: true })).toBeVisible();
  await expect(page.getByText('0.30', { exact: true })).toBeVisible();
  await expect(page.getByText('0:02:00', { exact: true })).toBeVisible();

  // Resume restores the carried distance.
  await page.getByRole('button', { name: 'Resume Run' }).click();
  await expect(page.getByText('0.30 / 2.0 km')).toBeVisible();

  // FAILED discard: simulated 500 → error shown, prompt stays, run untouched.
  backend.failNextDiscard = true;
  await page.getByRole('button', { name: 'Discard', exact: true }).click();
  await page.getByRole('button', { name: 'Confirm Discard' }).click();
  await expect(page.getByText('Could not discard run')).toBeVisible();
  await expect(page.getByText('Unfinished run', { exact: true })).toBeVisible();
  expect(backend.run(run.id).status).toBe('active');

  // SUCCESSFUL discard after the failure.
  await page.getByRole('button', { name: 'Discard', exact: true }).click();
  await page.getByRole('button', { name: 'Confirm Discard' }).click();
  await expect.poll(() => backend.run(run.id)?.status, { timeout: 20_000 }).toBe('abandoned');
  expect(backend.run(run.id).checkpoint).toBeNull();
  expect(backend.liveRuns.length).toBe(1);
  const mirror = await page.evaluate((k) => localStorage.getItem(k), MIRROR_PREFIX + run.id);
  expect(mirror).toBeNull();

  // No stale prompt remains after the successful discard.
  await gotoHome(page);
  await expect(page.getByText('Choose Your Route')).toBeVisible();
  await expect(page.getByText('Unfinished run detected')).toHaveCount(0);
});

// ---- P-1: tracking/timer/music stop when another tab finishes (known defect) ----

test.fail('P-1 regression: the losing tab stops tracking when the run goes terminal', async ({ browser }) => {
  test.info().annotations.push({
    type: 'known-defect',
    description: 'Second tab keeps its GPS watch and elapsed timer after another tab completes the run.',
  });
  const run = backend.seedRun({ target_distance_km: 2, target_time_min: 20, target_pace_per_km: 10 });
  const { context, pageA, pageB } = await setupTwoTabs(browser, run.id);
  for (let i = 1; i <= 5; i++) await emitStepTo([pageA, pageB], i);

  await pageA.getByRole('button', { name: 'End Run' }).click();
  await expect.poll(() => backend.run(run.id)?.status).toBe('completed');
  await context.clock.runFor(22_000);
  await expect(pageB.getByRole('heading', { name: 'Run Complete!' })).toBeVisible({ timeout: 30_000 });

  // The losing tab must have released its GPS watch.
  expect(await pageB.evaluate(() => window.__geo.watcherCount())).toBe(0);
  // ...and its displayed time must have frozen.
  const t1 = await readStat(pageB, 'Time');
  await context.clock.runFor(3_000);
  const t2 = await readStat(pageB, 'Time');
  expect(t2).toBe(t1);
  // Music stop is N/A in this phase: no music service is connected in the simulator.
});

// ---- P-2: completion screen shows persisted final values (known defect) ----

test.fail('P-2 regression: the completion screen shows persisted final values after a reload', async ({ page }) => {
  test.info().annotations.push({
    type: 'known-defect',
    description: 'PostRunSummary renders in-memory tracker values, not the persisted run record; a reload shows zeros.',
  });
  await installClock(page);
  const run = backend.seedRun({ target_distance_km: 0.3, target_time_min: 5, target_pace_per_km: 10 });
  await gotoRun(page, run.id);
  await startRun(page, run.id);
  for (let i = 1; i <= 4; i++) await emitStep(page, i);
  await page.getByRole('button', { name: 'End Run' }).click();
  await expect.poll(() => backend.run(run.id)?.status).toBe('completed');
  const saved = backend.run(run.id);
  expect(saved.actual_distance_km).toBeGreaterThan(0.25);

  await page.reload();
  await expect(page.getByRole('heading', { name: 'Run Complete!' })).toBeVisible();
  expect(await readStat(page, 'Distance')).toBe(`${saved.actual_distance_km.toFixed(2)} km`);
  expect(await readStat(page, 'Time')).toBe(requireFormat(Math.round(saved.actual_time_min * 60)));
});