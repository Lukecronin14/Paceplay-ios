# Stage B Phase 1 — Browser Regression Suite (local, simulated backend)

⚠️ **This is a simulation.** The suite runs the real PacePlay app in a real
Chromium browser, but its data requests are answered by an in-memory **fake
backend inside the test itself**. It never contacts Base44 servers, never uses
real accounts, and proves nothing about production authentication, RLS or
server-side atomicity. Its job is the *browser side* of recovery: GPS-driven
tracking, checkpoints, reloads, offline and two-tab races.

## What you need

- A computer with **Node.js 18 or newer** (Node 20 LTS recommended) and npm.
- The project files on that computer — via **GitHub sync** (2-way repo sync)
  or a **project export**. The `e2e/` folder must be present.

## Setup (first time only)

Open a terminal in the project folder and run:

```bash
npm install
npx playwright install chromium
```

(The second command downloads the test browser, ~120 MB. On macOS you may need
to approve the download; on Linux, `npx playwright install-deps chromium` if
the browser fails to launch.)

## Run the suite

```bash
npm run test:e2e
```

You'll see each test's status in the terminal:

- `✓` passed
- `✗ failed (expected)` for `P-1` / `P-2` — **these two are supposed to fail**
  right now; they are the recorded defect detectors. See below.
- `✗ failed` — a real problem.

## View the evidence report

```bash
npm run test:e2e:report
```

Opens an HTML report with, per test: screenshots, a full trace (network
requests, console output, step-by-step), and a `final-store` attachment — the
exact final state of every simulated record, every API request, checkpoint
sequence numbers and the overlap counters used by the P-3 check.

## The seven tests

| Test | Verifies |
|---|---|
| A | Refresh mid-run restores distance, pause-excluded time and route; resume and completion; final UI matches the saved record; route points strictly increasing, no duplicates |
| B | A 65-second pause (fast-forwarded clock, no real waiting) is fully excluded from elapsed time and the persisted result |
| C | Offline: requests fail (captured), nothing lands server-side, local distance keeps growing; reconnect flushes pending checkpoints; sequence never regresses; no duplicate runs/points |
| D | Two tabs on one run: the first finisher wins; the loser's writes are refused and its view converges on the terminal state with no resume/restart controls |
| E | Prompts on Home and Live setup; run-page recovery; a failed discard keeps the run recoverable; a successful discard clears checkpoint, mirror and all prompts |
| P-1 | **Currently failing (expected defect):** the losing tab keeps its GPS watch and timer after the run goes terminal elsewhere |
| P-2 | **Currently failing (expected defect):** the completion screen shows in-memory (on reload: zeroed) values instead of the persisted record |

Music stop in P-1 is **N/A** in this phase: no music service is connected in
the simulator, so nothing plays.

## Troubleshooting (non-technical)

- **"Port 5179 is already in use"** — close other copies of the dev server, or
  change the port in `e2e/playwright.config.js` and `e2e/vite.e2e.config.js`.
- **"Executable doesn't exist" / browser won't open** — run
  `npx playwright install chromium` again.
- **Browser fails to launch on Linux** — run `npx playwright install-deps chromium`.
- **Tests time out at the start** — the suite starts its own app server; make
  sure no VPN/firewall blocks `127.0.0.1`. Delete `e2e/test-results` and retry.
- **Something in the console about socket.io** — harmless: the app's realtime
  channel has no server here; tests don't rely on it.
- **Want to watch tests live** — `npm run test:e2e:ui` opens Playwright's UI mode.

## What this suite does NOT prove

- Real backend atomicity of the terminal-status guard (emulated here) — that
  was verified with live-server probes (Stage B2/B3) and must be re-confirmed
  end-to-end in a later phase against the real backend with a dedicated test
  account.
- Production authentication, RLS and ownership — never exercised here.
- Physical device behaviour (GPS in the wild, background modes) — separate
  iPhone tests.