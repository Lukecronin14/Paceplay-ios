/**
 * Stage B Phase 1 — deterministic GPS stub injected into every test page.
 *
 * Replaces navigator.geolocation so tests emit exact coordinates at exact
 * (faked-clock) timestamps — no real GPS, no stationary-location distance
 * tricks. The stub also counts active watches: the P-1 regression detector
 * ("tracking stops when another tab finishes the run") reads watcherCount().
 */
export const geoStubScript = `
  window.__geo = {
    watchers: new Map(),
    nextId: 1,
    lastPosition: null,
    watchPosition(onSuccess, onError, options) {
      const id = this.nextId++;
      this.watchers.set(id, onSuccess);
      return id;
    },
    clearWatch(id) { this.watchers.delete(id); },
    watcherCount() { return this.watchers.size; },
    emit(latitude, longitude, accuracy) {
      const position = {
        coords: { latitude, longitude, accuracy: accuracy == null ? 5 : accuracy },
        timestamp: Date.now(),
      };
      this.lastPosition = position;
      for (const cb of [...this.watchers.values()]) {
        try { cb(position); } catch (err) { console.error('geo stub cb error', err); }
      }
    },
  };
  try {
    Object.defineProperty(navigator, 'geolocation', { value: window.__geo, configurable: true });
  } catch (err) { console.error('geo stub install failed', err); }
  // Deterministic online/offline reporting (offline scenarios dispatch real
  // events AND flip this flag; the backend handler aborts /api calls offline).
  try {
    Object.defineProperty(navigator, 'onLine', {
      get() { return window.__netOnline === undefined ? true : !!window.__netOnline; },
      configurable: true,
    });
  } catch (err) { /* non-fatal */ }
`;