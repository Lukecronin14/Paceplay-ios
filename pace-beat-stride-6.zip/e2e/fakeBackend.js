/**
 * Stage B Phase 1 — in-memory FAKE backend for browser E2E tests.
 *
 * ⚠️ SIMULATION — NOT PRODUCTION. This object answers the app's /api calls
 * inside the test browser only (via Playwright request interception). It does
 * NOT implement real authentication, RLS or server-side atomicity: the
 * terminal-status guard below is an emulation of the data-layer filter
 * (`{ id, status: { $nin: ['completed','abandoned'] } }` → updated: 0/1),
 * whose real-backend semantics were verified separately (Stage B2/B3 probes).
 * Nothing in this file runs in the production app; the app's own code is
 * unchanged. No real user data or credentials are ever touched.
 */

const MAX_ROUTE_POINTS = 250;
const nowIso = () => new Date().toISOString();
const genId = () => 'mock' + Math.random().toString(16).slice(2, 12);

class FakeBackend {
  constructor() {
    this.reset();
  }

  reset() {
    // Minimum-privilege test identity: a NORMAL user (never admin) whose
    // access exists only inside this simulator as an "active" Subscription
    // record — exercising the app's real paywall path, not a bypass.
    this.user = {
      id: 'mock-user-1',
      email: 'e2e-runner@example.invalid',
      full_name: 'E2E Runner',
      role: 'user',
      onboarding_completed_at: nowIso(),
    };
    this.subscriptions = [{ id: genId(), status: 'active', created_date: nowIso(), updated_date: nowIso() }];
    this.liveRuns = [];
    this.musicPrefs = [];
    this.runPlans = [];
    this.requests = [];
    this.seqHistory = {};
    this.stats = { updateMany: { attempts: 0, active: 0, maxConcurrent: 0, offlineAborts: 0 } };
    this.offline = false;
    this.failNextDiscard = false;
  }

  seedRun(patch = {}) {
    const run = {
      id: genId(),
      created_by_id: this.user.id,
      created_date: nowIso(),
      updated_date: nowIso(),
      status: 'ready',
      target_distance_km: 2,
      target_time_min: 20,
      target_pace_per_km: 10,
      track_pool: [],
      route: [],
      checkpoint: null,
      ...patch,
    };
    this.liveRuns.push(run);
    return run;
  }

  run(id) {
    return this.liveRuns.find((r) => r.id === id) || null;
  }

  collection(entityName) {
    switch (entityName) {
      case 'LiveRun': return this.liveRuns;
      case 'Subscription': return this.subscriptions;
      case 'MusicPreference': return this.musicPrefs;
      case 'RunPlan': return this.runPlans;
      case 'User': return [this.user];
      default: return this._other ??= [];
    }
  }

  snapshot() {
    return JSON.parse(JSON.stringify({
      user: this.user,
      subscriptions: this.subscriptions,
      liveRuns: this.liveRuns,
      runPlans: this.runPlans,
      requests: this.requests,
      seqHistory: this.seqHistory,
      stats: this.stats,
    }));
  }
}

export const backend = new FakeBackend();

// ---- MongoDB-ish query matcher (the operators the app actually uses) ----

function matchValue(value, cond) {
  if (cond !== null && typeof cond === 'object' && !Array.isArray(cond)) {
    for (const [op, arg] of Object.entries(cond)) {
      switch (op) {
        case '$in': if (!arg.includes(value)) return false; break;
        case '$nin': if (arg.includes(value)) return false; break;
        case '$ne': if (value === arg) return false; break;
        case '$exists': if ((value === undefined) !== !arg) return false; break;
        case '$gte': if (!(value >= arg)) return false; break;
        case '$lte': if (!(value <= arg)) return false; break;
        case '$gt': if (!(value > arg)) return false; break;
        case '$lt': if (!(value < arg)) return false; break;
        case '$regex':
          if (!new RegExp(arg, cond.$options || '').test(String(value ?? ''))) return false;
          break;
        case '$options': break;
        default: return false;
      }
    }
    return true;
  }
  return value === cond;
}

function matchQuery(record, query = {}) {
  return Object.entries(query).every(([key, cond]) => {
    if (key === '$or') return cond.some((q) => matchQuery(record, q));
    return matchValue(record[key], cond);
  });
}

function sortItems(items, sort) {
  if (!sort) return items;
  const desc = sort.startsWith('-');
  const field = desc ? sort.slice(1) : sort;
  return [...items].sort((a, b) => {
    const av = a[field] ?? '', bv = b[field] ?? '';
    const cmp = av < bv ? -1 : av > bv ? 1 : 0;
    return desc ? -cmp : cmp;
  });
}

const fulfill = (route, status, data) =>
  route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(data) });

// ---- Request interception handler (registered on the browser context) ----

export async function handleApiRoute(route) {
  const req = route.request();
  const url = new URL(req.url());
  const path = url.pathname;
  const method = req.method();
  const log = (status) => backend.requests.push({ t: Date.now(), method, path, status });

  // Test control endpoints (direct calls, never from the app)
  if (path.startsWith('/api/__e2e__/')) {
    return fulfill(route, 200, {});
  }

  // App public settings (boot)
  if (path.startsWith('/api/apps/public/prod/public-settings/')) {
    log(200);
    return fulfill(route, 200, { id: url.pathname.split('/').pop(), public_settings: {} });
  }

  // Backend functions: the app only reaches these when music/strava are NOT
  // connected (silent token restore); return empty success — the app treats a
  // missing accessToken as "not connected" and moves on.
  const fnMatch = path.match(/^\/api\/apps\/[^/]+\/functions\/([^/]+)$/);
  if (fnMatch) {
    if (backend.offline) { log('aborted'); return route.abort('internetdisconnected'); }
    log(200);
    return fulfill(route, 200, {});
  }

  // Entities
  const entMatch = path.match(/^\/api\/apps\/[^/]+\/entities\/([^/]+)(\/.*)?$/);
  if (entMatch) {
    const [, entityName, sub = ''] = entMatch;
    const items = backend.collection(entityName);
    log('handling');

    // auth.me / auth.updateMe
    if (entityName === 'User' && sub === '/me') {
      if (backend.offline) { log('aborted'); return route.abort('internetdisconnected'); }
      if (method === 'GET') { log(200); return fulfill(route, 200, backend.user); }
      if (method === 'PUT') {
        Object.assign(backend.user, await req.postDataJSON());
        log(200);
        return fulfill(route, 200, backend.user);
      }
    }

    // Conditional update — the simulated terminal-status guard
    if (sub === '/update-many' && method === 'PATCH') {
      const stats = backend.stats.updateMany;
      stats.attempts += 1;
      stats.active += 1;
      stats.maxConcurrent = Math.max(stats.maxConcurrent, stats.active);
      try {
        // Small real-time window so genuinely overlapping attempts would show
        // up as maxConcurrent > 1 (P-3 detector).
        await new Promise((r) => setTimeout(r, 30));
        if (backend.offline) { stats.offlineAborts += 1; log('aborted'); return route.abort('internetdisconnected'); }
        const { query, data } = await req.postDataJSON();
        if (backend.failNextDiscard && data?.$set?.status === 'abandoned') {
          backend.failNextDiscard = false;
          log(500);
          return fulfill(route, 500, { error: 'simulated failure' });
        }
        const matched = items.filter((r) => matchQuery(r, query || {}));
        for (const record of matched) {
          const patch = data?.$set ?? data ?? {};
          Object.assign(record, patch);
          record.updated_date = nowIso();
          if (patch.checkpoint?.seq != null) {
            (backend.seqHistory[record.id] ??= []).push(patch.checkpoint.seq);
          }
        }
        log(200);
        return fulfill(route, 200, { updated: matched.length });
      } finally {
        stats.active -= 1;
      }
    }

    if (backend.offline) { log('aborted'); return route.abort('internetdisconnected'); }

    // Read: array form (list()/filter() without options)
    if (method === 'GET' && (sub === '' || sub === '/')) {
      const q = url.searchParams.get('q');
      let result = items.filter((r) => matchQuery(r, q ? JSON.parse(q) : {}));
      result = sortItems(result, url.searchParams.get('sort'));
      const skip = Number(url.searchParams.get('skip') || 0);
      const limit = url.searchParams.get('limit');
      if (skip) result = result.slice(skip);
      if (limit) result = result.slice(0, Number(limit));
      log(200);
      return fulfill(route, 200, result);
    }

    // Read: cursor page form (filter(query, options)) and distinct
    if (method === 'GET' && sub === '/v2/list') {
      const q = url.searchParams.get('q');
      let result = items.filter((r) => matchQuery(r, q ? JSON.parse(q) : {}));
      result = sortItems(result, url.searchParams.get('sort'));
      const limit = Number(url.searchParams.get('limit') || 100);
      log(200);
      return fulfill(route, 200, { items: result.slice(0, limit), next_cursor: null, has_more: false });
    }

    if (method === 'GET' && sub === '/count') {
      const q = url.searchParams.get('q');
      log(200);
      return fulfill(route, 200, { count: items.filter((r) => matchQuery(r, q ? JSON.parse(q) : {})).length });
    }

    if (method === 'GET' && sub) {
      const record = items.find((r) => r.id === sub.slice(1));
      log(record ? 200 : 404);
      if (!record) return fulfill(route, 404, { detail: 'Not found' });
      return fulfill(route, 200, record);
    }

    if (method === 'POST' && (sub === '' || sub === '/' || sub === '/bulk')) {
      const payload = sub === '/bulk' ? await req.postDataJSON() : [await req.postDataJSON()];
      const created = payload.map((data) => ({
        id: genId(),
        created_by_id: backend.user.id,
        created_date: nowIso(),
        updated_date: nowIso(),
        ...data,
      }));
      items.push(...created);
      log(200);
      return fulfill(route, 200, sub === '/bulk' ? created : created[0]);
    }

    if (method === 'PUT' && sub) {
      const record = items.find((r) => r.id === sub.slice(1));
      if (!record) { log(404); return fulfill(route, 404, { detail: 'Not found' }); }
      Object.assign(record, await req.postDataJSON());
      record.updated_date = nowIso();
      log(200);
      return fulfill(route, 200, record);
    }

    if (method === 'DELETE' && sub) {
      const id = sub.slice(1);
      const idx = items.findIndex((r) => r.id === id);
      if (idx >= 0) items.splice(idx, 1);
      log(200);
      return fulfill(route, 200, { deleted: idx >= 0 ? 1 : 0 });
    }

    if (method === 'DELETE') {
      const query = await req.postDataJSON();
      const matched = items.filter((r) => matchQuery(r, query || {}));
      for (const record of matched) items.splice(items.indexOf(record), 1);
      log(200);
      return fulfill(route, 200, { deleted: matched.length });
    }

    log(405);
    return fulfill(route, 405, { detail: 'Method not allowed' });
  }

  // Anything else the app asks for: succeed harmlessly.
  log(200);
  return fulfill(route, 200, {});
}