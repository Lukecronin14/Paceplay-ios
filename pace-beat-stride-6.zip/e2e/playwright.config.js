// Stage B Phase 1 — Playwright configuration (test-only; never used by the app build).
// SIMULATION: tests run against a local Vite dev server plus an in-memory
// fake backend (e2e/fakeBackend.js). Production Base44 servers are never contacted.
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: '.',
  testMatch: /recovery\.spec\.js/,
  timeout: 120_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: 1, // the fake backend is process-global; tests must run in order
  retries: 0,
  reporter: [['list'], ['html', { outputFolder: 'report', open: 'never' }]],
  outputDir: 'test-results',
  use: {
    baseURL: 'http://127.0.0.1:5179',
    trace: 'on', // full trace (screenshots, console, network) per test
    screenshot: 'on',
    actionTimeout: 15_000,
    navigationTimeout: 30_000,
  },
  webServer: {
    command: 'npx vite --config e2e/vite.e2e.config.js --port 5179 --strictPort',
    url: 'http://127.0.0.1:5179',
    reuseExistingServer: true,
    timeout: 120_000,
  },
});