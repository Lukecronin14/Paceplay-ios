// Test-only Vite dev server config for the browser E2E suite.
// Deliberately EXCLUDES the @base44/vite-plugin build tooling: the suite
// answers the app's /api calls itself, and `npm run build` never uses this
// config, so nothing here can affect production behaviour.
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export default defineConfig({
  root: projectRoot,
  plugins: [react()],
  resolve: {
    alias: { '@': path.resolve(projectRoot, 'src') },
  },
  define: {
    'import.meta.env.VITE_BASE44_APP_ID': JSON.stringify('e2e-mock-app'),
    'import.meta.env.VITE_BASE44_FUNCTIONS_VERSION': JSON.stringify('v3'),
    'import.meta.env.VITE_BASE44_APP_BASE_URL': JSON.stringify(''),
  },
  server: { port: 5179, strictPort: true },
  logLevel: 'error',
});