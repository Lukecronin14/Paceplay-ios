import { describe, it, expect } from 'vitest';
import { RunClock } from '../src/lib/runClock';

// Batch B1: RunClock state restoration (RunClock.toState / RunClock.fromState).
// All timestamps injected — no real time, no fake timers. T0 is a realistic
// epoch start (mirrors run.start_time, which is always a large epoch value).

const MIN = 60000;
const T0 = 1760000000000;

describe('RunClock restoration', () => {
  it('toState/fromState round-trips a running clock with identical elapsed', () => {
    const c = new RunClock();
    c.start(T0);
    c.pause(T0 + 30 * MIN);
    c.resume(T0 + 45 * MIN);
    const state = c.toState();
    expect(state).toEqual({ start_time_ms: T0, paused_ms: 15 * MIN, pause_started_at_ms: null });

    const restored = RunClock.fromState(state);
    expect(restored.elapsedMs(T0 + 75 * MIN)).toBe(c.elapsedMs(T0 + 75 * MIN));
    expect(restored.elapsedMs(T0 + 75 * MIN)).toBe(60 * MIN);
  });

  it('a restored running clock keeps accumulating wall-clock active time', () => {
    const original = new RunClock();
    original.start(T0 + 100000);
    const restored = RunClock.fromState(original.toState());
    expect(restored.elapsedMs(T0 + 160000)).toBe(60000);
    expect(restored.elapsedMs(T0 + 220000)).toBe(120000);
  });

  it('restoring while paused freezes elapsed and excludes the whole pause', () => {
    const original = new RunClock();
    original.start(T0);
    original.pause(T0 + 10 * MIN);
    const restored = RunClock.fromState(original.toState());

    // Still paused after restore: elapsed frozen at pause time, however long later.
    expect(restored.elapsedMs(T0 + 10 * MIN)).toBe(10 * MIN);
    expect(restored.elapsedMs(T0 + 25 * MIN)).toBe(10 * MIN);

    // Resuming after restore folds in only the pause that actually happened.
    restored.resume(T0 + 25 * MIN);
    expect(restored.elapsedMs(T0 + 40 * MIN)).toBe(25 * MIN); // 40 wall - 15 paused
  });

  it('repeated pause/resume cycles work after restoration', () => {
    const original = new RunClock();
    original.start(T0);
    original.pause(T0 + 10 * MIN);
    original.resume(T0 + 15 * MIN); // 5 min paused
    const restored = RunClock.fromState(original.toState());
    restored.pause(T0 + 30 * MIN);
    restored.resume(T0 + 32 * MIN); // 2 min paused
    restored.pause(T0 + 40 * MIN);
    restored.resume(T0 + 41 * MIN); // 1 min paused
    expect(restored.elapsedMs(T0 + 50 * MIN)).toBe(50 * MIN - 8 * MIN);
  });

  it('pausing a restored clock already in a pause is a no-op (original pause start kept)', () => {
    const original = new RunClock();
    original.start(T0);
    original.pause(T0 + 10 * MIN);
    const restored = RunClock.fromState(original.toState());
    restored.pause(T0 + 20 * MIN); // ignored — pause_started_at_ms preserved
    restored.resume(T0 + 30 * MIN);
    // The original pause spanned T0+10 → T0+30 (20 min): elapsed = 40 wall − 20 paused.
    expect(restored.elapsedMs(T0 + 40 * MIN)).toBe(20 * MIN);
  });

  it('stopping while paused reports active time only (pause in progress excluded)', () => {
    const original = new RunClock();
    original.start(T0);
    original.pause(T0 + 20 * MIN);
    const restored = RunClock.fromState(original.toState());
    // The stop path reads elapsedMs as-is: the in-progress pause is excluded.
    expect(Math.floor(restored.elapsedMs(T0 + 60 * MIN) / 1000)).toBe(20 * 60);
  });

  it('restored clock timestamps before start_time clamp to 0', () => {
    const original = new RunClock();
    original.start(T0 + 10 * MIN);
    original.pause(T0 + 12 * MIN);
    original.resume(T0 + 13 * MIN);
    const restored = RunClock.fromState(original.toState());
    expect(restored.elapsedMs(T0)).toBe(0);
    expect(restored.elapsedMs(T0 + 10 * MIN - 1)).toBe(0);
    // Wall-clock from start = 4 min, minus 1 min paused → 3 min active.
    expect(restored.elapsedMs(T0 + 14 * MIN)).toBe(3 * MIN);
  });

  it('split-style elapsed queries after restoration match the original clock', () => {
    const original = new RunClock();
    original.start(T0);
    original.pause(T0 + 5 * MIN);
    original.resume(T0 + 8 * MIN);
    const restored = RunClock.fromState(original.toState());
    // Mirrors the tracker's split bookkeeping: elapsedMs at km timestamps.
    for (const t of [T0 + 20 * MIN, T0 + 21 * MIN, T0 + 22 * MIN]) {
      expect(restored.elapsedMs(t)).toBe(original.elapsedMs(t));
    }
    expect(restored.elapsedMs(T0 + 22 * MIN)).toBe(19 * MIN);
  });

  describe('invalid or missing state degrades safely', () => {
    it('empty object → unstarted clock', () => {
      const c = RunClock.fromState({});
      expect(c.started).toBe(false);
      expect(c.elapsedMs(T0 + 100000)).toBe(0);
    });

    it('null/undefined → unstarted clock', () => {
      expect(RunClock.fromState(null).started).toBe(false);
      expect(RunClock.fromState(undefined).started).toBe(false);
      expect(RunClock.fromState('garbage').started).toBe(false);
    });

    it('non-finite or non-positive start_time_ms → unstarted clock', () => {
      expect(RunClock.fromState({ start_time_ms: 'abc' }).started).toBe(false);
      expect(RunClock.fromState({ start_time_ms: 0 }).started).toBe(false);
      expect(RunClock.fromState({ start_time_ms: -5 }).started).toBe(false);
      expect(RunClock.fromState({ start_time_ms: NaN }).started).toBe(false);
    });

    it('negative or invalid paused_ms is clamped to 0, not propagated', () => {
      const c = RunClock.fromState({ start_time_ms: T0, paused_ms: -100 });
      expect(c.elapsedMs(T0 + 30000)).toBe(30000);
      const c2 = RunClock.fromState({ start_time_ms: T0, paused_ms: 'x' });
      expect(c2.elapsedMs(T0 + 30000)).toBe(30000);
    });

    it('invalid pause_started_at_ms is ignored (treated as not paused)', () => {
      const c = RunClock.fromState({ start_time_ms: T0, paused_ms: 0, pause_started_at_ms: 'nope' });
      expect(c.elapsedMs(T0 + 30000)).toBe(30000);
      const c2 = RunClock.fromState({ start_time_ms: T0, paused_ms: 0, pause_started_at_ms: T0 - 1000 });
      // Before the start_time is not a valid pause: ignored.
      expect(c2.elapsedMs(T0 + 30000)).toBe(30000);
    });

    it('explicit null pause_started_at_ms round-trips as not paused', () => {
      const c = RunClock.fromState({ start_time_ms: T0, paused_ms: 0, pause_started_at_ms: null });
      expect(c.elapsedMs(T0 + 30000)).toBe(30000);
      expect(c.pauseStartedAtMs).toBeNull();
    });
  });
});