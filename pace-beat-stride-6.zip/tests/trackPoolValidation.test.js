import { describe, it, expect } from 'vitest';
import { validateTrackPoolRequest } from '../base44/shared/trackPool.js';

const liveBody = () => ({
  prompt: 'You are a running DJ AI. Generate a music track pool for a runner.',
  distance_km: 5,
  response_json_schema: { type: 'object', properties: { segments: { type: 'array' } } },
});

const planBody = () => ({
  prompt: 'You are a running coach and music expert. Generate a BPM-matched playlist.',
  distance_km: 21.1,
});

describe('validateTrackPoolRequest', () => {
  it('accepts a valid live-run request', () => {
    expect(validateTrackPoolRequest(liveBody())).toBe(null);
  });

  it('accepts a valid plan request with no schema', () => {
    expect(validateTrackPoolRequest(planBody())).toBe(null);
  });

  it('rejects a missing, non-object or null body', () => {
    expect(validateTrackPoolRequest(undefined)).not.toBe(null);
    expect(validateTrackPoolRequest(null)).not.toBe(null);
    expect(validateTrackPoolRequest('prompt')).not.toBe(null);
  });

  it('rejects a missing or empty prompt', () => {
    const body = liveBody();
    delete body.prompt;
    expect(validateTrackPoolRequest(body)).not.toBe(null);
    expect(validateTrackPoolRequest({ ...planBody(), prompt: '' })).not.toBe(null);
    expect(validateTrackPoolRequest({ ...planBody(), prompt: '   ' })).not.toBe(null);
  });

  it('rejects a non-string prompt', () => {
    expect(validateTrackPoolRequest({ ...planBody(), prompt: 42 })).not.toBe(null);
  });

  it('rejects an oversized prompt', () => {
    const long = 'x'.repeat(30001);
    expect(validateTrackPoolRequest({ ...planBody(), prompt: long })).not.toBe(null);
  });

  it('accepts a prompt at the size limit', () => {
    const max = 'x'.repeat(30000);
    expect(validateTrackPoolRequest({ ...planBody(), prompt: max })).toBe(null);
  });

  it('rejects a missing distance_km', () => {
    const body = liveBody();
    delete body.distance_km;
    expect(validateTrackPoolRequest(body)).not.toBe(null);
  });

  it('rejects zero, negative, non-finite and non-numeric distances', () => {
    expect(validateTrackPoolRequest({ ...planBody(), distance_km: 0 })).not.toBe(null);
    expect(validateTrackPoolRequest({ ...planBody(), distance_km: -5 })).not.toBe(null);
    expect(validateTrackPoolRequest({ ...planBody(), distance_km: NaN })).not.toBe(null);
    expect(validateTrackPoolRequest({ ...planBody(), distance_km: Infinity })).not.toBe(null);
    expect(validateTrackPoolRequest({ ...planBody(), distance_km: '5' })).not.toBe(null);
  });

  it('rejects a distance above the 50 km generation limit', () => {
    expect(validateTrackPoolRequest({ ...planBody(), distance_km: 50.01 })).not.toBe(null);
  });

  it('accepts a distance at the 50 km limit', () => {
    expect(validateTrackPoolRequest({ ...planBody(), distance_km: 50 })).toBe(null);
  });

  it('rejects a non-object response_json_schema', () => {
    expect(validateTrackPoolRequest({ ...liveBody(), response_json_schema: 'segments' })).not.toBe(null);
    expect(validateTrackPoolRequest({ ...liveBody(), response_json_schema: [] })).not.toBe(null);
    expect(validateTrackPoolRequest({ ...liveBody(), response_json_schema: null })).not.toBe(null);
  });
});