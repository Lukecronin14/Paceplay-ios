import { describe, it, expect } from 'vitest';
import {
  planRecovery,
  resumeFromCheckpoint,
  buildCheckpoint,
  nextSeq,
  applyCheckpoint,
  checkpointWriteAllowed,
  mergeRoutePoints,
  RECOVERABLE_STATUSES,
  TERMINAL_STATUSES,
} from '../src/lib/runCheckpoint';
import { RunClock } from '../src/lib/runClock';

// Batch B2: recovery-flow logic — planRecovery decisions, checkpoint/reopen
// round-trips (running and paused), sequence continuation, duplicate/
// out-of-order checkpoints, terminal immutability, and route dedupe across a
// reopen. All timestamps injected (no real time, no storage, no SDK).

const MIN = 60000;
const T0 = 1760000000000;

function makeRun(overrides = {}) {
  return {
    id: 'run1',
    status: 'active',
    start_time: new Date(T0).toISOString(),
    target_distance_km: 5,
    target_time_min: 30,
    ...overrides,
  };
}

// Simulates the tracker's snapshot → checkpoint → reopen → restore → continue
// cycle against the same pure pieces the runtime uses.
function makeClockWithHistory() {
  const c = new RunClock();
  c.start(T0);
  c.pause(T0 + 20 * MIN);
  c.resume(T0 + 25 * MIN); // 5 min paused
  return c;
}

describe('planRecovery', () => {
  const cp = buildCheckpoint({
    seq: 3,
    nowMs: T0 + 12 * MIN,
    clockState: { start_time_ms: T0, paused_ms: 2 * MIN, pause_started_at_ms: null },
    distanceMeters: 2500,
    splits: [{ km: 2, timeSec: 600, splitTimeSec: 600, paceMinPerKm: 10 }],
    route: [{ lat: 51.5, lng: -0.1, t: T0 + 11 * MIN }],
  });

  it('plans an exact checkpoint resume for an active run with a valid checkpoint', () => {
    const plan = planRecovery(makeRun({ checkpoint: cp }), null);
    expect(plan.mode).toBe('checkpoint');
    expect(plan.checkpoint).toEqual(cp);
    expect(plan.adoptedMirror).toBe(false);
  });

  it('adopts a newer local mirror and marks it for server convergence', () => {
    const mirror = buildCheckpoint({
      seq: 2, // lower seq is fine — reconciliation is by at_ms
      nowMs: T0 + 14 * MIN,
      clockState: { start_time_ms: T0, paused_ms: 2 * MIN, pause_started_at_ms: null },
      distanceMeters: 2700,
      splits: [],
      route: [],
    });
    const plan = planRecovery(makeRun({ checkpoint: cp }), JSON.stringify(mirror));
    expect(plan.mode).toBe('checkpoint');
    expect(plan.checkpoint).toEqual(mirror);
    expect(plan.adoptedMirror).toBe(true);
  });

  it('keeps the server checkpoint when the mirror is older or equal (tie → server)', () => {
    const older = { ...cp, seq: 2, at_ms: T0 + 10 * MIN };
    expect(planRecovery(makeRun({ checkpoint: cp }), JSON.stringify(older)).adoptedMirror).toBe(false);
    expect(planRecovery(makeRun({ checkpoint: cp }), JSON.stringify(cp)).adoptedMirror).toBe(false);
  });

  it('ignores a corrupt mirror and recovers from the server checkpoint', () => {
    const plan = planRecovery(makeRun({ checkpoint: cp }), '{not json');
    expect(plan.mode).toBe('checkpoint');
    expect(plan.checkpoint).toEqual(cp);
    expect(plan.adoptedMirror).toBe(false);
  });

  it('plans a legacy approximate resume for a pre-R2 run with a start_time', () => {
    const plan = planRecovery(makeRun(), null);
    expect(plan.mode).toBe('legacy');
    expect(plan.checkpoint).toBeNull();
  });

  it('plans a checkpoint resume for a paused run too', () => {
    const plan = planRecovery(makeRun({ status: 'paused', checkpoint: cp }), null);
    expect(plan.mode).toBe('checkpoint');
  });

  it('is discard-only when there is no checkpoint and no parsable start_time', () => {
    expect(planRecovery(makeRun({ start_time: null }), null).mode).toBe('discard_only');
    expect(planRecovery(makeRun({ start_time: 'garbage' }), null).mode).toBe('discard_only');
    expect(planRecovery(makeRun({ checkpoint: { bad: true }, start_time: null }), null).mode).toBe('discard_only');
  });

  it('returns null for terminal or never-started runs (never recoverable)', () => {
    for (const status of [...TERMINAL_STATUSES, 'ready', undefined]) {
      expect(planRecovery(makeRun({ status, checkpoint: cp }), null)).toBeNull();
    }
    expect(planRecovery(null, null)).toBeNull();
  });

  it('falls back to legacy when the stored checkpoint is invalid but a start_time exists', () => {
    const plan = planRecovery(makeRun({ checkpoint: { seq: 0 } }), null);
    expect(plan.mode).toBe('legacy');
  });
});

describe('simulated checkpoint/reopen — running state', () => {
  it('restores identical elapsed time, carried distance and splits, then continues the sequence', () => {
    const clock = makeClockWithHistory();
    const at = T0 + 30 * MIN;
    const route = Array.from({ length: 10 }, (_, i) => ({ lat: 51.5 + i * 1e-4, lng: -0.1, t: T0 + i * MIN }));
    const cp = buildCheckpoint({
      seq: 4,
      nowMs: at,
      clockState: clock.toState(),
      distanceMeters: 3200,
      splits: [{ km: 3, timeSec: 1500, splitTimeSec: 1500, paceMinPerKm: 10 }],
      route,
    });

    // Reopen: the runtime path is resumeFromCheckpoint → tracker.restore →
    // RunClock.fromState; verify each pure step.
    const payload = resumeFromCheckpoint(cp);
    expect(payload).not.toBeNull();
    const reopened = RunClock.fromState(payload.clockState);

    // Identical elapsed to the uninterrupted instance, at several moments.
    const original = makeClockWithHistory();
    for (const t of [at, at + 5 * MIN, at + 9 * MIN]) {
      expect(reopened.elapsedMs(t)).toBe(original.elapsedMs(t));
    }
    expect(reopened.elapsedMs(at + 5 * MIN)).toBe(30 * MIN); // 35 wall − 5 paused

    // Distance is carried state, never recomputed across the boundary.
    expect(payload.distanceMeters).toBe(3200);
    // Splits carried as-is.
    expect(payload.splits).toEqual([{ km: 3, timeSec: 1500, splitTimeSec: 1500, paceMinPerKm: 10 }]);
    // Route carried (dedupe anchor available).
    expect(payload.lastPoint.t).toBe(route[route.length - 1].t);

    // Post-resume work continues the sequence; only post-resume deltas add.
    const continuedDistance = payload.distanceMeters + 800; // one post-resume delta
    const cp2 = buildCheckpoint({
      seq: nextSeq(cp), // 5
      nowMs: at + 5 * MIN,
      clockState: reopened.toState(),
      distanceMeters: continuedDistance,
      splits: payload.splits,
      route: mergeRoutePoints(payload.route, [{ lat: 51.51, lng: -0.1, t: at + 4 * MIN }]),
    });
    expect(cp2.seq).toBe(5);
    expect(cp2.distance_m).toBe(4000);
    expect(cp2.route.length).toBe(11);
  });

  it('drops duplicate and out-of-order checkpoints; replaying one twice is a no-op', () => {
    const clock = makeClockWithHistory();
    const cp1 = buildCheckpoint({
      seq: 1, nowMs: T0 + 5 * MIN, clockState: clock.toState(), distanceMeters: 800, splits: [], route: [],
    });
    const cp2 = buildCheckpoint({
      seq: 2, nowMs: T0 + 9 * MIN, clockState: clock.toState(), distanceMeters: 1600, splits: [], route: [],
    });
    expect(applyCheckpoint(cp2, cp1)).toEqual(cp2); // stale seq ignored
    expect(applyCheckpoint(cp2, cp2)).toEqual(cp2); // duplicate replay is a no-op
    expect(applyCheckpoint(null, cp2)).toEqual(cp2); // first adoption on reopen
    expect(applyCheckpoint(cp1, cp2)).toEqual(cp2); // newer wins
    expect(applyCheckpoint(cp1, { garbage: true })).toEqual(cp1); // invalid ignored
  });

  it('merging a reopened route with a re-observed point adds no duplicate', () => {
    const route = [{ lat: 1, lng: 1, t: 1000 }, { lat: 2, lng: 2, t: 2000 }];
    // Post-reopen the tracker re-observes the same fix (same t) plus new ones.
    const merged = mergeRoutePoints(route, [
      { lat: 2, lng: 2, t: 2000 },
      { lat: 3, lng: 3, t: 3000 },
    ]);
    expect(merged.map((p) => p.t)).toEqual([1000, 2000, 3000]);
  });
});

describe('simulated checkpoint/reopen — paused state', () => {
  it('restores frozen elapsed while paused and folds the pause correctly on resume', () => {
    const clock = makeClockWithHistory();
    clock.pause(T0 + 28 * MIN); // pause in progress at checkpoint time
    const cp = buildCheckpoint({
      seq: 6,
      nowMs: T0 + 28 * MIN,
      clockState: clock.toState(),
      distanceMeters: 4200,
      splits: [],
      route: [],
    });

    const payload = resumeFromCheckpoint(cp);
    const reopened = RunClock.fromState(payload.clockState);
    // Still paused after reopen: elapsed frozen at pause time however long later.
    expect(reopened.elapsedMs(T0 + 28 * MIN)).toBe(23 * MIN); // 28 wall − 5 paused
    expect(reopened.elapsedMs(T0 + 40 * MIN)).toBe(23 * MIN);
    // User resumes 12 min later: only the pause that actually happened folds in.
    reopened.resume(T0 + 40 * MIN);
    expect(reopened.elapsedMs(T0 + 45 * MIN)).toBe(28 * MIN); // 45 wall − (5 + 12) paused
  });
});

describe('terminal immutability', () => {
  const cp = buildCheckpoint({
    seq: 1, nowMs: T0, clockState: { start_time_ms: T0, paused_ms: 0, pause_started_at_ms: null },
    distanceMeters: 0, splits: [], route: [],
  });

  it('checkpoint writes are not allowed on completed or abandoned runs', () => {
    expect(checkpointWriteAllowed({ status: 'completed' })).toBe(false);
    expect(checkpointWriteAllowed({ status: 'abandoned' })).toBe(false);
    expect(checkpointWriteAllowed({ status: 'active' })).toBe(true);
    expect(checkpointWriteAllowed({ status: 'paused' })).toBe(true);
    expect(checkpointWriteAllowed({ status: 'ready' })).toBe(true);
    expect(checkpointWriteAllowed(null)).toBe(false);
  });

  it('planRecovery never plans recovery onto a terminal run', () => {
    expect(planRecovery(makeRun({ status: 'completed', checkpoint: cp }), JSON.stringify(cp))).toBeNull();
    expect(planRecovery(makeRun({ status: 'abandoned', checkpoint: cp }), null)).toBeNull();
  });

  it('recovery payloads stay valid after a JSON round-trip (server → client)', () => {
    const clock = makeClockWithHistory();
    const cp2 = buildCheckpoint({
      seq: 2, nowMs: T0 + 30 * MIN, clockState: clock.toState(), distanceMeters: 3200, splits: [], route: [],
    });
    const viaJson = JSON.parse(JSON.stringify(cp2));
    const payload = resumeFromCheckpoint(viaJson);
    expect(RunClock.fromState(payload.clockState).elapsedMs(T0 + 35 * MIN)).toBe(30 * MIN);
  });
});