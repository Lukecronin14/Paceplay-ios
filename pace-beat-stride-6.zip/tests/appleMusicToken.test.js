import { describe, it, expect } from 'vitest';
import { generateKeyPairSync } from 'node:crypto';
import { normalizeP8Key, mintDeveloperToken } from '../base44/shared/appleMusicToken';

const NOW = 1760000000000; // fixed epoch ms — deterministic

function makeKey() {
  const { privateKey, publicKey } = generateKeyPairSync('ec', { namedCurve: 'P-256' });
  return {
    pem: privateKey.export({ type: 'pkcs8', format: 'pem' }).toString(),
    publicKey,
  };
}

function b64urlToJson(part) {
  return JSON.parse(Buffer.from(part, 'base64url').toString('utf8'));
}

describe('normalizeP8Key', () => {
  it('strips PEM armor, whitespace and quotes', () => {
    const armored = '-----BEGIN PRIVATE KEY-----\nabc\ndef==\n-----END PRIVATE KEY-----';
    expect(normalizeP8Key(armored)).toBe('abcdef==');
  });

  it('unescapes newlines as stored in the secrets vault', () => {
    const escaped = '-----BEGIN PRIVATE KEY-----\\nabc\\ndef==\\n-----END PRIVATE KEY-----';
    expect(normalizeP8Key(escaped)).toBe('abcdef==');
  });

  it('strips surrounding quotes', () => {
    expect(normalizeP8Key('"abcdef=="')).toBe('abcdef==');
  });
});

describe('mintDeveloperToken', () => {
  it('mints a 3-part ES256 token with the right claims', async () => {
    const { pem } = makeKey();
    const { token, expiresIn } = await mintDeveloperToken(
      { privateKeyPem: pem, keyId: 'KEY123', teamId: 'TEAM9' },
      NOW
    );
    const [h, p, s] = token.split('.');
    expect(h).toBeTruthy();
    expect(p).toBeTruthy();
    expect(s).toBeTruthy();
    expect(b64urlToJson(h)).toEqual({ alg: 'ES256', kid: 'KEY123' });
    const claims = b64urlToJson(p);
    expect(claims.iss).toBe('TEAM9');
    expect(claims.iat).toBe(Math.floor(NOW / 1000));
    expect(claims.exp - claims.iat).toBe(60 * 60 * 24 * 30);
    expect(expiresIn).toBe(60 * 60 * 24 * 30);
  });

  it('produces a signature the matching public key verifies', async () => {
    const { pem, publicKey } = makeKey();
    const { token } = await mintDeveloperToken(
      { privateKeyPem: pem, keyId: 'K', teamId: 'T' },
      NOW
    );
    const [h, p, s] = token.split('.');
    const sig = new Uint8Array(Buffer.from(s, 'base64url'));
    const keyData = publicKey.export({ type: 'spki', format: 'der' });
    const cryptoKey = await crypto.subtle.importKey(
      'spki',
      keyData,
      { name: 'ECDSA', namedCurve: 'P-256' },
      false,
      ['verify']
    );
    const ok = await crypto.subtle.verify(
      { name: 'ECDSA', hash: 'SHA-256' },
      cryptoKey,
      sig,
      new TextEncoder().encode(`${h}.${p}`)
    );
    expect(ok).toBe(true);
  });

  it('rejects garbage or short key material', async () => {
    await expect(
      mintDeveloperToken({ privateKeyPem: 'not-a-key', keyId: 'K', teamId: 'T' }, NOW)
    ).rejects.toThrow('INVALID_KEY');
    await expect(
      mintDeveloperToken({ privateKeyPem: '', keyId: 'K', teamId: 'T' }, NOW)
    ).rejects.toThrow('INVALID_KEY');
  });

  it('accepts an armored key with escaped newlines (the secrets-store shape)', async () => {
    const { pem } = makeKey();
    const escaped = pem.replace(/\n/g, '\\n');
    const { token } = await mintDeveloperToken(
      { privateKeyPem: escaped, keyId: 'K', teamId: 'T' },
      NOW
    );
    expect(token.split('.').length).toBe(3);
  });
});