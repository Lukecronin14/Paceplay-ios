import { describe, it, expect } from 'vitest';
import {
  RECOVERABLE_STATUSES,
  TERMINAL_STATUSES,
  isUnfinishedRun,
  planRecovery,
  applyCheckpoint,
  mergeRoutePoints,
  resumeFromCheckpoint,
  checkpointWriteAllowed,
  parseLocalMirror,
  validateCheckpoint,
} from '../src/lib/runCheckpoint';

// ---- Shared fixtures (Batch B3) ----

const T0 = 1760000000000;
const MIN = 60000;

const mkRoute = (n, startMs = T0) =>
  Array.from({ length: n }, (_, i) => ({ lat: 51.5 + i * 0.001, lng: -0.12, t: startMs + i * 10000 }));

const mkCheckpoint = (seq, atMs, distanceM = 1200, routeLen = 4) => {
  const route = mkRoute(routeLen);
  return {
    seq,
    at_ms: atMs,
    distance_m: distanceM,
    clock: { start_time_ms: T0 - 30 * MIN, paused_ms: 5 * MIN, pause_started_at_ms: null },
    splits: [{ km: 1, timeSec: 360, splitTimeSec: 360, paceMinPerKm: 6 }],
    route,
    last_point: route[route.length - 1],
  };
};

const mirrorRaw = (cp) => JSON.stringify(cp);
const runWith = (status, checkpoint = null, startTime = new Date(T0 - 30 * MIN).toISOString()) => ({
  id: 'r1',
  status,
  checkpoint,
  start_time: startTime,
  target_distance_km: 5,
  target_time_min: 30,
});

// ---- 1. Entry-point detection (shared predicate, all entry points) ----

describe('B3: isUnfinishedRun — entry-point detection', () => {
  it('detects started (active/paused) runs', () => {
    expect(isUnfinishedRun(runWith('active'))).toBe(true);
    expect(isUnfinishedRun(runWith('paused'))).toBe(true);
  });

  it('rejects terminal and never-started runs', () => {
    expect(isUnfinishedRun(runWith('ready'))).toBe(false);
    expect(isUnfinishedRun(runWith('completed'))).toBe(false);
    expect(isUnfinishedRun(runWith('abandoned'))).toBe(false);
    expect(isUnfinishedRun(null)).toBe(false);
    expect(isUnfinishedRun(undefined)).toBe(false);
    expect(isUnfinishedRun({})).toBe(false);
  });

  it('entry-point detection matches the eligibility set planRecovery recovers', () => {
    // Every entry point (Home, Live setup) and the run record itself use the
    // same predicate, so anything a prompt offers is always recoverable.
    for (const status of ['ready', 'active', 'paused', 'completed', 'abandoned']) {
      const run = runWith(status, mkCheckpoint(3, T0 - MIN));
      expect(isUnfinishedRun(run)).toBe(planRecovery(run, mirrorRaw(mkCheckpoint(4, T0))) !== null);
    }
  });
});

// ---- 2. Abandoned runs are never resumable ----

describe('B3: abandoned runs cannot be resumed', () => {
  it('planRecovery returns null for an abandoned run even with a valid checkpoint', () => {
    const run = runWith('abandoned', mkCheckpoint(3, T0 - MIN));
    expect(planRecovery(run, mirrorRaw(mkCheckpoint(4, T0)))).toBeNull();
  });

  it('planRecovery returns null for an abandoned run even with a newer local mirror', () => {
    const run = runWith('abandoned', mkCheckpoint(3, T0 - 2 * MIN));
    expect(planRecovery(run, mirrorRaw(mkCheckpoint(9, T0)))).toBeNull();
  });

  it('an abandoned record rejects checkpoint writes (guard covers it)', () => {
    expect(checkpointWriteAllowed(runWith('abandoned', mkCheckpoint(1, T0)))).toBe(false);
  });

  it("'abandoned' is a terminal status, so the guarded write filter excludes it", () => {
    expect(TERMINAL_STATUSES).toContain('abandoned');
    expect(TERMINAL_STATUSES).toContain('completed');
  });
});

// ---- 3. Offline flush on reconnect / reopen: idempotent, no duplicates ----

describe('B3: offline flush convergence (reconnect + reopen)', () => {
  it('a newer offline mirror wins reconciliation and is flagged for flush', () => {
    const run = runWith('active', mkCheckpoint(3, T0 - 2 * MIN));
    const plan = planRecovery(run, mirrorRaw(mkCheckpoint(4, T0)));
    expect(plan.mode).toBe('checkpoint');
    expect(plan.adoptedMirror).toBe(true);
    expect(plan.checkpoint.seq).toBe(4);
  });

  it('flushing the adopted mirror converges: applying it again is idempotent (no seq regression)', () => {
    const server = mkCheckpoint(3, T0 - 2 * MIN);
    const adopted = mkCheckpoint(4, T0);
    const converged = applyCheckpoint(server, adopted);
    expect(converged).toBe(adopted);
    // The same flush replayed (e.g. reconnect fires twice) changes nothing.
    expect(applyCheckpoint(converged, adopted)).toBe(converged);
    expect(applyCheckpoint(converged, mkCheckpoint(4, T0 + 1000))).toBe(converged); // equal seq ignored
  });

  it('replaying merged route data introduces no duplicate route points', () => {
    const route = mkRoute(5);
    const once = mergeRoutePoints([], route);
    const twice = mergeRoutePoints(once, route);
    expect(twice.length).toBe(once.length);
    expect(new Set(twice.map((p) => p.t)).size).toBe(twice.length);
  });

  it('an adopted mirror restores the exact run state (distance, clock, splits)', () => {
    const cp = mkCheckpoint(4, T0);
    const payload = resumeFromCheckpoint(cp);
    expect(payload.distanceMeters).toBe(1200);
    expect(payload.clockState.start_time_ms).toBe(cp.clock.start_time_ms);
    expect(payload.clockState.paused_ms).toBe(5 * MIN);
    expect(payload.splits).toEqual(cp.splits);
    expect(payload.lastPoint).toEqual(cp.route[cp.route.length - 1]);
  });

  it('a corrupt offline mirror can never poison the flush (server copy survives)', () => {
    const run = runWith('active', mkCheckpoint(3, T0 - MIN));
    const plan = planRecovery(run, '{"seq":4,corrupt');
    expect(plan.mode).toBe('checkpoint');
    expect(plan.adoptedMirror).toBe(false);
    expect(plan.checkpoint.seq).toBe(3);
  });

  it('mirror parse is stable across retries (failed flush does not lose data)', () => {
    const raw = mirrorRaw(mkCheckpoint(4, T0));
    const first = parseLocalMirror(raw);
    const second = parseLocalMirror(raw);
    expect(second).toEqual(first);
    expect(validateCheckpoint(second).valid).toBe(true);
  });
});

// ---- 4. Terminal immutability after completion (reopen / refresh) ----

describe('B3: completed record remains immutable', () => {
  it('planRecovery returns null for a completed run even with stale checkpoint data', () => {
    const run = runWith('completed', mkCheckpoint(5, T0));
    expect(planRecovery(run, mirrorRaw(mkCheckpoint(9, T0)))).toBeNull();
  });

  it('checkpoint and status writes are refused for completed runs', () => {
    const run = runWith('completed', mkCheckpoint(1, T0));
    expect(checkpointWriteAllowed(run)).toBe(false);
    expect(isUnfinishedRun(run)).toBe(false); // entry points never prompt it
  });

  it('the guarded write filter excludes every terminal status', () => {
    for (const status of TERMINAL_STATUSES) {
      expect(checkpointWriteAllowed(runWith(status))).toBe(false);
    }
  });
});

// ---- 5. Discard failure keeps the run recoverable (never silently discarded) ----

describe('B3: failed discard keeps recoverable data intact', () => {
  it('planRecovery is pure: repeated planning after a failed discard yields the same plan', () => {
    const run = runWith('paused', mkCheckpoint(4, T0 - MIN));
    const mirror = mirrorRaw(mkCheckpoint(5, T0));
    const first = planRecovery(run, mirror);
    const second = planRecovery(run, mirror);
    expect(second).toEqual(first);
    expect(first.mode).toBe('checkpoint');
    expect(first.adoptedMirror).toBe(true);
  });

  it('discard eligibility excludes terminal runs — a failed discard cannot loop a terminal record', () => {
    expect(checkpointWriteAllowed(runWith('completed'))).toBe(false);
    expect(checkpointWriteAllowed(runWith('abandoned'))).toBe(false);
    expect(checkpointWriteAllowed(runWith('active'))).toBe(true);
  });
});

// ---- 6. Multiple entry points, one unfinished run, no duplicates ----

describe('B3: multiple entry points, no duplicate runs', () => {
  it('entry-point detection picks at most one unfinished run from a mixed list', () => {
    const mixed = [
      runWith('completed', mkCheckpoint(1, T0)),
      runWith('paused', mkCheckpoint(2, T0 - MIN)),
      runWith('abandoned', null),
      runWith('ready', null),
    ];
    const unfinished = mixed.filter(isUnfinishedRun);
    expect(unfinished.length).toBe(1);
    expect(unfinished[0].status).toBe('paused');
  });

  it('checkpoint validation keeps entry-point data shape-safe before any write', () => {
    expect(validateCheckpoint(mkCheckpoint(4, T0)).valid).toBe(true);
    expect(validateCheckpoint(null).valid).toBe(false);
    expect(validateCheckpoint({ seq: 4 }).valid).toBe(false);
  });
});