import { describe, it, expect } from 'vitest';
import {
  buildDeletionPlan,
  USER_OWNED_ENTITIES,
  USER_FIELDS_TO_CLEAR,
} from '../base44/shared/accountDeletion';

describe('buildDeletionPlan', () => {
  const plan = buildDeletionPlan('user-1');

  it('covers every user-owned entity, including HealthRun', () => {
    const entities = plan.map((s) => s.entity);
    for (const name of USER_OWNED_ENTITIES) {
      expect(entities).toContain(name);
    }
    expect(entities).toContain('HealthRun');
  });

  it('does not touch shared catalog data like ParkRun', () => {
    const entities = plan.map((s) => s.entity);
    expect(entities).not.toContain('ParkRun');
  });

  it('scopes every step to the requesting user only', () => {
    for (const step of plan) {
      const keys = Object.keys(step.filter);
      expect(keys.length).toBe(1);
      const scope = step.filter.created_by_id ?? step.filter.user_id;
      expect(scope).toBe('user-1');
    }
  });

  it('a different user produces a different, isolated plan', () => {
    const other = buildDeletionPlan('user-2');
    for (let i = 0; i < plan.length; i++) {
      const a = plan[i].filter.created_by_id ?? plan[i].filter.user_id;
      const b = other[i].filter.created_by_id ?? other[i].filter.user_id;
      expect(a).toBe('user-1');
      expect(b).toBe('user-2');
      expect(a).not.toBe(b);
    }
  });

  it('IntegrationSecret is scoped by its user_id ownership field', () => {
    const step = plan.find((s) => s.entity === 'IntegrationSecret');
    expect(step.filter).toEqual({ user_id: 'user-1' });
  });

  it('rejects an empty or missing user id', () => {
    expect(() => buildDeletionPlan('')).toThrow();
    expect(() => buildDeletionPlan(null)).toThrow();
  });
});

describe('USER_FIELDS_TO_CLEAR', () => {
  it('clears Spotify, Strava and Apple Music credentials', () => {
    expect(USER_FIELDS_TO_CLEAR.apple_music_token).toBeNull();
    expect(USER_FIELDS_TO_CLEAR.apple_music_connected).toBe(false);
    expect(USER_FIELDS_TO_CLEAR.spotify_token).toBeNull();
    expect(USER_FIELDS_TO_CLEAR.spotify_connected).toBe(false);
    expect(USER_FIELDS_TO_CLEAR.strava_token).toBeNull();
    expect(USER_FIELDS_TO_CLEAR.strava_connected).toBe(false);
  });
});