import { describe, it, expect } from 'vitest';
import { pickSubscriptionRecord, computeEntitlements } from '../src/lib/subscriptionAccess';

const NOW = new Date('2026-10-12T12:00:00Z');
const past = (days) => new Date(NOW.getTime() - days * 86400000).toISOString();
const future = (days) => new Date(NOW.getTime() + days * 86400000).toISOString();

describe('computeEntitlements', () => {
  const withNow = (fn) => {
    const realNow = Date.now;
    Date.now = () => NOW.getTime();
    try {
      fn();
    } finally {
      Date.now = realNow;
    }
  };

  it('a pending checkout must NOT grant premium access', () => {
    withNow(() => {
      const e = computeEntitlements({ status: 'pending' });
      expect(e.isPending).toBe(true);
      expect(e.hasAccess).toBe(false);
    });
  });

  it('a verified active subscription grants access', () => {
    const e = computeEntitlements({ status: 'active' });
    expect(e.hasAccess).toBe(true);
    expect(e.isSubscribed).toBe(true);
  });

  it('a granted free entitlement grants access', () => {
    const e = computeEntitlements({ status: 'free' });
    expect(e.hasAccess).toBe(true);
    expect(e.isFree).toBe(true);
  });

  it('an unexpired trial grants access', () => {
    withNow(() => {
      const e = computeEntitlements({ status: 'trial', trial_end_date: future(10) });
      expect(e.trialActive).toBe(true);
      expect(e.hasAccess).toBe(true);
    });
  });

  it('an expired trial does NOT grant access', () => {
    withNow(() => {
      const e = computeEntitlements({ status: 'trial', trial_end_date: past(2) });
      expect(e.trialActive).toBe(false);
      expect(e.hasAccess).toBe(false);
    });
  });

  it('a trial with missing/invalid dates does NOT grant access (fail closed)', () => {
    withNow(() => {
      expect(computeEntitlements({ status: 'trial' }).hasAccess).toBe(false);
      expect(computeEntitlements({ status: 'trial', trial_end_date: 'not-a-date' }).hasAccess).toBe(false);
    });
  });

  it('canceled and expired accounts do NOT grant access', () => {
    expect(computeEntitlements({ status: 'canceled' }).hasAccess).toBe(false);
    expect(computeEntitlements({ status: 'expired' }).hasAccess).toBe(false);
  });

  it('a previously trialled account that never paid does NOT grant access', () => {
    withNow(() => {
      const e = computeEntitlements({
        status: 'trial',
        trial_start_date: past(40),
        trial_end_date: past(10),
      });
      expect(e.hasAccess).toBe(false);
    });
  });

  it('no record grants nothing', () => {
    expect(computeEntitlements(null).hasAccess).toBe(false);
    expect(computeEntitlements(undefined).hasAccess).toBe(false);
  });
});

describe('pickSubscriptionRecord', () => {
  it('prefers an active record over duplicates', () => {
    const picked = pickSubscriptionRecord([
      { id: 'a', status: 'trial', trial_end_date: future(5) },
      { id: 'b', status: 'active' },
      { id: 'c', status: 'expired' },
    ]);
    expect(picked.id).toBe('b');
  });

  it('prefers any non-trial record over a trial', () => {
    const picked = pickSubscriptionRecord([
      { id: 'a', status: 'trial', trial_end_date: future(5) },
      { id: 'b', status: 'free' },
    ]);
    expect(picked.id).toBe('b');
  });

  it('among duplicate trials, keeps the one ending latest (valid access not revoked)', () => {
    const picked = pickSubscriptionRecord([
      { id: 'old', status: 'trial', trial_end_date: future(2) },
      { id: 'new', status: 'trial', trial_end_date: future(12) },
    ]);
    expect(picked.id).toBe('new');
  });

  it('returns null for no records', () => {
    expect(pickSubscriptionRecord([])).toBeNull();
    expect(pickSubscriptionRecord(null)).toBeNull();
  });
});