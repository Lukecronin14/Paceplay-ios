import { describe, it, expect } from 'vitest';
import {
  pickSubscriptionRecord,
  hasPremiumAccess,
} from '../base44/shared/subscriptionAccess.js';

// Fixed clock so trial-expiry cases are deterministic.
const NOW = new Date('2026-10-13T12:00:00Z');
const days = (n) => new Date(NOW.getTime() + n * 86400000).toISOString();

describe('hasPremiumAccess', () => {
  it('grants access for an active subscription', () => {
    expect(hasPremiumAccess({ status: 'active' }, NOW)).toBe(true);
  });

  it('grants access for a free entitlement', () => {
    expect(hasPremiumAccess({ status: 'free' }, NOW)).toBe(true);
  });

  it('grants access for an unexpired trial', () => {
    expect(hasPremiumAccess({ status: 'trial', trial_end_date: days(5) }, NOW)).toBe(true);
  });

  it('refuses an expired trial', () => {
    expect(hasPremiumAccess({ status: 'trial', trial_end_date: days(-1) }, NOW)).toBe(false);
  });

  it('refuses a trial with no end date', () => {
    expect(hasPremiumAccess({ status: 'trial' }, NOW)).toBe(false);
  });

  it('refuses pending, canceled, expired, missing status and null records', () => {
    expect(hasPremiumAccess({ status: 'pending' }, NOW)).toBe(false);
    expect(hasPremiumAccess({ status: 'canceled' }, NOW)).toBe(false);
    expect(hasPremiumAccess({ status: 'expired' }, NOW)).toBe(false);
    expect(hasPremiumAccess({}, NOW)).toBe(false);
    expect(hasPremiumAccess(null, NOW)).toBe(false);
  });

  it('treats a trial as expired the instant it ends', () => {
    expect(hasPremiumAccess({ status: 'trial', trial_end_date: NOW.toISOString() }, NOW)).toBe(false);
  });
});

describe('pickSubscriptionRecord', () => {
  it('returns null for empty or invalid input', () => {
    expect(pickSubscriptionRecord([])).toBe(null);
    expect(pickSubscriptionRecord(undefined)).toBe(null);
  });

  it('prefers an active record over anything else', () => {
    const picked = pickSubscriptionRecord([
      { status: 'trial', trial_end_date: days(10) },
      { status: 'expired' },
      { status: 'active' },
    ]);
    expect(picked.status).toBe('active');
  });

  it('prefers the latest-ending trial among trials', () => {
    const picked = pickSubscriptionRecord([
      { status: 'trial', trial_end_date: days(3) },
      { status: 'trial', trial_end_date: days(10) },
    ]);
    expect(picked.trial_end_date).toBe(days(10));
  });

  it('returns a non-trial record over trials, and the first record as fallback', () => {
    expect(pickSubscriptionRecord([{ status: 'trial' }, { status: 'canceled' }]).status).toBe('canceled');
    expect(pickSubscriptionRecord([{ status: 'unknown' }, { status: 'unknown' }]).status).toBe('unknown');
  });
});