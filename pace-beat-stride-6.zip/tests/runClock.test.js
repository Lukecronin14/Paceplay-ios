import { describe, it, expect } from 'vitest';
import { RunClock } from '../src/lib/runClock';

describe('RunClock', () => {
  it('a run with no pauses accumulates plain wall-clock time', () => {
    const c = new RunClock();
    c.start(0);
    expect(c.elapsedMs(60000)).toBe(60000);
    expect(c.elapsedMs(125000)).toBe(125000);
  });

  it('before start, elapsed is 0', () => {
    expect(new RunClock().elapsedMs(1000)).toBe(0);
  });

  it('a single pause is excluded from elapsed time', () => {
    const c = new RunClock();
    c.start(0);
    c.pause(60000); // run 60s, then pause
    expect(c.elapsedMs(90000)).toBe(60000); // frozen while paused
    c.resume(120000); // resume after 60s of pausing
    expect(c.elapsedMs(180000)).toBe(120000); // 3 min wall - 1 min paused
  });

  it('elapsed time does not grow while paused', () => {
    const c = new RunClock();
    c.start(0);
    c.pause(30000);
    expect(c.elapsedMs(31000)).toBe(30000);
    expect(c.elapsedMs(120000)).toBe(30000);
  });

  it('multiple pauses are all excluded', () => {
    const c = new RunClock();
    c.start(0);
    c.pause(30000);
    c.resume(45000); // 15s paused
    c.pause(90000);
    c.resume(120000); // 30s paused
    expect(c.elapsedMs(150000)).toBe(105000);
  });

  it('pausing twice without resuming keeps the first pause start', () => {
    const c = new RunClock();
    c.start(0);
    c.pause(10000);
    c.pause(20000); // ignored — already paused
    c.resume(30000); // counts 10s→30s (20s) as paused
    expect(c.elapsedMs(40000)).toBe(20000);
  });

  it('resuming without pausing is a no-op', () => {
    const c = new RunClock();
    c.start(0);
    c.resume(10000);
    expect(c.elapsedMs(60000)).toBe(60000);
  });

  it('ending a run after resuming reports active time only', () => {
    const c = new RunClock();
    c.start(0);
    c.pause(120000);
    c.resume(300000); // 3 min paused
    const finalElapsed = Math.floor(c.elapsedMs(600000) / 1000);
    expect(finalElapsed).toBe(420); // 10 min wall - 3 min paused
  });

  it('timestamps before the start are clamped to 0', () => {
    const c = new RunClock();
    c.start(60000);
    expect(c.elapsedMs(0)).toBe(0);
    expect(c.elapsedMs(59999)).toBe(0);
  });

  it('restarting a run resets accumulated paused time', () => {
    const c = new RunClock();
    c.start(0);
    c.pause(10000);
    c.resume(20000);
    c.start(100000);
    expect(c.elapsedMs(160000)).toBe(60000);
  });
});