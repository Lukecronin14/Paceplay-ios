import { describe, it, expect } from 'vitest';
import {
  RATE_LIMIT_MAX,
  RATE_LIMIT_WINDOW_MS,
  countInWindow,
  acquireMintSlot,
  confirmSlot,
} from '../base44/shared/rateLimit';

const NOW = 1760000000000;

/**
 * In-memory entity that faithfully applies the filter semantics the limiter
 * relies on (equality + $lt/$gte on t), so the tests exercise the real
 * acquire/confirm logic.
 */
function makeMockEntity() {
  let records = [];
  let seq = 0;
  const matches = (r, q) =>
    Object.entries(q).every(([k, v]) => {
      if (v !== null && typeof v === 'object') {
        if ('$lt' in v && !(r[k] < v.$lt)) return false;
        if ('$gte' in v && !(r[k] >= v.$gte)) return false;
        return true;
      }
      return r[k] === v;
    });
  return {
    async count(q) {
      return records.filter((r) => matches(r, q)).length;
    },
    async filter(q) {
      return records.filter((r) => matches(r, q));
    },
    async create(data) {
      const rec = { id: 'r' + seq++, ...data };
      records.push(rec);
      return rec;
    },
    async deleteMany(q) {
      const before = records.length;
      records = records.filter((r) => !matches(r, q));
      return before - records.length;
    },
    records: () => records,
  };
}

/** One full (allowed-path) mint flow against the mock. */
async function mint(entity, now, userId = 'u1', service = 's') {
  const slot = await acquireMintSlot(entity, userId, service, now);
  if (!slot.allowed) return false;
  return confirmSlot(entity, userId, service, slot.slot, now);
}

describe('countInWindow', () => {
  it('counts only hits inside the window boundary (inclusive start)', () => {
    const start = NOW - RATE_LIMIT_WINDOW_MS;
    const hits = [{ t: start }, { t: start - 1 }, { t: NOW }];
    expect(countInWindow(hits, NOW)).toBe(2);
  });
});

describe('rate limit enforcement', () => {
  it('allows up to RATE_LIMIT_MAX and denies the next request', async () => {
    const entity = makeMockEntity();
    for (let i = 0; i < RATE_LIMIT_MAX; i++) {
      expect(await mint(entity, NOW + i)).toBe(true);
    }
    expect(entity.records().length).toBe(RATE_LIMIT_MAX);
    const slot = await acquireMintSlot(entity, 'u1', 's', NOW + RATE_LIMIT_MAX);
    expect(slot.allowed).toBe(false);
  });

  it('repeated requests decrement availability one by one', async () => {
    const entity = makeMockEntity();
    await mint(entity, NOW);
    await mint(entity, NOW);
    await mint(entity, NOW);
    expect(await entity.count({ user_id: 'u1', service: 's', t: { $gte: NOW - RATE_LIMIT_WINDOW_MS } })).toBe(3);
    const slot = await acquireMintSlot(entity, 'u1', 's', NOW);
    expect(slot.allowed).toBe(true);
    expect(await confirmSlot(entity, 'u1', 's', slot.slot, NOW)).toBe(true);
    const next = await acquireMintSlot(entity, 'u1', 's', NOW);
    expect(next.allowed).toBe(true); // 4 < 10 still allowed
  });

  it('window expiry frees slots again', async () => {
    const entity = makeMockEntity();
    for (let i = 0; i < RATE_LIMIT_MAX; i++) await mint(entity, NOW + i);
    expect((await acquireMintSlot(entity, 'u1', 's', NOW + RATE_LIMIT_WINDOW_MS - 1)).allowed).toBe(false);
    // One ms past expiry the oldest slot (t = NOW) leaves the window
    const later = NOW + RATE_LIMIT_WINDOW_MS + 1;
    const slot = await acquireMintSlot(entity, 'u1', 's', later);
    expect(slot.allowed).toBe(true);
    expect(await confirmSlot(entity, 'u1', 's', slot.slot, later)).toBe(true);
    expect(entity.records().length).toBe(RATE_LIMIT_MAX); // pruned + new
  });

  it('users are independent', async () => {
    const entity = makeMockEntity();
    for (let i = 0; i < RATE_LIMIT_MAX; i++) await mint(entity, NOW, 'u1', 's');
    expect((await acquireMintSlot(entity, 'u1', 's', NOW)).allowed).toBe(false);
    expect((await acquireMintSlot(entity, 'u2', 's', NOW)).allowed).toBe(true);
  });

  it('a failed mint (slot never confirmed) does not count', async () => {
    const entity = makeMockEntity();
    const slot = await acquireMintSlot(entity, 'u1', 's', NOW);
    expect(slot.allowed).toBe(true);
    // Token generation fails — confirmSlot is never called, nothing recorded
    expect(entity.records().length).toBe(0);
    for (let i = 0; i < RATE_LIMIT_MAX; i++) {
      expect(await mint(entity, NOW)).toBe(true);
    }
    expect((await acquireMintSlot(entity, 'u1', 's', NOW)).allowed).toBe(false);
  });
});

describe('concurrent calls converge to the cap', () => {
  it('15 parallel mint flows never deliver more than 10 tokens', async () => {
    const entity = makeMockEntity();
    const results = await Promise.all(
      Array.from({ length: 15 }, () => mint(entity, NOW))
    );
    const delivered = results.filter(Boolean).length;
    expect(delivered).toBeLessThanOrEqual(RATE_LIMIT_MAX);
    expect(entity.records().length).toBeLessThanOrEqual(RATE_LIMIT_MAX);
  });

  it('staggered parallel bursts stay capped', async () => {
    const entity = makeMockEntity();
    for (let round = 0; round < 3; round++) {
      await Promise.all(Array.from({ length: 6 }, () => mint(entity, NOW + round)));
    }
    expect(entity.records().filter((r) => r.t < NOW + RATE_LIMIT_WINDOW_MS).length).toBeLessThanOrEqual(
      RATE_LIMIT_MAX
    );
  });
});