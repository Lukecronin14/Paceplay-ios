import { describe, it, expect } from 'vitest';
import {
  haversineDistance,
  formatPace,
  formatTime,
  formatDistance,
  selectTrack,
  pickNextTrack,
  getPaceColor,
} from '@/lib/paceUtils';

describe('haversineDistance', () => {
  it('returns 0 for identical points', () => {
    expect(haversineDistance(51.5, -0.12, 51.5, -0.12)).toBe(0);
  });

  it('matches the known London→Paris great-circle distance (~343.6 km)', () => {
    const d = haversineDistance(51.5074, -0.1278, 48.8566, 2.3522);
    expect(Math.abs(d - 343556)).toBeLessThan(500);
  });
});

describe('formatPace', () => {
  it('formats min/km as M:SS', () => {
    expect(formatPace(5.2)).toBe('5:12');
  });
  it('rounds seconds correctly', () => {
    expect(formatPace(4.983)).toBe('4:59');
  });
  it('shows a dash for missing/invalid pace', () => {
    expect(formatPace(0)).toBe('—');
    expect(formatPace(null)).toBe('—');
  });
});

describe('formatTime', () => {
  it('formats hours', () => {
    expect(formatTime(3661)).toBe('1:01:01');
  });
  it('rounds fractional seconds to whole seconds', () => {
    expect(formatTime(125.6)).toBe('2:06');
  });
  it('formats minutes only', () => {
    expect(formatTime(59)).toBe('0:59');
  });
  it('handles zero', () => {
    expect(formatTime(0)).toBe('0:00');
  });
});

describe('formatDistance', () => {
  it('formats to two decimals', () => {
    expect(formatDistance(5)).toBe('5.00');
  });
});

describe('selectTrack', () => {
  const tracks = [
    { title: 'On', scenario: 'on_pace' },
    { title: 'Behind', scenario: 'behind_pace' },
    { title: 'Ahead', scenario: 'ahead_pace' },
  ];
  const segment = { tracks };

  it('picks behind_pace when the runner is behind', () => {
    expect(selectTrack(segment, 0.2).title).toBe('Behind');
  });
  it('picks ahead_pace when the runner is ahead', () => {
    expect(selectTrack(segment, -0.2).title).toBe('Ahead');
  });
  it('picks on_pace when on pace', () => {
    expect(selectTrack(segment, 0).title).toBe('On');
  });
  it('falls back to the first track when the scenario is missing', () => {
    expect(selectTrack({ tracks: [{ title: 'Only', scenario: 'on_pace' }] }, 0.5).title).toBe('Only');
  });
  it('returns null for an empty segment', () => {
    expect(selectTrack({}, 0)).toBeNull();
  });
});

describe('pickNextTrack', () => {
  const pool = [
    { km: 0, tracks: [
      { title: 'A', artist: 'X', scenario: 'on_pace' },
      { title: 'B', artist: 'X', scenario: 'behind_pace' },
    ] },
    { km: 1, tracks: [
      { title: 'C', artist: 'Y', scenario: 'on_pace' },
    ] },
  ];
  const urisMap = {
    'A|X': 'a', 'B|X': 'b', 'C|Y': 'c',
  };

  it('returns null for an empty pool', () => {
    expect(pickNextTrack([], 0, 0, new Set(), urisMap)).toBeNull();
  });

  it('returns null when nothing is searchable (no uris)', () => {
    expect(pickNextTrack(pool, 0, 0, new Set(), {})).toBeNull();
  });

  it('picks the on-pace track on the current km', () => {
    const pick = pickNextTrack(pool, 0, 0, new Set(), urisMap);
    expect(pick.uri).toBe('a');
    expect(pick.segIndex).toBe(0);
  });

  it('picks the behind-pace track when the runner is behind', () => {
    const pick = pickNextTrack(pool, 0, 0.5, new Set(), urisMap);
    expect(pick.uri).toBe('b');
  });

  it('skips already-played songs and moves to the next segment', () => {
    const pick = pickNextTrack(pool, 0, 0, new Set(['a', 'b']), urisMap);
    expect(pick.uri).toBe('c');
    expect(pick.segIndex).toBe(1);
  });

  it('falls back to a scenario-ranked replay when everything has played', () => {
    const pick = pickNextTrack(pool, 0, 0, new Set(['a', 'b', 'c']), urisMap);
    expect(pick).not.toBeNull();
    expect(pick.uri).toBe('a'); // wish scenario (on_pace) replays first
  });

  it('stays clamped to valid segments for fractional km', () => {
    const pick = pickNextTrack(pool, 1.7, 0, new Set(), urisMap);
    expect(pick.segIndex).toBe(1);
  });
});

describe('getPaceColor', () => {
  it('maps deviations to color classes', () => {
    expect(getPaceColor(0)).toBe('text-primary');
    expect(getPaceColor(-0.3)).toBe('text-primary');
    expect(getPaceColor(0.1)).toBe('text-chart-3');
    expect(getPaceColor(0.2)).toBe('text-destructive');
  });
});