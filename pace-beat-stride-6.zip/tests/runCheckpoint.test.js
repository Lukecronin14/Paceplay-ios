import { describe, it, expect } from 'vitest';
import {
  CHECKPOINT_INTERVAL_MS,
  TERMINAL_STATUSES,
  ACTIVE_STATUSES,
  isTerminalStatus,
  checkpointWriteAllowed,
  validateCheckpoint,
  buildCheckpoint,
  nextSeq,
  applyCheckpoint,
  mergeRoutePoints,
  pickNewerMirror,
  parseLocalMirror,
  resumeFromCheckpoint,
  hasCheckpoint,
  canApproximateResume,
} from '../src/lib/runCheckpoint';

// Batch B1: pure checkpoint logic — no Date.now(), no storage, no SDK.

const route3 = [
  { lat: 51.5, lng: -0.1, t: 1000 },
  { lat: 51.501, lng: -0.1, t: 2000 },
  { lat: 51.502, lng: -0.1, t: 3000 },
];

const T0 = 1760000000000; // realistic epoch start (run.start_time)
const clockState = { start_time_ms: T0, paused_ms: 0, pause_started_at_ms: null };

function validCheckpoint(overrides = {}) {
  return buildCheckpoint({
    seq: 1,
    nowMs: 5000,
    clockState,
    distanceMeters: 1500,
    splits: [{ km: 1, timeSec: 300, splitTimeSec: 300, paceMinPerKm: 5 }],
    route: route3,
    ...overrides,
  });
}

describe('status guards', () => {
  it('terminal statuses are completed and abandoned', () => {
    for (const s of TERMINAL_STATUSES) expect(isTerminalStatus(s)).toBe(true);
    for (const s of ACTIVE_STATUSES) expect(isTerminalStatus(s)).toBe(false);
  });

  it('checkpoint writes are refused for completed and abandoned runs', () => {
    expect(checkpointWriteAllowed({ status: 'active' })).toBe(true);
    expect(checkpointWriteAllowed({ status: 'paused' })).toBe(true);
    expect(checkpointWriteAllowed({ status: 'ready' })).toBe(true);
    expect(checkpointWriteAllowed({ status: 'completed' })).toBe(false);
    expect(checkpointWriteAllowed({ status: 'abandoned' })).toBe(false);
    expect(checkpointWriteAllowed(null)).toBe(false);
  });

  it('the checkpoint interval is the designed 20 s', () => {
    expect(CHECKPOINT_INTERVAL_MS).toBe(20000);
  });
});

describe('buildCheckpoint / validateCheckpoint', () => {
  it('builds a valid checkpoint with last_point from the route tail', () => {
    const cp = validCheckpoint();
    expect(validateCheckpoint(cp)).toEqual({ valid: true, reason: null });
    expect(cp.last_point).toEqual({ lat: 51.502, lng: -0.1, t: 3000 });
    expect(cp.clock).toEqual(clockState);
  });

  it('allows null last_point and empty route (no GPS fix yet)', () => {
    const cp = validCheckpoint({ route: [] });
    expect(cp.last_point).toBeNull();
    expect(validateCheckpoint(cp).valid).toBe(true);
  });

  it('rejects building with invalid input', () => {
    expect(() => validCheckpoint({ seq: 0 })).toThrow();
    expect(() => validCheckpoint({ seq: 1.5 })).toThrow();
    expect(() => validCheckpoint({ nowMs: undefined })).toThrow();
    expect(() => validCheckpoint({ distanceMeters: -1 })).toThrow();
    expect(() => validCheckpoint({ clockState: null })).toThrow();
    expect(() => validCheckpoint({ splits: 'no' })).toThrow();
    expect(() => validCheckpoint({ route: [{ lat: 'x', lng: 0, t: 1 }] })).toThrow();
  });

  it('validates strictly: each malformed field is reported', () => {
    const cases = [
      [null, 'not an object'],
      [{ ...validCheckpoint(), seq: 'x' }, 'invalid seq'],
      [{ ...validCheckpoint(), seq: 0 }, 'invalid seq'],
      [{ ...validCheckpoint(), at_ms: 0 }, 'invalid at_ms'],
      [{ ...validCheckpoint(), at_ms: 'x' }, 'invalid at_ms'],
      [{ ...validCheckpoint(), distance_m: -5 }, 'invalid distance_m'],
      [{ ...validCheckpoint(), clock: null }, 'missing clock'],
      [{ ...validCheckpoint(), clock: { ...clockState, start_time_ms: 0 } }, 'invalid clock.start_time_ms'],
      [{ ...validCheckpoint(), clock: { ...clockState, paused_ms: -1 } }, 'invalid clock.paused_ms'],
      [{ ...validCheckpoint(), clock: { ...clockState, pause_started_at_ms: 'x' } }, 'invalid clock.pause_started_at_ms'],
      [{ ...validCheckpoint(), splits: {} }, 'splits not an array'],
      [{ ...validCheckpoint(), route: 'x' }, 'route not an array'],
      [{ ...validCheckpoint(), route: [{ lat: 1, lng: 2 }] }, 'bad route point'],
      [{ ...validCheckpoint(), last_point: { lat: 1, lng: 2 } }, 'invalid last_point'],
    ];
    for (const [cp, reason] of cases) {
      expect(validateCheckpoint(cp).reason).toBe(reason);
    }
  });

  it('accepts a paused clock state (pause_started_at_ms set)', () => {
    const cp = validCheckpoint({
      clockState: { start_time_ms: T0, paused_ms: 5000, pause_started_at_ms: T0 + 4000 },
    });
    expect(validateCheckpoint(cp).valid).toBe(true);
  });
});

describe('sequence ordering', () => {
  it('nextSeq continues from the current checkpoint', () => {
    expect(nextSeq(null)).toBe(1);
    expect(nextSeq(undefined)).toBe(1);
    expect(nextSeq(validCheckpoint({ seq: 7 }))).toBe(8);
  });

  it('a newer checkpoint replaces the current one', () => {
    const current = validCheckpoint({ seq: 3, nowMs: 5000 });
    const incoming = validCheckpoint({ seq: 4, nowMs: 25000 });
    expect(applyCheckpoint(current, incoming)).toBe(incoming);
  });

  it('an older or equal checkpoint can never overwrite a newer one', () => {
    const current = validCheckpoint({ seq: 5, nowMs: 5000 });
    expect(applyCheckpoint(current, validCheckpoint({ seq: 4, nowMs: 1000 }))).toBe(current);
    expect(applyCheckpoint(current, validCheckpoint({ seq: 5, nowMs: 9000 }))).toBe(current);
  });

  it('an invalid incoming checkpoint is ignored, current kept', () => {
    const current = validCheckpoint({ seq: 2 });
    expect(applyCheckpoint(current, { seq: 99 })).toBe(current);
    expect(applyCheckpoint(null, { seq: 99 })).toBeNull();
  });

  it('adoption chains maintain strict ordering under replay', () => {
    let current = null;
    for (let seq = 1; seq <= 5; seq++) {
      current = applyCheckpoint(current, validCheckpoint({ seq, nowMs: seq * 20000 }));
    }
    expect(current.seq).toBe(5);
    // Replay the whole history in any order — result is unchanged.
    let replayed = null;
    for (const seq of [3, 1, 5, 2, 4]) {
      replayed = applyCheckpoint(replayed, validCheckpoint({ seq, nowMs: seq * 20000 }));
    }
    expect(replayed.seq).toBe(5);
  });
});

describe('route merge (duplicate prevention)', () => {
  it('merges without duplicating shared points', () => {
    const merged = mergeRoutePoints(route3, [
      { lat: 51.502, lng: -0.1, t: 3000 }, // duplicate of the tail
      { lat: 51.503, lng: -0.1, t: 4000 },
      { lat: 51.504, lng: -0.1, t: 5000 },
    ]);
    expect(merged).toHaveLength(5);
    expect(merged.map(p => p.t)).toEqual([1000, 2000, 3000, 4000, 5000]);
  });

  it('replaying the same points twice is a no-op', () => {
    const once = mergeRoutePoints([], route3);
    expect(mergeRoutePoints(once, route3)).toEqual(once);
    expect(mergeRoutePoints(once, route3)).toHaveLength(3);
  });

  it('sorts out-of-order input by timestamp', () => {
    const merged = mergeRoutePoints([route3[2]], [route3[0], route3[1]]);
    expect(merged.map(p => p.t)).toEqual([1000, 2000, 3000]);
  });

  it('caps the merged route at 250 points, keeping the most recent', () => {
    const old = Array.from({ length: 200 }, (_, i) => ({ lat: 1, lng: 2, t: i + 1 }));
    const fresh = Array.from({ length: 100 }, (_, i) => ({ lat: 1, lng: 2, t: 1000 + i + 1 }));
    const merged = mergeRoutePoints(old, fresh);
    expect(merged).toHaveLength(250);
    expect(merged[0].t).toBe(51); // 300 points total → oldest 50 dropped
    expect(merged[249].t).toBe(1100);
  });

  it('ignores malformed points instead of throwing', () => {
    const merged = mergeRoutePoints(route3, [null, { lat: 1 }, { lat: 51.503, lng: -0.1, t: 4000 }]);
    expect(merged).toHaveLength(4);
  });
});

describe('mirror reconciliation', () => {
  it('a newer local mirror wins over the server checkpoint', () => {
    const server = validCheckpoint({ seq: 3, nowMs: 30000 });
    const local = validCheckpoint({ seq: 3, nowMs: 40000 });
    expect(pickNewerMirror(server, local)).toBe(local);
  });

  it('the server checkpoint wins when it is newer', () => {
    const server = validCheckpoint({ seq: 4, nowMs: 40000 });
    const local = validCheckpoint({ seq: 3, nowMs: 30000 });
    expect(pickNewerMirror(server, local)).toBe(server);
  });

  it('a tie resolves to the server (the confirmed copy)', () => {
    const server = validCheckpoint({ seq: 3, nowMs: 30000 });
    const local = validCheckpoint({ seq: 3, nowMs: 30000 });
    expect(pickNewerMirror(server, local)).toBe(server);
  });

  it('an invalid side degrades to the valid one; both invalid → null', () => {
    const server = validCheckpoint();
    expect(pickNewerMirror(server, { garbage: true })).toBe(server);
    expect(pickNewerMirror({ garbage: true }, server)).toBe(server);
    expect(pickNewerMirror(null, null)).toBeNull();
    expect(pickNewerMirror(undefined, {})).toBeNull();
  });
});

describe('local mirror parsing (corruption-safe)', () => {
  it('parses a well-formed mirror string', () => {
    expect(parseLocalMirror(JSON.stringify(validCheckpoint()))).toEqual(validCheckpoint());
  });

  it('returns null for corrupt or impossible input', () => {
    expect(parseLocalMirror(null)).toBeNull();
    expect(parseLocalMirror(undefined)).toBeNull();
    expect(parseLocalMirror('')).toBeNull();
    expect(parseLocalMirror(12345)).toBeNull();
    expect(parseLocalMirror('{not json')).toBeNull();
    expect(parseLocalMirror('{"truncated": ')).toBeNull();
  });

  it('returns null for JSON that does not match the checkpoint schema', () => {
    expect(parseLocalMirror('{"hello":"world"}')).toBeNull();
    expect(parseLocalMirror(JSON.stringify({ ...validCheckpoint(), seq: 'corrupt' }))).toBeNull();
    expect(parseLocalMirror(JSON.stringify([]))).toBeNull();
    expect(parseLocalMirror(JSON.stringify({ ...validCheckpoint(), route: [{ lat: NaN, lng: 0, t: 1 }] }))).toBeNull();
  });
});

describe('recovery payload', () => {
  it('extracts the full resume state from a valid checkpoint', () => {
    const cp = validCheckpoint({
      clockState: { start_time_ms: T0 + 1000, paused_ms: 2000, pause_started_at_ms: null },
    });
    const r = resumeFromCheckpoint(cp);
    expect(r.seq).toBe(1);
    expect(r.clockState).toEqual({ start_time_ms: T0 + 1000, paused_ms: 2000, pause_started_at_ms: null });
    expect(r.distanceMeters).toBe(1500);
    expect(r.splits).toHaveLength(1);
    expect(r.route).toEqual(route3);
    expect(r.lastPoint).toEqual({ lat: 51.502, lng: -0.1, t: 3000 });
  });

  it('returns null for an invalid checkpoint (caller falls back to the legacy path)', () => {
    expect(resumeFromCheckpoint(null)).toBeNull();
    expect(resumeFromCheckpoint({ seq: 1 })).toBeNull();
    expect(resumeFromCheckpoint({ garbage: true })).toBeNull();
  });
});

describe('legacy run compatibility (pre-R2 records)', () => {
  it('hasCheckpoint is false when no usable checkpoint exists', () => {
    expect(hasCheckpoint(null)).toBe(false);
    expect(hasCheckpoint({})).toBe(false);
    expect(hasCheckpoint({ status: 'active' })).toBe(false);
    expect(hasCheckpoint({ status: 'active', checkpoint: undefined })).toBe(false);
    expect(hasCheckpoint({ status: 'active', checkpoint: { seq: 1 } })).toBe(false);
    expect(hasCheckpoint({ status: 'active', checkpoint: validCheckpoint() })).toBe(true);
  });

  it('canApproximateResume is true only for an unfinished legacy run with a start_time', () => {
    expect(canApproximateResume({ status: 'active', start_time: '2026-10-13T08:00:00.000Z' })).toBe(true);
    expect(canApproximateResume({ status: 'paused', start_time: '2026-10-13T08:00:00.000Z' })).toBe(true);
    expect(canApproximateResume({ status: 'ready', start_time: '2026-10-13T08:00:00.000Z' })).toBe(false);
    expect(canApproximateResume({ status: 'completed', start_time: '2026-10-13T08:00:00.000Z' })).toBe(false);
    expect(canApproximateResume({ status: 'abandoned', start_time: '2026-10-13T08:00:00.000Z' })).toBe(false);
  });

  it('canApproximateResume is false without a parsable start_time', () => {
    expect(canApproximateResume({ status: 'active' })).toBe(false);
    expect(canApproximateResume({ status: 'active', start_time: '' })).toBe(false);
    expect(canApproximateResume({ status: 'active', start_time: 'not-a-date' })).toBe(false);
    expect(canApproximateResume(null)).toBe(false);
  });
});