import { describe, it, expect } from 'vitest';
import { hasPriorTrial, trialEligibility } from '../base44/shared/trialEligibility.js';

const trialing = {
  status: 'trial',
  trial_start_date: '2026-10-01T00:00:00.000Z',
  trial_end_date: '2026-10-31T00:00:00.000Z',
};

describe('trialEligibility', () => {
  it('a user with no subscription record is eligible', () => {
    expect(trialEligibility([])).toEqual({ eligible: true });
  });

  it('a missing/null subscription list is handled safely as eligible', () => {
    expect(trialEligibility(undefined)).toEqual({ eligible: true });
    expect(trialEligibility(null)).toEqual({ eligible: true });
    expect(hasPriorTrial([null, undefined])).toBe(false);
  });

  it('an active trial is not eligible', () => {
    expect(trialEligibility([trialing]).eligible).toBe(false);
  });

  it('a trial that converted to a paid subscription is not eligible (dates persist)', () => {
    const converted = { status: 'active', subscription_id: 'wix-123', ...trialing };
    expect(trialEligibility([converted]).eligible).toBe(false);
  });

  it('a canceled or expired trial is not eligible', () => {
    expect(trialEligibility([{ status: 'canceled', ...trialing }]).eligible).toBe(false);
    expect(trialEligibility([{ status: 'expired', ...trialing }]).eligible).toBe(false);
  });

  it('inconsistent data (status trial, no dates) fails closed as not eligible', () => {
    expect(trialEligibility([{ status: 'trial' }]).eligible).toBe(false);
  });

  it('trial dates without a trial status still count as a prior trial', () => {
    expect(trialEligibility([{ status: 'active', trial_start_date: '2026-09-01T00:00:00.000Z' }]).eligible).toBe(false);
  });

  it('a free-code redemption without trial dates stays eligible', () => {
    expect(trialEligibility([{ status: 'free' }]).eligible).toBe(true);
  });

  it('a paying subscription without trial dates stays eligible', () => {
    expect(trialEligibility([{ status: 'active', subscription_id: 'wix-9' }]).eligible).toBe(true);
  });

  it('any prior trial among multiple records blocks redemption', () => {
    expect(trialEligibility([{ status: 'free' }, trialing]).eligible).toBe(false);
    expect(trialEligibility([trialing, { status: 'free' }]).eligible).toBe(false);
  });
});