import { describe, it, expect, afterEach } from 'vitest';
import {
  KM_PER_MILE,
  getPreferredUnits,
  setPreferredUnits,
  isImperial,
  displayUnit,
  kmToDisplay,
  displayToKm,
  formatDisplayPace,
  formatDisplayDistance,
} from '@/lib/units';

// In-memory localStorage stand-in (units.js only touches it inside functions).
const store = new Map();
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
};

afterEach(() => {
  store.clear();
});

describe('units', () => {
  it('defaults to metric', () => {
    expect(getPreferredUnits()).toBe('metric');
    expect(isImperial()).toBe(false);
    expect(displayUnit()).toBe('km');
  });

  it('switches to imperial and back', () => {
    setPreferredUnits('imperial');
    expect(isImperial()).toBe(true);
    expect(displayUnit()).toBe('mi');
    setPreferredUnits('metric');
    expect(displayUnit()).toBe('km');
  });

  it('uses the exact mile conversion factor', () => {
    setPreferredUnits('imperial');
    expect(KM_PER_MILE).toBeCloseTo(1.609344, 6);
    expect(kmToDisplay(3.218688)).toBeCloseTo(2, 6);
    expect(displayToKm(1)).toBeCloseTo(1.609344, 6);
    setPreferredUnits('metric');
  });

  it('round-trips through conversion', () => {
    setPreferredUnits('imperial');
    expect(displayToKm(kmToDisplay(10.5))).toBeCloseTo(10.5, 6);
    setPreferredUnits('metric');
    expect(displayToKm(kmToDisplay(10.5))).toBeCloseTo(10.5, 6);
  });

  it('formats metric pace as M:SS', () => {
    expect(formatDisplayPace(5.2)).toBe('5:12');
  });

  it('handles the 60-second rollover in imperial pace', () => {
    // 3.7275 min/km * 1.609344 = 5.9988... → 5:60 must become 6:00
    setPreferredUnits('imperial');
    expect(formatDisplayPace(3.7275)).toBe('6:00');
    setPreferredUnits('metric');
  });

  it('shows a dash for missing pace', () => {
    expect(formatDisplayPace(0)).toBe('—');
  });

  it('formats distance in the preferred unit', () => {
    expect(formatDisplayDistance(5)).toBe('5.00');
    setPreferredUnits('imperial');
    expect(formatDisplayDistance(5, 1)).toBe('3.1');
    setPreferredUnits('metric');
  });
});