import { describe, it, expect } from 'vitest';
import { decodePolyline } from '@/lib/decodePolyline';

describe('decodePolyline', () => {
  it('decodes the standard Google example polyline', () => {
    // Reference vector from Google's polyline encoding docs.
    const coords = decodePolyline('_p~iF~ps|U_ulLnnqC_mqNvxq`@');
    expect(coords.length).toBe(3);
    expect(coords[0][0]).toBeCloseTo(38.5, 4);
    expect(coords[0][1]).toBeCloseTo(-120.2, 4);
    expect(coords[1][0]).toBeCloseTo(40.7, 4);
    expect(coords[1][1]).toBeCloseTo(-120.95, 4);
    expect(coords[2][0]).toBeCloseTo(43.252, 4);
    expect(coords[2][1]).toBeCloseTo(-126.453, 4);
  });

  it('returns an empty array for empty/null input', () => {
    expect(decodePolyline('')).toEqual([]);
    expect(decodePolyline(null)).toEqual([]);
  });

  it('decodes a single point without crashing', () => {
    // "_p~iF~ps|U" encodes (38.5, -120.2) alone (Google's first-point example).
    const coords = decodePolyline('_p~iF~ps|U');
    expect(coords.length).toBe(1);
    expect(coords[0][0]).toBeCloseTo(38.5, 4);
    expect(coords[0][1]).toBeCloseTo(-120.2, 4);
  });
});