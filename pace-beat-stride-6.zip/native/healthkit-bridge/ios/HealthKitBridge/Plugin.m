#import <Foundation/Foundation.h>
#import <Capacitor/Capacitor.h>
#import "Plugin.h"

CAP_PLUGIN(HealthKitBridgePlugin, "HealthKitBridge",
    CAP_PLUGIN_METHOD(requestReadAuth, CAPReturnPromise);
    CAP_PLUGIN_METHOD(fetchRecentWorkouts, CAPReturnPromise);
    CAP_PLUGIN_METHOD(fetchWorkoutRoute, CAPReturnPromise);
)