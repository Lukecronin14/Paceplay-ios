#import <Capacitor/Capacitor.h>

@interface HealthKitBridgePlugin : CAPPlugin
- (void)requestReadAuth:(CAPPluginCall *)call;
- (void)fetchRecentWorkouts:(CAPPluginCall *)call;
- (void)fetchWorkoutRoute:(CAPPluginCall *)call;
@end