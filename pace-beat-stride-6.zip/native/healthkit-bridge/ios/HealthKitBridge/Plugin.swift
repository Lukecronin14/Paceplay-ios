import Foundation
import Capacitor
import HealthKit

/**
 * Read-only Apple Health access for PacePlay.
 *
 * JS contract (consumed by src/lib/healthKit.js via
 * window.Capacitor.Plugins.HealthKitBridge):
 *   requestReadAuth()      -> { granted: Bool }
 *   fetchRecentWorkouts({ limit }) -> { workouts: [{ uuid, start_time(ms),
 *       end_time(ms), duration_sec, distance_km, avg_hr?, source }] }
 *   fetchWorkoutRoute({ workout_uuid }) -> { route: [{ lat, lng, ele, t, spd }] }
 *
 * PacePlay never writes to Apple Health: requestAuthorization is called with
 * `toShare: nil`, so the write permission is never requested. The app target
 * must carry the HealthKit entitlement and both usage descriptions (see
 * native/patch-info-plist.sh).
 */
@objc(HealthKitBridgePlugin)
public class HealthKitBridgePlugin: CAPPlugin {

    private let store = HKHealthStore()

    private var readTypes: Set<HKObjectType> {
        var types: Set<HKObjectType> = [HKObjectType.workoutType()]
        if let distance = HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning) {
            types.insert(distance)
        }
        if let heartRate = HKQuantityType.quantityType(forIdentifier: .heartRate) {
            types.insert(heartRate)
        }
        if let route = HKSeriesType.workoutRoute() {
            types.insert(route)
        }
        return types
    }

    @objc func requestReadAuth(_ call: CAPPluginCall) {
        guard HKHealthStore.isHealthDataAvailable() else {
            call.reject("HealthKit is not available on this device")
            return
        }
        store.requestAuthorization(toShare: nil, read: readTypes) { granted, error in
            if let error = error {
                call.reject(error.localizedDescription)
            } else {
                call.resolve(["granted": granted])
            }
        }
    }

    @objc func fetchRecentWorkouts(_ call: CAPPluginCall) {
        guard HKHealthStore.isHealthDataAvailable() else {
            call.reject("HealthKit is not available on this device")
            return
        }
        let limit = call.getInt("limit") ?? 25
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)
        let query = HKSampleQuery(sampleType: HKObjectType.workoutType(),
                                  predicate: nil,
                                  limit: limit,
                                  sortDescriptors: [sort]) { _, samples, error in
            if let error = error {
                call.reject(error.localizedDescription)
                return
            }
            let workouts = (samples as? [HKWorkout]) ?? []
            let group = DispatchGroup()
            let lock = NSLock()
            var results: [[String: Any]] = []

            for workout in workouts {
                group.enter()
                self.averageHeartRate(for: workout) { avgHr in
                    var dict: [String: Any] = [
                        "uuid": workout.uuid.uuidString,
                        "start_time": Int64(workout.startDate.timeIntervalSince1970 * 1000),
                        "end_time": Int64(workout.endDate.timeIntervalSince1970 * 1000),
                        "duration_sec": Int(workout.duration),
                        "distance_km": workout.totalDistance?.doubleValue(for: HKUnit(from: "km")) ?? 0,
                        "source": workout.sourceRevision.source.name,
                    ]
                    if let avgHr = avgHr {
                        dict["avg_hr"] = avgHr
                    }
                    lock.lock()
                    results.append(dict)
                    lock.unlock()
                    group.leave()
                }
            }
            group.notify(queue: .main) {
                call.resolve(["workouts": results])
            }
        }
        store.execute(query)
    }

    @objc func fetchWorkoutRoute(_ call: CAPPluginCall) {
        guard HKHealthStore.isHealthDataAvailable() else {
            call.reject("HealthKit is not available on this device")
            return
        }
        guard let uuidString = call.getString("workout_uuid"),
              let uuid = UUID(uuidString: uuidString) else {
            call.reject("workout_uuid is required")
            return
        }
        guard let routeType = HKSeriesType.workoutRoute() else {
            call.reject("Workout routes are not available")
            return
        }
        let predicate = HKQuery.predicateForObject(withUUID: uuid)
        let query = HKObjectQuery(objectType: routeType, predicate: predicate) { _, objects, _ in
            guard let route = (objects as? [HKWorkoutRoute])?.first else {
                call.resolve(["route": []])
                return
            }
            var points: [[String: Any]] = []
            let routeQuery = HKWorkoutRouteQuery(route: route) { _, locations, done, error in
                if let error = error {
                    call.reject(error.localizedDescription)
                    return
                }
                for location in locations {
                    points.append([
                        "lat": location.coordinate.latitude,
                        "lng": location.coordinate.longitude,
                        "ele": location.altitude,
                        "t": Int64(location.timestamp.timeIntervalSince1970 * 1000),
                        "spd": location.speed,
                    ])
                }
                if done {
                    call.resolve(["route": points])
                }
            }
            self.store.execute(routeQuery)
        }
        store.execute(query)
    }

    private func averageHeartRate(for workout: HKWorkout, completion: @escaping (Double?) -> Void) {
        guard let heartRate = HKQuantityType.quantityType(forIdentifier: .heartRate) else {
            completion(nil)
            return
        }
        let predicate = HKQuery.predicateForSamples(withStart: workout.startDate, end: workout.endDate)
        let query = HKStatisticsCollectionQuery(quantityType: heartRate,
                                                quantitySamplePredicate: predicate,
                                                options: .discreteAverage,
                                                anchorDate: workout.startDate,
                                                intervalComponents: DateComponents(day: 1))
        query.initialResultsHandler = { _, statistics, _ in
            var average: Double?
            statistics?.statistics().forEach { stats in
                if let mean = stats.averageQuantity() {
                    average = mean.doubleValue(for: HKUnit.count().unitDivided(by: .minute()))
                }
            }
            completion(average)
        }
        store.execute(query)
    }
}