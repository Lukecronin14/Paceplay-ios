Pod::Spec.new do |s|
  s.name = 'HealthKitBridge'
  s.module_name = 'HealthKitBridge'
  s.version = '0.1.0'
  s.summary = 'Read-only Apple Health access for PacePlay: workouts, heart rate and routes'
  s.homepage = 'https://pace-beat-stride.base44.app'
  s.author = 'PacePlay'
  s.license = 'MIT'
  s.source = { :path => '.' }
  s.ios.deployment_target = '13.0'
  s.swift_version = '5.1'
  s.source_files = 'HealthKitBridge/**/*.{swift,h,m}'
  s.frameworks = 'HealthKit'
  s.dependency 'Capacitor'
end