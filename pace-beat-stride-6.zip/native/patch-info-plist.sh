#!/bin/bash
# Configures location privacy, background modes, the privacy manifest and
# read-only Apple Health (usage descriptions + entitlement) for
# an externally built Capacitor iOS app. Does not modify Base44-generated IPAs.
#
# Usage (from the project root, after `npx cap add ios`):
#   bash native/patch-info-plist.sh
#
# Idempotent: safe to run on every build. Targets the generated Capacitor iOS
# project at ios/App/App/Info.plist (verified Capacitor 5 template path).
#
# What it does:
#   1. Adds the live-run location permission description to Info.plist.
#   2. Adds UIBackgroundModes [location, audio] (Background Modes capability).
#   3. Adds the app-target privacy manifest to the bundle resources.
#   4. Adds both Apple Health usage descriptions and the HealthKit entitlement.
set -euo pipefail

APP_DIR="ios/App/App"
PLIST="$APP_DIR/Info.plist"
MANIFEST="$APP_DIR/PrivacyInfo.xcprivacy"
PB=/usr/libexec/PlistBuddy
[ -x "$PB" ] || PB="/usr/sbin/PlistBuddy"

if [ ! -f "$PLIST" ]; then
  echo "ERROR: $PLIST not found — run from the project root after 'npx cap add ios'." >&2
  exit 1
fi

echo "Bundle ID configured in the iOS project:"
grep -o 'PRODUCT_BUNDLE_IDENTIFIER = [^;]*;' ios/App/App.xcodeproj/project.pbxproj | sort -u

# ---------------------------------------------------------------- Info.plist
add_key() {
  local key="$1" value="$2"
  if "$PB" -c "Print :$key" "$PLIST" >/dev/null 2>&1; then
    echo "present: $key"
  else
    "$PB" -c "Add :$key string '$value'" "$PLIST"
    echo "added:   $key"
  fi
}

add_key "NSLocationWhenInUseUsageDescription" \
  "PacePlay tracks your GPS route, distance and pace during a live run, and keeps tracking (with music control) running while your screen is locked."

# Apple Health (read-only): PacePlay reads workouts, heart rate and routes and
# never writes to Apple Health. Apple requires BOTH usage descriptions when the
# HealthKit entitlement is present.
add_key "NSHealthShareUsageDescription" \
  "PacePlay reads your Apple Health workouts (distance, pace, heart rate and route) to show your run history and tune your pace-matched playlists. PacePlay never writes to Apple Health."
add_key "NSHealthUpdateUsageDescription" \
  "PacePlay never writes to Apple Health. Any HealthKit access is read-only."

# Background Modes: location keeps GPS alive when locked, audio keeps the
# process alive. Both are Info.plist entries; no portal capability needed.
"$PB" -c "Print :UIBackgroundModes" "$PLIST" >/dev/null 2>&1 \
  || "$PB" -c "Add :UIBackgroundModes array" "$PLIST"
MODES=$("$PB" -c "Print :UIBackgroundModes" "$PLIST" 2>/dev/null || echo "")
for mode in location audio; do
  if ! echo "$MODES" | grep -qE "^[[:space:]]*${mode}[[:space:]]*$"; then
    "$PB" -c "Add :UIBackgroundModes:0 string $mode" "$PLIST"
    echo "added background mode: $mode"
  else
    echo "present background mode: $mode"
  fi
done

# ------------------------------------------------------- Privacy manifest
# Fitness data may still be imported from Strava; keep its collection disclosure.
if [ ! -f "$MANIFEST" ]; then
  cat > "$MANIFEST" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>NSPrivacyTracking</key>
	<false/>
	<key>NSPrivacyTrackingDomains</key>
	<array/>
	<key>NSPrivacyCollectedDataTypes</key>
	<array>
		<dict>
			<key>NSPrivacyCollectedDataType</key>
			<string>NSPrivacyCollectedDataTypeHealthFitness</string>
			<key>NSPrivacyCollectedDataTypeLinked</key>
			<true/>
			<key>NSPrivacyCollectedDataTypeTracking</key>
			<false/>
			<key>NSPrivacyCollectedDataTypePurposes</key>
			<array><string>NSPrivacyCollectedDataTypePurposeAppFunctionality</string></array>
		</dict>
		<dict>
			<key>NSPrivacyCollectedDataType</key>
			<string>NSPrivacyCollectedDataTypeLocation</string>
			<key>NSPrivacyCollectedDataTypeLinked</key>
			<true/>
			<key>NSPrivacyCollectedDataTypeTracking</key>
			<false/>
			<key>NSPrivacyCollectedDataTypePurposes</key>
			<array><string>NSPrivacyCollectedDataTypePurposeAppFunctionality</string></array>
		</dict>
	</array>
	<key>NSPrivacyAccessedAPITypes</key>
	<array>
		<dict>
			<key>NSPrivacyAccessedAPIType</key>
			<string>NSPrivacyAccessedAPICategoryUserDefaults</string>
			<key>NSPrivacyAccessedAPITypeReasons</key>
			<array><string>CA92.1</string></array>
		</dict>
	</array>
</dict>
</plist>
EOF
  echo "created: $MANIFEST"
fi

# Bundle the privacy manifest with the app (idempotent, via xcodeproj gem).
ruby -r xcodeproj -e '
  project = Xcodeproj::Project.open("ios/App/App.xcodeproj")
  target = project.targets.find { |t| t.name == "App" }
  abort "App target not found" unless target
  already = target.resources_build_phase.files_references.any? { |r| r.path.to_s.end_with?("PrivacyInfo.xcprivacy") }
  unless already
    file_ref = project.main_group.new_file("App/PrivacyInfo.xcprivacy")
    target.resources_build_phase.add_file_reference(file_ref, true)
    project.save
    puts "bundled app-target PrivacyInfo.xcprivacy"
  end
' 2>/dev/null || echo "note: could not bundle privacy manifest via ruby (continuing)"

# -------------------------------------------------- HealthKit entitlement
# Read-only: the entitlement flags the app's HealthKit capability and the
# healthkit-bridge podspec links the HealthKit framework. The provisioning
# profile must include the HealthKit capability (see EXPORT-CHECKLIST.md).
ENT="$APP_DIR/PacePlay.entitlements"
if [ ! -f "$ENT" ]; then
  cat > "$ENT" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>com.apple.developer.healthkit</key>
	<true/>
</dict>
</plist>
EOF
  echo "created: $ENT"
fi

ruby -r xcodeproj -e '
  project = Xcodeproj::Project.open("ios/App/App.xcodeproj")
  target = project.targets.find { |t| t.name == "App" }
  abort "App target not found" unless target
  needs_setting = target.build_configurations.any? { |c| c.build_settings["CODE_SIGN_ENTITLEMENTS"] != "App/PacePlay.entitlements" }
  if needs_setting
    target.build_configurations.each do |c|
      c.build_settings["CODE_SIGN_ENTITLEMENTS"] = "App/PacePlay.entitlements"
    end
    project.save
    puts "set CODE_SIGN_ENTITLEMENTS = App/PacePlay.entitlements"
  else
    puts "present: CODE_SIGN_ENTITLEMENTS"
  end
' 2>/dev/null || echo "note: could not set CODE_SIGN_ENTITLEMENTS via ruby (continuing)"

echo "Done: location privacy, background modes, privacy manifest and read-only HealthKit are in place."