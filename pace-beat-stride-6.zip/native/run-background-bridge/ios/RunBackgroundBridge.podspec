Pod::Spec.new do |s|
  s.name = 'RunBackgroundBridge'
  s.module_name = 'RunBackgroundBridge'
  s.version = '0.1.0'
  s.summary = 'Locked-screen run support for PacePlay: background GPS tracking and keep-alive audio session'
  s.homepage = 'https://pace-beat-stride.base44.app'
  s.author = 'PacePlay'
  s.license = 'MIT'
  s.source = { :path => '.' }
  s.ios.deployment_target = '13.0'
  s.swift_version = '5.1'
  s.source_files = 'RunBackgroundBridge/**/*.{swift,h,m}'
  s.frameworks = 'CoreLocation', 'AVFoundation'
  s.dependency 'Capacitor'
end