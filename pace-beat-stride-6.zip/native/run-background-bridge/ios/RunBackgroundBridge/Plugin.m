#import <Foundation/Foundation.h>
#import <Capacitor/Capacitor.h>
#import "Plugin.h"

CAP_PLUGIN(RunBackgroundBridgePlugin, "RunBackgroundBridge",
    CAP_PLUGIN_METHOD(enable, CAPReturnPromise);
    CAP_PLUGIN_METHOD(disable, CAPReturnPromise);
)