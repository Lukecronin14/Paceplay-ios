import Foundation
import Capacitor
import CoreLocation
import AVFoundation

/**
 * Locked-screen run support for PacePlay.
 *
 * JS contract (consumed by src/lib/runBackground.js via
 * window.Capacitor.Plugins.RunBackgroundBridge):
 *   enable()  -> activates a playback audio session (mixes with Spotify) and
 *                starts background location updates
 *   disable() -> stops location updates and deactivates the audio session
 *   "location" listener events: { latitude, longitude, accuracy, timestamp(ms) }
 *
 * With the host app's Background Modes ("Location updates" + "Audio") and
 * When-In-Use location permission, both keep running while the screen is
 * locked, so GPS tracking, pace assessment and Spotify track switching
 * continue in the webview.
 */
@objc(RunBackgroundBridgePlugin)
public class RunBackgroundBridgePlugin: CAPPlugin, CLLocationManagerDelegate {

    private let locationManager = CLLocationManager()
    private var audioSessionActive = false

    override public func load() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.activityType = .fitness
        locationManager.distanceFilter = 5
        locationManager.pausesLocationUpdatesAutomatically = false
    }

    @objc func enable(_ call: CAPPluginCall) {
        // 1. Background audio session: keeps the app process (and the webview's
        //    JS timers, GPS watch and Spotify poll) alive while the device is
        //    locked. mixWithOthers lets Spotify keep playing uninterrupted.
        if !audioSessionActive {
            let session = AVAudioSession.sharedInstance()
            do {
                try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
                try session.setActive(true)
                audioSessionActive = true
            } catch {
                // Non-fatal: location tracking still works without it.
                print("[RunBackgroundBridge] audio session error: \(error.localizedDescription)")
            }
        }

        // 2. Background location updates (requires Background Modes -> Location
        //    updates in Xcode + When-In-Use permission).
        if locationManager.authorizationStatus == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        }
        DispatchQueue.main.async {
            if #available(iOS 9.0, *) {
                self.locationManager.allowsBackgroundLocationUpdates = true
            }
            if #available(iOS 11.0, *) {
                self.locationManager.showsBackgroundLocationIndicator = true
            }
            self.locationManager.startUpdatingLocation()
        }
        call.resolve()
    }

    @objc func disable(_ call: CAPPluginCall) {
        locationManager.stopUpdatingLocation()
        if audioSessionActive {
            let session = AVAudioSession.sharedInstance()
            try? session.setActive(false, options: [.notifyOthersOnDeactivation])
            audioSessionActive = false
        }
        call.resolve()
    }

    public func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        for location in locations {
            // Mirror the web-side accuracy filter (reject fixes worse than 40 m)
            let accuracy = location.horizontalAccuracy
            guard accuracy >= 0, accuracy <= 40 else { continue }
            notifyListeners("location", data: [
                "latitude": location.coordinate.latitude,
                "longitude": location.coordinate.longitude,
                "accuracy": accuracy,
                "timestamp": Int64(location.timestamp.timeIntervalSince1970 * 1000),
            ])
        }
    }

    public func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // Transient GPS errors are ignored, matching the web behavior.
        print("[RunBackgroundBridge] location error: \(error.localizedDescription)")
    }
}