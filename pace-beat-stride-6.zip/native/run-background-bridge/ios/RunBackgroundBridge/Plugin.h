#import <Capacitor/Capacitor.h>

@interface RunBackgroundBridgePlugin : CAPPlugin
- (void)enable:(CAPPluginCall *)call;
- (void)disable:(CAPPluginCall *)call;
@end