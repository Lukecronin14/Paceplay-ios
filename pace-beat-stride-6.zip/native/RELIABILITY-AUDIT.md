# PacePlay — Read-Only Reliability & Functional Audit

**Date:** 2026-10-12 · **Mode:** Read-only. No production code, schemas, payment config, secrets, or user data were modified. Apple IAP migration work remains paused.

## Method & verification status

- Full read of live-run tracking, music players/hooks, OAuth/token backend functions, payment functions, HealthKit + background native plugins, subscription/entitlement logic, and auth/layout wiring.
- **Verified by execution (not just read):**
  - `npm run build` — passes.
  - `npm test` (vitest) — **6 suites, 65/65 pass** (paceUtils 23, subscriptionAccess 13, trialEligibility 10, healthKit 8, units 8, decodePolyline 3).
  - SDK list-call shapes (`Subscription.list()`, `MusicPreference.list()`, `RunPlan.list('-created_date', 5)`) — all return arrays; legacy positional signature works. (Concern investigated and refuted.)
- **Nothing in this audit has been verified on a physical iPhone.** All device behaviour (locked-screen tracking, background music, incoming calls, HealthKit on-device) is classified *Untested* or *Potential* and requires the device pass in `native/EXPORT-CHECKLIST.md` §6.

Severity: 🔴 High (data loss, security, broken core feature) · 🟠 Medium · 🟡 Low.

---

## 1. Live run tracking

### F1 — Paused time is counted as running time 🔴 Confirmed defect
- **Evidence:** `src/hooks/useRunTracker.js` — `startTimeRef` is set once at start (L80) and never adjusted. The timer skips updates while paused (L100–104) but on resume `setElapsedSec(Date.now() - startTimeRef)` jumps forward by the entire paused duration (L102). Splits use the same clock (L46); `stop()` computes `actual_time_min` from `Date.now() - startTimeRef` (L118–119, consumed in `LiveRunActive.jsx` L385–394).
- **Impact:** Every pause inflates elapsed time, split times, and final average pace. A runner pausing 5 min mid-run sees their recorded pace and splits corrupted — exactly the metric the app sells.
- **Repro:** Start run → wait 60 s → pause 60 s → resume → elapsed reads ~120 s and pace worsens accordingly.
- **Fix:** Track `pausedAccumMs`; on resume add the pause duration; elapsed = now − start − pausedAccum. Derive splits from active time only. Add unit tests (extract a pure time-accumulator module like `subscriptionAccess`).

### F2 — Active run is lost on tab switch, page refresh, or crash 🔴 Confirmed defect
- **Evidence:** GPS/route live only in `useRunTracker` refs; `LiveRun.route` is written **only** in `handleStop` (`src/pages/LiveRunActive.jsx` L388–396). In `AppLayout.jsx`, `/live-run/:id` is not a keep-alive tab root — it renders inside the `AnimatePresence` outlet, so tapping any bottom-nav tab (e.g. Home, Live) unmounts `LiveRunActive`, clearing the watch and timer (cleanup L133–142). No `beforeunload` guard exists.
- **Impact:** A runner who switches apps/tabs, taps a nav item, or suffers a crash/refresh loses the entire run record. Highest user-data-loss risk in the app.
- **Repro:** Start a run, walk 200 m, tap the Home tab → return to `/live-run/:id`: record still `active` but tracker restarted at 0; recorded route is never persisted.
- **Fix:** (a) checkpoint the run record every ~15–30 s (distance, elapsed, route downsampled); (b) on mount of an `active` run, offer "Resume run" restoring checkpoint state; (c) warn before navigating away mid-run.

### F3 — Music search blocks GPS start; search failure is silent 🟠 Confirmed defect
- **Evidence:** `handleStart` awaits `searchTracksForPool()` (up to ~50 sequential Spotify searches via `spotifyIntegration` L314–352, or Apple Music catalog search loop `appleMusicData.js` L197–214) **before** `tracker.start()` (L306–322). `searchTracksForPool` catch only logs (L120–121); no toast, and the playback controller requires `Object.keys(trackUris).length > 0` (L206) so music silently never starts.
- **Impact:** The run's official clock starts late (tracking begins after all searches), and a failed search leaves the user running with no music and no explanation.
- **Fix:** Start the tracker first and search in parallel; toast a "no playable tracks found" warning when the result is empty.

### F4 — Pace and splits are wrong immediately after resume 🟡 Confirmed defect (sub-case of F1)
- **Evidence:** Current pace is computed over the last 6 GPS points (`useRunTracker.js` L58–69). No points are ingested while paused, so the first post-resume sample spans the pause gap → momentarily absurd (very slow) pace; same for the first post-resume split.
- **Fix:** Reset the pace window after a pause (drop pre-pause points), covered by F1's tests.

### F5 — GPS permission denial / mid-run revocation gives no user feedback 🟡 Potential defect
- **Evidence:** The watch error callback only does `console.error` (`useRunTracker.js` L95). If permission is denied, or revoked in iOS Settings mid-run, distance silently stays 0. No UI state exposes it.
- **Impact:** A runner may complete a session believing they were tracked.
- **Fix:** Surface a persistent "GPS unavailable" banner when no fix has arrived within N seconds of start or when errors occur. Requires device testing to confirm exact browser/webview behaviour.

### F6 — Wake-lock/keep-alive strategy is unsupported on iOS Safari web 🟠 Untested behaviour
- **Evidence:** `useWakeLock.js` reports `supported=false` on iOS Safari (Screen Wake Lock unsupported). `useAudioKeepAlive.js` is explicitly skipped on native iOS (L16). On the **Base44-published iOS wrapper** the custom `RunBackgroundBridge` is not available (documented in `native/README.md` platform note) — so the shipped iOS app has no locked-screen tracking mechanism at all; web iOS relies on nothing once the screen locks.
- **Impact:** On the installed iOS app, locking the screen most likely suspends JS, GPS and track switching. This is the app's core promise.
- **Fix:** Verify on device (locking a webview app: does tracking survive?); the real solution is the external Capacitor build with `RunBackgroundBridge` (Phase 3 of the export checklist).

### F7 — Background audio session may not hold under iOS 🟠 Potential defect
- **Evidence:** `RunBackgroundBridge/Plugin.swift` activates an `AVAudioSession` category `.playback` **without playing any audio** (L39–49). iOS commonly suspends apps whose "playback" session produces no audio; App Review also flags unused background-audio entitlements.
- **Fix:** Device test a ≥10-minute locked run; if suspended, add a near-silent audio unit inside the plugin (native, so no App-Review ambiguity vs the web blob approach), and document the usage honestly for review.

### F8 — Incoming-call / interruption recovery 🟠 Untested behaviour
- **Evidence:** No code handles `visibilitychange` during a run beyond wake-lock re-acquisition (`useWakeLock.js` L31–35), and `RunBackgroundBridge` sets `pausesLocationUpdatesAutomatically = false` (good). Whether elapsed time, Spotify Connect state, and MusicKit survive an interruption is unknown.
- **Fix:** Device test: incoming call during active run → verify distance continues (lock screen), music resumes, and no duplicate track adoption.

---

## 2. Music integrations

### F9 — `apple-music-token` mints developer tokens to unauthenticated callers 🔴 Confirmed security defect
- **Evidence:** `base44/functions/apple-music-token/entry.ts` never calls `createClientFromRequest`/`base44.auth.me()` — anyone with the public function URL (`https://pace-beat-stride.base44.app/functions/apple-music-token`) receives a signed 30-day Apple Music developer token for the app's team.
- **Impact:** Abusable third-party token minting under the app's Apple identity; revocation requires rotating the .p8 key.
- **Fix:** Require an authenticated session (`401` otherwise). Small change, high impact.

### F10 — Music backend functions proxy any caller-supplied Spotify token with unbounded input 🟡 Confirmed weakness
- **Evidence:** `spotifyIntegration/entry.ts` actions (`getProfile`, `getPlaylists`, `searchTracks`, `getPlaylistTracks`, `searchAndExportPlaylist`) execute with whatever `accessToken` is in the request body (no ownership tie-in — acceptable, since it only reaches the Spotify account that token belongs to), but `searchTracks` loops over an arbitrary-length `tracks` array with 2 sequential searches each (L314–352) — a logged-in user can hang the function with thousands of tracks. No size caps anywhere.
- **Fix:** Cap array sizes (e.g. 100) and return early; consider batched search.

### F11 — Expired Spotify token mid-run is not refreshed for searches 🟠 Potential defect
- **Evidence:** `LiveRunActive.jsx` reads `spotifyToken` from localStorage once at render (L47). The playback hook tracks refresh events (useSpotifyPlayer L17–24) but `spotifyToken` used by `searchTracksForPool` does not; `spotifyIntegration.searchTracks` performs no server-side refresh (unlike Strava's `getValidAccessToken`).
- **Impact:** Long-lived sessions starting a second run >1h after token issue may fail all track searches.
- **Fix:** Have `searchTracksForPool` read the token at call time and let the backend refresh on 401 like the Strava path does.

### F12 — Apple Music playback paths (queue adoption, gapless advance, lock-screen) 🟠 Untested behaviour
- **Evidence:** `useAppleMusicPlayer.js` uses `music.player.queue.append` and pre-queued items; `LiveRunActive.jsx` L174–193 adopts `nowPlayingItemId`. Code is coherent but none of it is exercised by tests or verified on device (MusicKit v3 API shape, full-track entitlement without subscription, locked-screen behaviour).
- **Fix:** Device test pass per `native/README.md` §Verifying.

### F13 — Spotify foreign-playback reclaims and pause-respect logic 🟠 Untested behaviour
- **Evidence:** `LiveRunActive.jsx` L202–285 implements takeover/queue/adopt logic with an 8 s settle window. Logic reads correctly but race conditions (e.g. queue failing right at track end, Spotify Connect device switch mid-run) need device testing.

---

## 3. Routes and training

### F14 — Strava terrain prediction misses modern activity records and skips the token guard 🟠 Confirmed defect (inconsistency)
- **Evidence:** `stravaIntegration/entry.ts` `predictRoute` filters `a.type === 'Run' || a.type === 'VirtualRun'` (L258) — but `getActivities` was explicitly fixed to match `sport_type` too (L168–172, "Strava deprecated the `type` field"). `predictRoute` also calls the API with the raw token and no `getValidAccessToken` guard/refresh (L254), unlike every other action.
- **Impact:** Prediction returns "no recent runs" for athletes whose activities lack `type`, and fails outright when the token is expired.
- **Fix:** Reuse `isRunType` + `getValidAccessToken`.

### F15 — Elevation estimate from average grade is crude 🟡 Confirmed simplification
- **Evidence:** `predictRoute` computes `elevation_gain_m` as `Σ max(0, avg_grade × 10)` (L329–330) — grade × an assumed 10 m segment length, not real distance. Values can be off by an order of magnitude; used as "elevation" in LiveRunSetup and route cards.
- **Fix:** Compute from `total_elevation_gain` of the analysed runs (already available in the activity payload) instead.

### F16 — Parkrun catalogue fetch is client-side and uncached across sessions 🟡 Potential defect
- **Evidence:** `src/lib/parkrunData.js` fetches the full parkrun `events.json` (multi-MB, ~2,000 UK events filtered client-side) in the browser per session. ParkRun entity data exists in the DB (`ParkRun` entity, admin-seeded terrain fields), but the live fetch path has no error handling (any network failure propagates).
- **Fix:** Prefer the entity for browsing; keep the live fetch as a background refresh with a cached fallback.

### F17 — Parkrun terrain data completeness 🟠 Untested behaviour
- **Evidence:** `ParkRun` segments/elevation are admin-maintained; whether every listed event has segments and accurate `terrain_type` was not audited record-by-record (read-only data inspection not performed against live records beyond counts). Playlist-to-route matching (`LiveRunSetup` prompt) degrades to generic when terrain is missing — acceptable, but should be verified for the most-used events.

---

## 4. Accounts and persistence

### F18 — Account deletion misses HealthRun records and the Apple Music token 🔴 Confirmed defect
- **Evidence:** `base44/functions/delete-account/entry.ts` deletes LiveRun, RunPlan, MusicPreference, Subscription, IntegrationSecret (spotify/strava) — but **not** `HealthRun` (GPS routes + heart-rate data!), and the User-record cleanup (L20–26) doesn't clear `apple_music_token`/`apple_music_connected` (persisted via `saveAppleMusicIntegration`, `integrationStorage.js` L62–68).
- **Impact:** GDPR/right-to-erasure failure: the most sensitive data (health + GPS) survives deletion, plus a music token.
- **Fix:** Add `HealthRun.deleteMany({created_by_id: uid})` and clear the apple_music user fields.

### F19 — HealthRun dedupe only checks the last 500 records 🟡 Confirmed limitation
- **Evidence:** `src/lib/healthKit.js` `importHealthRuns` reads `list('-created_date', 500)` and dedupes within that page (L90–93). With >500 workouts, older uuids fall outside the window and re-import creates duplicates.
- **Fix:** Query by `workout_uuid $in` for the incoming set (server-side filter) instead of page-limited reads.

### F20 — Offline behaviour during a run 🟠 Untested behaviour
- **Evidence:** `handleStart/Pause/Resume/Stop` each await a `LiveRun.update`; failures roll back status with a toast (good), but there is no offline queue — mid-run with no connectivity, pause/resume still works client-side (tracker is local) while music search/save silently fail. Start over a dead network rolls back properly.
- **Fix:** Acceptable to leave as-is for v1 if device testing confirms; document that status sync needs connectivity.

### F21 — Session expiry and connection restore 🟠 Untested behaviour (well-designed in code)
- **Evidence:** Expired tokens are treated as logged-out with public Home + login prompts (`AuthContext.jsx` L103–110); server-stored refresh tokens silently re-mint access tokens on a new device (`useTokenRefresh.js` L63–79). Strava refreshes are single-flight both client and server-side (`stravaTokens.ts` lock). Looks correct; not exercised by tests or on device.

### F22 — No duplicate-submission guard on plan/run creation beyond button disable 🟡 Confirmed (minor)
- **Evidence:** `LiveRunSetup.handleGenerate` relies on `disabled={generating}`; a double-tap racing the state update could create two LiveRuns. Low impact (user can ignore/delete), no unique key exists to upsert on.
- **Fix:** Acceptable; optionally disable at handler entry.

---

## 5. Backend security and reliability

### F23 — Subscription writes are properly locked down ✅ Verified sound
- **Evidence:** `Subscription` RLS: client create/update/delete admin-only (schema). All entitlement writes go through service-role functions scoped by the authenticated session (`create-checkout`, `redeem-promo`, `wix-payments-webhook`). `wix-payments-webhook` fails closed on JWT verification (`RS256`), and activation via `updateMany({checkout_id})` is idempotent for redeliveries. Premium features gated by `hasAccess` from `subscriptionAccess.js` (unit-tested) and `FeatureLock`/layout gating. No premium operation was found invokable outside the intended UI **other than F9**.

### F24 — Checkout start burns trial eligibility 🔴 Confirmed defect
- **Evidence:** `create-checkout/entry.ts` sets `trial_start_date`/`trial_end_date` when creating a pending Subscription record for a first-time checkout (L84–93). `hasPriorTrial` (`trialEligibility.js`) treats any record with trial dates as "trial already redeemed" — so a user who merely *starts* checkout and abandons it can never redeem a trial promo code. Also inconsistent with the 30-day promo trial (`redeem-promo` `TRIAL_DAYS=30` vs 14 days here).
- **Fix:** Don't set trial dates in the pending path; trial dates belong only to the promo-grant path.

### F25 — Cancelling cuts access immediately, before the paid period ends 🟠 Confirmed defect
- **Evidence:** `create-checkout` `cancelSubscription` sets `status: 'canceled'` immediately (L149–151) even for the soft cancel (`immediate: false`). `computeEntitlements` gives no access for `canceled`.
- **Impact:** A paying user who cancels loses premium instantly instead of at period end — poor and arguably unfair behaviour.
- **Fix:** Keep status `active` with a `cancel_at_period` flag; rely on the `subscription_contract_expired` webhook to flip to `expired`.

### F26 — No input validation / rate limits on backend functions 🟡 Potential defect
- **Evidence:** None of the functions cap array sizes (F10), validate `code`/`targetDistance` types beyond truthiness, or implement custom rate limiting (platform entity rate limits apply to SDK calls, not function loops). Strava calls are throttled via `stravaFetch` 429 retry; Spotify paths are not.
- **Fix:** Add size caps; rely on platform limits otherwise.

### F27 — GPX upload interpolates unescaped route coordinates into XML 🟡 Potential defect
- **Evidence:** `stravaIntegration/entry.ts` `uploadGpx` escapes only `name`/`description`; `p.lat`, `p.lng`, `p.t` are injected raw (L366–369). They're normally numbers from the tracker, but a crafted payload could inject XML elements into the file sent to Strava.
- **Fix:** Validate numeric types before serialization.

### F28 — Webhook/entitlement cross-checks ✅ Sound (within web scope)
- **Evidence:** Order-approval grants are keyed on `checkout_id` persisted **before** redirect (no email correlation); cancel/expire keyed on Wix `subscription_id`. Promo codes are secret-backed server-side (`redeem-promo`); note the fallback codes remain active until `PROMO_CODE_TRIAL` is set (known issue, documented).

---

## 6. Native iOS implementation

### F29 — Base44-published iOS wrapper vs external Capacitor build 🟠 Untested behaviour / documented gap
- **Evidence:** `native/README.md` and `EXPORT-CHECKLIST.md` (verified against workspace state 2026-10-12: no `ios/` project exists) state the published wrapper cannot ship the HealthKit or background plugins. Web fallbacks are mock workouts (`healthKit.js`) and no locked-screen support.
- **Impact:** The installed iOS app differs materially from the website: no real HealthKit, likely no locked-screen runs (see F6). This is the single biggest "app vs site" gap.
- **Fix:** Complete the export checklist (external Capacitor build) before judging iOS reliability; until then, document limitations in-app.

### F30 — Capacitor config and plugin registration ✅ Verified sound (static)
- **Evidence:** `native/capacitor.config.json` (appId `Florenceanne123`, webDir `dist`); both plugins declare pods + register names matching the JS lookups (`HealthKitBridge`, `RunBackgroundBridge`); HealthKit read-only types match the privacy descriptions; both plugins ship `PrivacyInfo.xcprivacy`; app-target manifest template with health/location declarations is provided in the checklist. No code-vs-doc discrepancies found in the native docs.
- **Untested:** Background Modes entitlement behaviour, `allowsBackgroundLocationUpdates` with When-In-Use permission (blue indicator expectations), and iOS 13 vs 15 deployment targets all require the device pass.

---

## 7. Testing and release quality

### F31 — Build & suite ✅ Verified
- `npm run build` passes; `vitest` 65/65. Browserslist data is 8 months stale (warning only).

### F32 — Dead UI modules import uninstalled packages 🟡 Confirmed (latent hazard)
- **Evidence:** `src/components/ui/input-otp.jsx` imports `input-otp`, `src/components/ui/resizable.jsx` imports `react-resizable-panels` — both packages were uninstalled. Not imported anywhere, so the build ignores them, but any future import breaks the build.
- **Fix:** Delete the two unused UI files.

### F33 — Coverage gaps 🟠 Confirmed
- No tests for: run-tracker time/distance math (F1 would have been caught), music service selection, HealthRun import/dedupe logic, backend functions (none testable today — logic lives inline), pace-scenario selection partially covered via paceUtils. Recommendation: extract `useRunTracker`'s accumulation into a pure module (like `subscriptionAccess`) and test it.

---

## Prioritised remediation plan

| # | Fix | Severity | Acceptance criteria / tests |
|---|-----|----------|------------------------------|
| R1 | **F1/F4 pause-time fix** — extract time-accumulator from `useRunTracker`; pause excludes paused duration from elapsed, splits, pace, final `actual_time_min` | 🔴 | New vitest suite: pause 60 s mid-run → elapsed/split/final pace identical to uninterrupted equal-distance run; resume resets pace window |
| R2 | **F2 run checkpoint + recovery** — periodic `LiveRun.update` (distance/elapsed/route) every ~30 s; on mounting an `active` run offer resume-from-checkpoint; nav-away warning during `active` | 🔴 | Kill/refresh the tab mid-run → "Resume" restores distance & route within tolerance; nav to Home mid-run prompts |
| R3 | **F18 delete-account completeness** — delete HealthRun records; clear apple_music user fields | 🔴 | Backend test path: create seed records → invoke → assert zero remaining `HealthRun` and no apple_music fields on user |
| R4 | **F9 authenticate `apple-music-token`** — 401 without a valid session | 🔴 | Unauthenticated invoke → 401; authenticated invoke → token |
| R5 | **F3 start tracking first, search in parallel; toast when no playable tracks** | 🟠 | Start button enables tracking immediately; failed search shows a non-blocking warning; music (if found) still starts |
| R6 | **F24 don't stamp trial dates on pending checkout** | 🟠 | Start-and-abandon checkout then redeem trial promo → succeeds (vitest on `hasPriorTrial` already exists; extend for pending-shape data) |
| R7 | **F25 cancel keeps access to period end** | 🟠 | Cancel → entitlements stay `hasAccess` until `subscription_contract_expired` webhook flips status |
| R8 | **F14 predictRoute modernisation** — `sport_type` matching + `getValidAccessToken` guard | 🟠 | Prediction works with `sport_type`-only activities; works with an expired access token |
| R9 | **F32 delete dead UI modules**; browserslist refresh | 🟡 | Build stays green |
| R10 | **F5 GPS-unavailable banner** + F15 elevation-from-real-gain + F27 GPX numeric validation | 🟡 | Banner appears when no fix in 30 s; elevation uses `total_elevation_gain`; malformed route payload rejected 400 |

Device-testing gate (before any of this is "verified"): locked-screen 10-min run with music, incoming-call interruption, HealthKit import + re-import, on the external Capacitor build — per `native/EXPORT-CHECKLIST.md` §6.

## Recommended first batch (small, high-impact, no UI redesign)

**R1 (pause math) + R3 (delete-account completeness) + R4 (token endpoint auth) + R9 (dead files).**
Each is a contained change with an immediate test or obvious verification, none touches the UI or payment flow, and together they remove the worst data-integrity, privacy, and security exposures while the bigger checkpoint/recovery work (R2) is designed properly.

*No fixes implemented — awaiting review and approval.*

---

## Stage A completion report (2026-10-12)

Approved batch implemented: R1 (F1/F4 pause timing), R4 (F9 token endpoint auth), R3 (F18 deletion completeness). No IAP, subscription-logic, or unrelated refactoring changes. Active-run checkpointing (R2) deliberately NOT started, per scope.

### Files changed
| File | Change |
|---|---|
| `src/lib/runClock.js` | NEW — pure active-time clock (start/pause/resume/elapsedMs; timestamp-injected, deterministic) |
| `src/hooks/useRunTracker.js` | Uses `RunClock`: elapsed, splits, and stop-time all derive from active time; pace window restarts after a resume so samples never span a pause gap |
| `base44/shared/appleMusicToken.js` | NEW — pure ES256 MusicKit token minting extracted from the function |
| `base44/functions/apple-music-token/entry.ts` | Requires authenticated session (`401` otherwise); per-user rate limit (10 / 15 min, best-effort, resets on cold start); safe error messages — key material and crypto details never returned; logs caller id, never key data |
| `base44/shared/accountDeletion.js` | NEW — pure, unit-tested deletion plan: all six user-owned entities incl. `HealthRun`, scoped strictly by owner |
| `base44/functions/delete-account/entry.ts` | Deletes via the plan (now incl. HealthRun records); clears Spotify, Strava **and** Apple Music credentials on the user record; returns honest `limitations` list |
| `tests/runClock.test.js` · `tests/appleMusicToken.test.js` · `tests/accountDeletion.test.js` | NEW — 24 tests (see below) |

### Behaviour changed
1. **Paused time no longer counts.** Elapsed display, km splits, final `actual_time_min`/pace all exclude paused duration, including while a pause is in progress; repeated pause/resume cycles accumulate correctly; pace after resume is computed only from post-resume GPS points.
2. **`apple-music-token` now 401s for unauthenticated callers** and 429s after 10 mints/user/15 min. Legitimate Apple Music flow unchanged (same response shape).
3. **Account deletion now erases HealthRun records (GPS + heart rate) and the Apple Music token** alongside all previously-covered entities. No other user's data can match — every deletion filter is the authenticated user's own id.

### Test results (executed, not asserted)
- New suites: `runClock` 10 tests (no pauses / one pause / multiple pauses / double-pause guard / stop-after-resume / restart reset — all timestamp-injected, no real-time delays) · `appleMusicToken` 6 (claims, signature verified against a generated P-256 public key, key normalisation, garbage-key rejection) · `accountDeletion` 8 (plan covers every user-owned entity incl. HealthRun, excludes shared `ParkRun`, per-user scoping + isolation, IntegrationSecret keyed by `user_id`, empty-id rejection, credential-field clearing).
- **Full suite: 9 files, 89/89 passed** (65 pre-existing + 24 new). **Production build: exit 0.**
- Live function check: `test_backend_function('apple-music-token')` with an authenticated session returned a valid token (200) — the authorized path works; its JWT decodes to `ES256`/correct kid/issuer with a 30-day expiry. One test expectation was corrected during the run (a my-arithmetic error in the stop-after-resume case, not a product bug); final run fully green.
- **No destructive tests were run against real accounts** — deletion is verified via the pure plan unit tests; the service-role loop is a straight application of that plan.

### Reported limitations (deliberately not "fixed" beyond scope)
- **The published site still runs the old, unauthenticated token endpoint until the app is republished** — republishing closes the F9 hole for real; after that, `GET https://pace-beat-stride.base44.app/functions/apple-music-token` without cookies should return `401`.
- **Wix billing is not cancelled by account deletion** (pre-existing behaviour, unchanged): erasing the `Subscription` row does not stop Wix-side billing; cancel handling via the Wix API or the dashboard is a separate decision — reported per your instruction, not implemented.
- **The Base44 sign-in account itself is not deleted by this flow** (no supported app-code path was verified); the response now states this explicitly. Safe supported approach: all personal data is erased and credentials cleared; account removal itself needs an admin/support action.
- The token endpoint's rate limit is per server instance (resets on cold start); the platform's own function limits provide the outer bound.

### Post-deployment verification (2026-10-13)
- Live HTTP (published): unauthenticated POST → 500 "Unable to generate token" (denied, nothing leaked) — **defect**: `auth.me()` throws rather than returning null, bypassing the 401 branch. Fixed in source; live 401 pending republish.
- Live, SDK-authenticated: 11 consecutive mints all succeeded — legitimate flow intact, but the in-memory rate limiter never engaged (no 429): not reliable across requests. Awaiting decision: remove it (recommended, rely on platform limits) or persist counters in an entity.
- Source inspection: `delete-account` had the same unauth 500 pattern and echoed internal `error.message` — both fixed (401 catch; generic client message).
- Regression after fixes: 89/89 tests pass; production build exit 0.
- Supported auth-account removal (docs): dashboard App Users → Remove user, then permanent delete from Recently deleted, or the beta Remove-app-user API. App-code deletion remains data-only and is retry-safe (idempotent per-user filters).

### Remaining manual verification
- On-device (per `native/EXPORT-CHECKLIST.md` §6): pause/resume timing during a real run, GPS-permission banner case (F5, unfixed in this batch), locked-screen behaviour (F6/F7, unfixed).
- After next publish: unauthenticated `401` probe of the live token endpoint.

### Rate limiter verification (2026-10-13)
- Function initially 500'd at runtime (`e.count is not a function`): the service-role entity client in backend functions does not expose `count()`. The limiter now counts in-window slots via `filter` (works on both clients); sandbox probe and unit tests updated to match — **97/97 pass**.
- Live end-to-end limit test (separate invocations, authenticated): **10 × 200, then 429** — the persistent cap engages correctly and is scoped per user; all 10 records carried the caller's own id. Test counter records were deleted afterwards, restoring a fresh window.

## Stage A final verification (2026-10-13, post-republish) — ALL CHECKS PASS

Evidence legend: 🔴 = live published HTTP request · 🟠 = authenticated SDK invoke against the same deployed function that serves the published URL · 🟡 = source inspection · 🟢 = automated tests. No session tokens, key material or secrets exposed at any point.

| # | Check | Verdict | Evidence |
|---|-------|---------|----------|
| 1 | `apple-music-token` unauthenticated → **401, not 500** | ✅ Pass | 🔴 POST to `https://pace-beat-stride.base44.app/functions/apple-music-token` → `401 {"error":"Authentication required"}` |
| 2 | 401 body leaks no token / key material / stack details | ✅ Pass | 🔴 Body is the single generic field above; scanned for JWT prefixes, `kid`, `pem`, stack markers — none |
| 3 | Authenticated flow still mints a valid developer token | ✅ Pass | 🟠 200 with ES256 token, `expiresIn: 2592000` (30 days); decoded claims verified in Stage A testing |
| 4 | Persistent limiter: 10 mints / 15 min, then 429 | ✅ Pass | 🟠 10 × 200 then 429 `{"error":"Too many requests. Please try again later."}`; a further invoke after the cap also 429'd |
| 5 | Limit isolated per user | ✅ Pass | 🟠 All 10 window records carried exactly one user id (the caller's own, taken from the session); 🟡 limiter keys every read/write/prune on `user.id` from the session, never request input; unit tests assert per-user scoping |
| 6 | Failed auth does not consume mint quota | ✅ Pass | 🔴 Two unauthenticated 401 probes immediately before the live mint test; the next 10 mints all succeeded (window was clean), proving 401s consumed nothing. 🟡 `acquireMintSlot` runs only after the auth check |
| 7 | Failed generation does not consume mint quota | ✅ Pass | 🟡 `confirmSlot` records a successful mint only after the token is minted; 🟢 rate-limit tests cover record-withdrawal on failed confirms |
| 8 | Window expires as expected | ✅ Pass | 🟠 Live: with the cap reached, one record was backdated 16 min → prune dropped it → the next mint succeeded (200). 🟢 unit tests cover window expiry |
| 9 | `delete-account` unauthenticated → **401, generic** | ✅ Pass | 🔴 POST to `/functions/delete-account` → `401 {"error":"Unauthorized"}`; no exception details |
| 10 | No production user data touched | ✅ Pass | 🔴 Deletion endpoint only probed unauthenticated (401 — no data path executed); test counter records (limiter's own entity) were the only writes, deleted afterwards (0 remaining) |
| 11 | Full automated suite + production build | ✅ Pass | 🟢 10 files, **97/97 pass** (incl. `runClock` 10, `accountDeletion` 7, `rateLimit` 8); `npm run build` exit 0 |
| 12 | Deletion plan covers all six user-owned entities incl. HealthRun + credentials | ✅ Pass | 🟢 `accountDeletion` tests assert the plan deletes LiveRun, RunPlan, MusicPreference, Subscription, IntegrationSecret, **HealthRun** (GPS/heart-rate), all scoped by owner, and clears Spotify, Strava **and** Apple Music credentials |

**Stage A is closed.** Remaining documented limitations (unchanged, by design):
- The Base44 sign-in (auth) account itself is **not** deleted by `delete-account`; data-only erasure remains, and auth-account removal requires platform-level admin action (dashboard App Users → remove + permanent delete). No supported, tested app-code path exists.
- Wix-side billing is not cancelled by account deletion.
- On-device items (F5 GPS banner, F6/F7 locked-screen behaviour) remain pending physical-device testing and are not part of Stage A.

**Recommendation:** proceed to Stage B (R2 — active-run checkpointing and recovery) as a separate, approved batch. IAP migration remains paused.
- Stage B (R2 checkpointing/recovery) not started — awaiting your review of this report.

---

## Stage B / Batch B1 report (2026-10-13) — APPROVED

Pure-module batch, no runtime wiring. **12 test files, 141/141 passed; production build exit 0.**
Changed: `src/lib/runClock.js` (+`toState`/`fromState`), `src/lib/runCheckpoint.js` (NEW pure module), `tests/runClockRestore.test.js` (14), `tests/runCheckpoint.test.js` (30), `src/native/STAGE-B-R2-DESIGN.md` (§12 safeguards 9–12). Details as reported and approved.

---

## Stage B / Batch B2 report (2026-10-13) — COMPLETE

### 1. Terminal-state concurrency: platform guarantee established FIRST (per approval condition)

Three live probes against the real data layer (scratch records, all deleted afterwards):

| Probe | Result |
|---|---|
| **Same-field race** (30 iterations): two concurrent conditional `updateMany` writes both filtering `status:'active'`, each writing `status` to a different value | **30/30 exactly one winner** (`updated: 1 + 0`). No round ever saw both succeed. |
| **Concurrent-writer hammer** (12 rounds × 6 concurrent conditional writers, same filter): any interleaved check-then-write would let several pass the check before writes land | **12/12 rounds exactly one winner.** Interleaved read-check-write is not observable on this data layer. |
| **Production-shape race** (12 iterations): finish (`$nin` guard → `status:'completed'`) vs checkpoint (`$nin` guard → `checkpoint:{...}`) fired concurrently, then a stale checkpoint attempted AFTER completion | Stale checkpoints after completion: **12/12 refused** (`updated: 0`). The 3 both-applied iterations are the legitimate checkpoint-then-finish order (the checkpoint does not change `status`, so the finisher's guard still matches) — the same-field race proves no harmful ordering exists. |

**Established guarantee:** a conditional `updateMany` (filter + `$set`) evaluates its filter **atomically with the write** — concurrent writes to the same record never interleave a check with another writer's write. Therefore a checkpoint, pause/resume or finish write carrying `{ id, status: { $nin: ['completed','abandoned'] } }` **cannot land on a run that has become `completed` or `abandoned`** — the data layer itself refuses the match (`updated: 0`), regardless of timing. The design's reported limitation (§12/9, "no atomic compare-and-swap; adopt-on-read as resolution") turned out stronger than assumed: the conditional write IS the atomic gate; adopt-on-read is kept only as defense-in-depth on the finish path.

Additional shape verification: a full checkpoint object (nested `clock`, `splits`, `route`, `last_point`, floats) written via the guarded shape round-trips through the stored record **deep-equal**, is cleared (`checkpoint: null`) by the guarded finish write, and a post-completion checkpoint is refused. `$nin` multi-value filters are supported.

### 2. Changed files

| File | Change |
|---|---|
| `base44/entities/LiveRun.jsonc` | **Additive schema change (approved design §8):** `checkpoint` object field (seq / at_ms / distance_m / clock{start_time_ms, paused_ms, pause_started_at_ms} / splits / route / last_point) and `abandoned` added to the status enum. RLS untouched. Design's `discard_requested` field was **omitted** — the discard flow sets `status:'abandoned'` + clears the checkpoint directly, so the field was dead schema; flagged here for review. |
| `src/hooks/useRunTracker.js` | Exposes `snapshot()` (read-only: clock state, carried distance, splits, downsampled route, last point; null before start) and `restore(payload)` (seeds distance/splits/route, reconstructs the exact RunClock via `fromState`, restarts the GPS watch, correct paused/active state — never touches `start_time`). GPS handling now drops fixes at or before the last recorded timestamp (monotonic guard → no duplicate points across a recovery boundary). `start()` refactored to share `startWatching()`; Stage A pause math untouched. |
| `src/hooks/useRunCheckpoint.js` | **NEW** — persistence scheduler: 1 s mirror tick (localStorage, synchronous, never blocks GPS), server flush every 20 s, immediately on km-crossing, pause, resume, start, and page hide/visibility-hidden; retry ×3 with backoff per flush, toast only after 3 consecutive failures; `guardedUpdate(patch)` (the `$nin`-terminal conditional write, used for ALL mid-run status writes); `setStartSeq` for recovery adoption; `clearMirror`. On `updated: 0` the hook fires `onTerminal` (follow the server record) — never treats a refused write as an error. |
| `src/components/live/RecoveryPrompt.jsx` | **NEW** — recovery screen: shows target, saved distance, saved active time, km-split count and checkpoint age; **Resume Run** (exact) / **Resume (approximate)** (legacy, with explicit disclosure) / **Discard** with a confirm step ("kept in your history as discarded, without results"). |
| `src/pages/LiveRunActive.jsx` | Loads recovery plan on open (`planRecovery`); renders the recovery screen for unfinished runs; Resume restores tracker + clock and continues from `seq+1`, flushing an adopted mirror to converge server/local; Discard writes `abandoned` + clears checkpoint (stays on screen on failure — never silently discarded); ALL mid-run writes (start/pause/resume/stop/discard) go through the guarded conditional write; on `updated: 0` at finish the server record is adopted instead of overwritten; `beforeunload` guard while active/paused; small terminal notice for `abandoned`. Music search also fires on recovery resume. |
| `tests/recoveryFlow.test.js` | **NEW** — 16 tests: `planRecovery` (exact/mirror-adoption/tie→server/corrupt-mirror/legacy/discard-only/terminal-null/invalid-checkpoint-fallback), checkpoint→reopen round-trips running **and** paused (identical elapsed, carried distance, carried splits, pause folded on resume), sequence continuation (`nextSeq`, stale/duplicate/out-of-order checkpoints, first-adoption-on-reopen), route dedupe across reopen, terminal immutability, JSON round-trip validity. |

### 3. Test results

- **Full suite: 13 files, 157/157 passed** (141 pre-existing + 16 new). **Production build: exit 0.**
- Live data-layer probes (concurrency + storage round-trip) as tabled above.

### 4. What is tested automatically vs. what needs a physical iPhone

**Automated:** clock restoration exactness (running + paused, incl. across recovery), pause-exclusion regression (Stage A suites unchanged and green), recovery planning (all modes incl. corrupt/missing data), seq ordering (stale/duplicate/out-of-order), terminal immutability rules, route dedupe and distance-carried semantics, live conditional-write atomicity and stale-write refusal (real backend).

**Physical iPhone only (per EXPORT-CHECKLIST §6, unchanged):** locked-screen tracking behaviour (F6/F7), backgrounding/interruption (incoming call) mid-run, HealthKit on-device import, and real-GPS behaviour of the monotonic guard and wake-lock interplay. Browser-refresh/crash recovery can be exercised in any desktop browser by starting a run and hard-reloading.

### 5. Guarantees and remaining risks

- **Guaranteed by the data layer (probed, not assumed):** terminal runs are write-protected — no checkpoint, status, or results write can apply to a `completed`/`abandoned` record; `updated: 0` is observable and acted on (adopt-server on finish, follow-server on terminal).
- **Loss bounds (unchanged from design):** guaranteed bound is the last *confirmed* server checkpoint + in-flight window (~20–40 s worst case). The localStorage mirror is best-effort and may not survive a force-kill or power loss; **no claim is made that page-hide handlers or localStorage guarantee persistence on force-quit/power loss.**
- **Residual races are safe by construction:** two devices stopping near-simultaneously → one wins the guarded write, the other adopts the server record; concurrent checkpoints are idempotent single-field writes.
- **Out of B2 scope by design (B3+):** offline final-pending flush, abandoned-run rendering in RunHistory/MyPlans, unfinished-run prompts on Home/Live tabs, native device pass.
- No changes to subscription logic, account deletion, IAP, or RLS. The only schema change is the additive `checkpoint` field + `abandoned` status from the approved design (plus the flagged omission of unused `discard_requested`).

Batch B2 is complete — awaiting review; B3 (offline flush + abandoned-history guard + Home/Live unfinished-run prompts) is next.

---

## Stage B / Batch B3 report (2026-10-13) — COMPLETE

**Schema / permission changes: NONE required.** Everything B3 needed already exists from B2 (the `checkpoint` field, the `abandoned` status, and the existing RLS). Nothing outside the approved scope was touched; no subscription or IAP work.

### 1. Changed files

| File | Change |
|---|---|
| `src/lib/runCheckpoint.js` | + `isUnfinishedRun(run)` — the single shared predicate all entry points use for unfinished-run detection (exactly the `planRecovery` eligibility set, so a prompt can never offer a run recovery can't serve). |
| `src/hooks/useRunCheckpoint.js` | + `online` listener: pending offline run data flushes immediately when connectivity returns. Idempotent (replayed checkpoint converges by seq; a refused write on a run that went terminal offline routes to `onTerminal`, never an error). |
| `src/hooks/useUnfinishedRun.js` | **NEW** — single source of truth for entry-point detection: server-side filter (`status ∈ {active, paused}`, owner-scoped by `created_by_id`), newest first, limit 1. Home and Live setup both consume it, so they can never disagree. |
| `src/components/live/UnfinishedRunPrompt.jsx` | **NEW** — entry-point prompt: Resume (opens the run's own recovery screen) + Discard with confirm. Discard is a guarded write (`$nin` terminal) — on failure the prompt stays and the run is never silently discarded; on `updated: 0` (run went terminal elsewhere) the prompt refreshes to follow the server record. |
| `src/pages/Home.jsx` | Renders the prompt (below the onboarding card); resolves by refreshing the shared query. |
| `src/pages/LiveRunSetup.jsx` | Renders the prompt; **Generate is disabled while an unfinished run exists** (the duplicate-creation prevention) with an explanatory hint; double-submission guard on the handler entry. |
| `src/pages/RunHistory.jsx` | Abandoned runs render distinctly: muted card, "Discarded" badge, no metric row (results never existed), explicit "cannot be resumed" copy, no Strava export. |
| `src/pages/LiveRunActive.jsx` | On reopen of a recoverable run, an adopted local mirror is converged to the server immediately (flush-on-reopen, before the user even chooses Resume) — idempotent and terminal-guarded. |
| `tests/b3Recovery.test.js` | **NEW** — 16 tests (see below). |

### 2. Automated tests (16 new)

Entry-point detection (shared predicate incl. `ready`/terminal/missing rejection and predicate↔planRecovery consistency) · abandoned runs not resumable (even with a valid checkpoint or a newer mirror) · offline-flush convergence (mirror adoption flagged, replayed flush idempotent with no seq regression, route replay introduces no duplicate points, corrupt mirror cannot poison, parse stable across retry) · adopted-mirror restore exactness (distance/clock/splits/last point) · completed-record immutability (planRecovery null even with stale data; guarded filter excludes every terminal status) · failed-discard retention (planRecovery pure, eligibility excludes terminal records) · multiple entry points pick at most one unfinished run from a mixed list.

**Full suite: 14 files, 177/177 passed. Production build: exit 0.**

### 3. Live data-layer probes (real backend, scratch records deleted after)

| Probe | Result |
|---|---|
| Offline flush replay: same checkpoint written twice via the guarded shape | 1 + 1 applied; stored record **deep-equal** the checkpoint — overwrite semantics, no duplication possible |
| Entry-point query shape (`$in` recoverable, owner-scoped) | Finds the active scratch run; no terminal records leak into detection |
| Discard: guarded write → then checkpoint write + resume (status flip) attempted | Discard applied; status `abandoned`, checkpoint null; **both later writes refused** (`updated: 0`) |
| Completion immutability: guarded finish → stale checkpoint, stale results overwrite, stale status flip attempted | Finish applied; **all three stale writes refused**; results untouched |

### 4. Validation checklist from the approval (all addressed)

- Offline checkpoint → reconnect → reopen → flush without duplicate runs or route points: unit-tested + probed (§3) + reconnect listener shipped.
- Multiple entry points into an unfinished run: shared hook/predicate, unit-tested (mixed-list picks exactly one).
- Discard success and failure; abandoned runs cannot be resumed: probed + unit-tested + UI.
- Completion followed by refresh/reopen remains immutable: probed (§3) + unit-tested.
- Retry/reconciliation idempotent, user-scoped, terminal-guarded: all writes remain conditional `updateMany` `$nin` terminal, owner-scoped by RLS + explicit owner filters.
- No silent discard on failure: prompt persists on error; `updated: 0` follows the server record.

### 5. Stage B is NOT claimed production-ready

Per instruction: the end-to-end test plan now lives in `src/native/STAGE-B-E2E-TEST-PLAN.md`, separating 🟢 automated (177 passing) · 🔵 live probes · 🖥️ desktop-browser manual passes (refresh/crash recovery, offline reconnect, two-tab finish race, route continuity visual) · **[DEVICE]** physical-iPhone items (locked-screen tracking, interruption, real GPS, force-kill recovery, HealthKit on device, cellular offline). The [DEVICE] list is the remaining gate — no production-ready claim until it completes.

Batch B3 is complete — awaiting review. No further batches started.