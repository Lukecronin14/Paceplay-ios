# PacePlay — Native iOS Export & TestFlight Checklist

Updated 15 October 2026: Apple Health is retained **read-only**. `native/patch-info-plist.sh` adds both Apple Health usage descriptions (`NSHealthShareUsageDescription`, `NSHealthUpdateUsageDescription`) and the HealthKit entitlement; `native/healthkit-bridge` provides the read-only native bridge (`src/lib/healthKit.js` is the JS wrapper). The `run-background-bridge` package is unchanged. Existing imported records stay covered by account deletion.

## Base44-generated iPhone packages

Base44's normal publishing **cannot** apply these native changes: `NSHealthShareUsageDescription`, `NSHealthUpdateUsageDescription` and the HealthKit entitlement are not editable in the Base44 interface, and this is documented as a known iOS build limitation. Source changes also cannot edit a downloaded, signed IPA. Do not upload the Base44-generated package while the app uses HealthKit — use the cloud build below.

## Simplest supported cloud build: Codemagic (no local Xcode)

`codemagic.yaml` at the repo root automates everything; the workflow is `paceplay-ios-app-store`.

1. **App Store Connect API key** — Users and Access → Integrations → App Store Connect API → generate a key with the App Manager role; download the `.p8` once.
2. **HealthKit capability** — Apple Developer portal → Identifiers → the app's App ID → enable HealthKit, then create/regenerate the App Store provisioning profile. The profile **must include HealthKit**, or the build fails entitlement validation. Re-upload the new profile to Codemagic afterwards.
3. **Codemagic setup** — Team integrations → Developer Portal: add the API key (Issuer ID, Key ID, `.p8`). Code signing identities: add an Apple Distribution certificate and the App Store profile. Confirm `bundle_identifier` in `codemagic.yaml` matches the app's bundle ID (`Florenceanne123` in `capacitor.config.json`).
4. **Build** — start the `paceplay-ios-app-store` workflow. It installs dependencies, builds the web bundle, creates the Capacitor iOS project, syncs `run-background-bridge` and `healthkit-bridge`, runs `native/patch-info-plist.sh`, signs and uploads the IPA to TestFlight.
5. **Verify the final IPA before relying on it** — in the built app bundle:
   - `codesign -d --entitlements - <App>.app` shows `com.apple.developer.healthkit`;
   - the bundle's `Info.plist` contains both `NSHealthShareUsageDescription` and `NSHealthUpdateUsageDescription`.
6. **On a physical iPhone** — the Apple Health permission prompt appears (read-only types only), workout import works, live GPS tracking, locked-screen behavior and music switching all work.

## Optional external build, when Xcode is available

1. Export the latest saved source. Keep an existing Capacitor project's bundle identifier, team and signing settings unchanged.
2. For a new Capacitor shell, copy `native/capacitor.config.json` to the project root and install Capacitor 5:
   ```bash
   npm install @capacitor/core@^5 @capacitor/cli@^5 @capacitor/ios@^5
   npm run build
   npm install ./native/run-background-bridge ./native/healthkit-bridge
   npx cap add ios
   npx cap sync ios
   ```
   In an existing project, skip `cap add ios` and keep its existing Capacitor version.
3. Run `bash native/patch-info-plist.sh`. It adds the live-run location description, background location/audio modes, the app privacy manifest, both Apple Health usage descriptions and the HealthKit entitlement (`App/PacePlay.entitlements`).
4. In Xcode, retain signing for the existing app target and enable the background modes required by the remaining plugin: Location updates and Audio, AirPlay, and Picture in Picture. Ensure the App ID has the HealthKit capability and the provisioning profile includes it.
5. Check the built app's privacy declarations match the data collected: location, Strava fitness data and the read-only Apple Health import.
6. On a physical iPhone, verify the Health permission prompt (read-only), workout import, live GPS tracking, pause/resume, locked-screen behavior, music switching and end-of-run teardown.
7. Increment the build number, archive for an iOS device and distribute through Xcode to App Store Connect/TestFlight.

See `native/README.md` for the two local native plugins.