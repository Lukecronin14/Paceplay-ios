# iOS background run support

Apple Health is retained **read-only** as of 15 October 2026: `native/healthkit-bridge` reads workouts, heart rate and routes and never writes to Apple Health (JS wrapper: `src/lib/healthKit.js`). `native/patch-info-plist.sh` adds both Apple Health usage descriptions and the HealthKit entitlement, and the build must be produced by the Codemagic cloud workflow (`codemagic.yaml`) because Base44's generated package cannot include those native settings. The `run-background-bridge` package supports GPS/background running. Previously imported records and their account-deletion cleanup are retained.

## Locked-screen runs (RunBackgroundBridge)

A second local Capacitor plugin (`RunBackgroundBridge`) makes **live runs keep working while the iPhone is locked**: background GPS tracking feeds the existing run tracker, and a background audio session keeps the webview's JavaScript alive so pace assessment and Spotify track switching continue. The web side (`src/lib/runBackground.js`) activates it automatically when running natively and is a no-op on the web, where Android is covered by wake lock + keep-alive audio.

> This plugin only takes effect in an externally exported Capacitor build, not the Base44-generated iOS package. Source changes here cannot modify entitlements in a downloaded IPA. If a newly generated package still fails Apple validation for missing health permission descriptions, contact Base44 support with the rejection.

### Setup (in the same exported project)

1. Install the plugin and add Background Modes:
    ```bash
    npm install ./native/run-background-bridge
    npx cap sync ios
    npx cap open ios
    ```
2. **Xcode → Signing & Capabilities → + Capability → Background Modes**, then tick **Location updates** and **Audio, AirPlay, and Picture in Picture**. Both are required: audio keeps the app process alive while locked; location keeps GPS running in the background.
3. **App/Info.plist** — add the location permission description (App Review requires it be specific):
    ```xml
    <key>NSLocationWhenInUseUsageDescription</key>
    <string>PacePlay tracks your GPS route, distance and pace during a live run, and keeps tracking (with music control) running while your screen is locked.</string>
    ```
    ("While Using" is sufficient — the plugin enables background location updates with the standard indicator, so no "Always" prompt is needed.)
4. The web side needs no changes: starting a live run in the Capacitor build activates the bridge, subscribes to GPS events, and disables it when the run ends.

### Verifying

1. On your iPhone (real device — the simulator does not do real GPS/background): start a Live Run, allow the location prompt.
2. Lock the screen and run/walk ~500 m. Unlock: the distance, pace and splits should reflect the whole period, not just the unlocked time.
3. While locked, the current Spotify song should still finish and the next segment's track should start (Spotify app keeps playing in the background; the bridge's audio session lets the app command it).
4. End the run — background tracking and the audio session stop.