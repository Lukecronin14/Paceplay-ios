# PacePlay — TestFlight build plan with read-only Apple Health

Updated 15 October 2026. Apple Health is retained **read-only** (workouts, heart rate, routes; PacePlay never writes to Apple Health). Spotify, Apple Music, Strava, parkrun planning and live-run tracking are unchanged.

## Current path: Codemagic cloud build (recommended)

Base44's normal publishing cannot add the Apple Health usage descriptions or the HealthKit entitlement to the package it generates — those native settings are not editable in the Base44 interface, and this is a documented iOS build limitation. Source changes cannot edit a downloaded, signed IPA either.

The supported route is the Codemagic cloud build configured in `codemagic.yaml` (workflow `paceplay-ios-app-store`), which needs no local Xcode:

1. Create an App Store Connect API key (App Manager) and connect it in Codemagic.
2. Enable the HealthKit capability on the app's App ID and regenerate the App Store provisioning profile (it must include HealthKit); upload the certificate and profile to Codemagic.
3. Run the workflow: it applies `native/patch-info-plist.sh` (both health usage descriptions + `App/PacePlay.entitlements`), syncs `run-background-bridge` and `read-only healthkit-bridge`, signs the IPA and uploads it to TestFlight.

Before relying on any upload, verify the built IPA: the entitlements show `com.apple.developer.healthkit` and the Info.plist contains both health usage descriptions. Full steps in `native/EXPORT-CHECKLIST.md`.

## Optional path when Xcode becomes available

Use `native/EXPORT-CHECKLIST.md` and the existing project's signing settings. Run `bash native/patch-info-plist.sh` after `cap add ios`/`cap sync ios` — it adds the location description, background modes, privacy manifest, both Apple Health usage descriptions and the HealthKit entitlement. A previously configured project must have its signing settings intact and the HealthKit capability + profile in place before archiving.

Previously imported records are preserved privately and remain covered by account deletion.