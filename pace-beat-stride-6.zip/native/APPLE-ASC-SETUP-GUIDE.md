# Phase 0 — App Store Connect Setup Guide & Prerequisites

Companion to `APPLE-IAP-MIGRATION-PLAN.md` (decisions confirmed 2026-10-12).
This phase is **configuration on Apple's side only** — no production code or
payment configuration in PacePlay changes. Estimated effort: 2–4 hours plus
Apple-side processing delays.

Confirmed parameters: StoreKit 2 (iOS 15+) · £2.00/month auto-renewable ·
7-day free intro trial · no Family Sharing · sign-in required to purchase.

---

## 1. Prerequisites checklist (verify before starting)

| # | Prerequisite | Where to verify | Blocker level |
|---|---|---|---|
| 1.1 | Apple Developer Program membership active for Team `CN782GYTY3` | developer.apple.com → Membership | Hard blocker |
| 1.2 | App record exists in App Store Connect with bundle id `Florenceanne123` | ASC → My Apps → PacePlay | Hard blocker |
| 1.3 | **Paid Applications Agreement: Active** (ASC → Agreements, Tax, and Banking) — IAP products cannot be created or sold without it | ASC → Business | Hard blocker |
| 1.4 | Banking details + tax forms completed | ASC → Business | Hard blocker (needed before sales, not before setup — can run in parallel) |
| 1.5 | HealthKit App ID capability still enabled (existing requirement, unchanged by IAP) | developer.apple.com → Identifiers | Context only |
| 1.6 | Access to export the app code (Builder plan) — documented in `EXPORT-CHECKLIST.md`; needed in Phase 2, not now | Builder dashboard | Later phase |
| 1.7 | A physical iPhone running iOS 15+ and Xcode 15+ for sandbox testing (Phase 4) | — | Later phase |

## 2. Create the subscription product

ASC → My Apps → PacePlay → **Features → In-App Purchases** (requires 1.3 active):

1. **Subscription Group** → Create: name **"PacePlay Premium"**
   (reference name only; users never see it).
2. Inside the group → **Create Subscription**:
   - Reference Name: `PacePlay Premium Monthly`
   - Product ID: **`paceplay_premium_monthly`**
     (must match the `APPLE_PRODUCT_IDS` allowlist in Phase 1 — do not change it later)
   - Subscription Duration: **1 month**
   - Family Sharing: **OFF** (confirmed decision)
3. **Subscription Price**: set base storefront **United Kingdom → £2.00** and
   let ASC auto-generate other storefronts (or set USD explicitly first, then UK).
4. **Localisation** (add at least en-GB):
   - Display Name: `PacePlay Premium`
   - Description: `Terrain-adaptive running playlists, live pace-matched music, and full run history.`
5. **Review screenshot**: an app screenshot showing the premium experience
   (the Subscribe screen works). Required before the product can be submitted.
6. **App Review notes**: leave default; the product is submitted with the app
   build in Phase 5, not now.

> ⚠️ Do **not** submit the product for review yet. Leave it in
> "Ready to Submit" until Phase 4 testing is complete.

## 3. Introductory offer (replaces the custom promo trial on iOS)

On the subscription's pricing page → **Offer type: Introductory offer**:

- Offer: **Free trial**
- Duration: **7 days** (confirmed)
- Eligibility: **New subscribers only** (Apple enforces one intro offer per
  Apple ID per subscription group automatically)
- The offer can be added, changed or removed at any time in ASC without an
  app update.

Offer codes (for comped access) can be created later at
**Features → Offer Codes**; nothing needed at Phase 0.

## 4. Server keys (secrets for Phase 1)

1. ASC → **Users and Access → Integrations → In-App Purchase** →
   **Generate In-App Purchase Key**. Name it `PacePlay IAP Server Key`.
   - **Download the .p8 immediately** — Apple lets you download it exactly once.
   - Note the **Key ID** shown beside it.
2. On the same Integrations page, note the **Issuer ID**.
3. Later (after Phase 1 code exists) set these as PacePlay secrets — values only
   from this page, never shipped in the app bundle:
   - `APPLE_IAP_PRIVATE_KEY` (contents of the .p8)
   - `APPLE_IAP_KEY_ID`
   - `APPLE_IAP_ISSUER_ID`
   - `APPLE_IAP_BUNDLE_ID` = `Florenceanne123`
   - `APPLE_PRODUCT_IDS` = `paceplay_premium_monthly`

Do not create or set these secrets yet — Phase 1 prepares the functions that
read them; the .p8 can still be generated any time.

## 5. App Store Server Notifications V2

1. ASC → PacePlay → **App Information → App Store Server Notifications**
   (or Features → In-App Purchases → Manage, depending on ASC version):
   - **Version: V2**
   - **Production Server URL:**
     `https://pace-beat-stride.base44.app/functions/apple-notifications-webhook`
   - **Sandbox Server URL:** same URL
2. The webhook function is built in Phase 1 and registered in Phase 3 — Apple
   accepts the URL now and retries failed deliveries, so registering early is
   safe. Expect "Test Notification" to fail until the function is deployed;
   run the URL check again after Phase 3.

## 6. Sandbox testers (Phase 4 prerequisites)

ASC → **Users and Access → Sandbox → Testers** → **+**:

- Create **at least two** testers with different email addresses (one simulates
  "existing Apple ID with purchase", one "fresh account"). Any valid-format
  email works — it does not need to be a real mailbox.
- First Name / Last Name required; the password you set is the sandbox Apple ID
  password.
- No special entitlement needed — sandbox purchases are free and renewals are
  accelerated (1 month → 5 minutes in sandbox; expiry tests use device clock
  changes).

## 7. StoreKit configuration file (local Xcode testing, Phase 2)

Created during Phase 2 inside the exported Xcode project
(`Products.storekit`): declares `paceplay_premium_monthly`, 1-month
subscription, £2.00, 7-day free trial, family sharable = false. Mirrors the ASC
product exactly. **Only for local testing — App Store / TestFlight builds use
the real ASC products.**

## 8. What NOT to do in Phase 0 (guardrails)

- ❌ Do **not** submit the subscription product or the app for review.
- ❌ Do **not** touch the existing Base44 Payments (Wix) configuration,
  secrets, webhook registration or `Subscription` records.
- ❌ Do **not** enable any purchase UI in the app (the native branch stays
  flag-gated to internal builds through Phase 4).
- ❌ Do **not** remove the 3.1.1 "subscribe on the web" notice — it remains
  until the native purchase flow passes access-control testing.
- ❌ Do **not** reuse the existing Apple Music key (`APPLE_MUSIC_*` is a
  MusicKit key, unrelated to IAP — a separate In-App Purchase key is required).

## 9. Phase 0 exit criteria

- [ ] Paid Applications Agreement Active (1.3)
- [ ] Subscription group + `paceplay_premium_monthly` created, £2.00, priced
- [ ] 7-day free trial intro offer configured
- [ ] Review screenshot attached, product in "Ready to Submit"
- [ ] .p8 In-App Purchase key downloaded + Key ID and Issuer ID recorded
- [ ] Notifications V2 URLs registered (both environments)
- [ ] 2+ sandbox testers created
- [ ] Product ID recorded for the `APPLE_PRODUCT_IDS` allowlist

Then Phase 1 (backend foundation) can begin on approval.