# PacePlay — Apple In-App Purchase Migration Assessment

Read-only assessment produced 2026-10-12. No production code or payment
configuration was changed. Implementation waits for approval.

---

## 1. Current system inventory (verified in source)

### Payment flow (Wix/Base44 Payments, web)
| Piece | Location | What it does |
|---|---|---|
| Checkout | `base44/functions/create-checkout/entry.ts` | `createCheckout` action: auth'd session user → Wix checkout session (£2.00/month), sets `Subscription.status = "pending"` + `checkout_id`; `cancelSubscription` and `getSubscriptionStatus` actions call Wix subscription endpoints |
| Webhook | `base44/functions/wix-payments-webhook/entry.ts` | JWT-verified (RS256, `WIX_PAYMENTS_WEBHOOK_PUBLIC_KEY`) `order_approved` → `status:"active"` + `subscription_id`; also `subscription_contract_canceled` → `canceled`, `_expired` → `expired`; idempotent via `updateMany` on `checkout_id`/`subscription_id` |
| Promo codes | `base44/functions/redeem-promo/entry.ts` + `base44/shared/trialEligibility.js` | Server-side code match from secrets (`PROMO_CODE_FREE`, `PROMO_CODE_TRIAL`); grants `free` or 30-day `trial` with dates; prior-trial guard. **`PROMO_CODE_TRIAL` secret is still unset** (known issue) |

### Entitlement model
| Piece | Location | Behaviour |
|---|---|---|
| `Subscription` entity | `base44/entities/Subscription.jsonc` | One record per user (in practice). Statuses: `trial / pending / active / canceled / expired / free`. Fields: `checkout_id`, `subscription_id`, `trial_start_date`, `trial_end_date` |
| RLS | same file | Read: owner-or-admin. **Create/update/delete: admin-only** — verified live earlier this session (writes refused when no rule matched, even for the builder identity). All client writes already impossible; every write goes through the four service-role call sites above |
| Entitlement logic | `src/lib/subscriptionAccess.js` (+ `tests/subscriptionAccess.test.js`, 13 tests) | `pickSubscriptionRecord` (dedupe), `computeEntitlements`: access = `active` ∨ `free` ∨ unexpired `trial`; `pending` grants nothing |
| Hook | `src/hooks/useSubscription.js` | React Query on `Subscription.list()`, `startCheckout` → invoke `create-checkout`, `cancelSubscription` |
| UI gates | `src/components/layout/AppLayout.jsx` (`authorizedForPath`), `src/components/subscription/FeatureLock.jsx`, `src/components/subscription/SubscriptionGuard.jsx`, Home redirect to `/subscribe`, `src/pages/Subscribe.jsx`, `src/pages/Account.jsx` status row | **All frontend-only.** Server-side enforcement today = RLS on `Subscription` only; feature data (RunPlan, LiveRun, HealthRun, integrations) is gated by UI alone |
| Account lifecycle | `base44/functions/delete-account/entry.ts` | Deletes LiveRun, RunPlan, MusicPreference, **Subscription**, IntegrationSecret rows and token fields |
| Native posture | `src/pages/Subscribe.jsx` (`isNativeIOS`), `src/lib/native.js`, `native/capacitor.config.json`, `native/EXPORT-CHECKLIST.md` | Capacitor 5 webview over the live web app; bundle id `Florenceanne123`, team `CN782GYTY3`; native build already refuses the web checkout and shows a 3.1.1-compliant "subscribe on the web" notice; two local ObjC Capacitor plugins exist (HealthKitBridge, RunBackgroundBridge) as the plugin pattern to follow |

### Dependency map (everything that touches the subscription system)
`Subscription.jsonc` ← `create-checkout` ← `wix-payments-webhook` ← `redeem-promo` ← `delete-account` ← `src/lib/subscriptionAccess.js` ← `src/hooks/useSubscription.js` ← `AppLayout` / `SubscriptionGuard` / `FeatureLock` / `Home` / `Subscribe` / `Account` ← `src/App.jsx` routes (`/subscribe`, `/thank-you`). Secrets: `WIX_PAYMENTS_API_KEY`, `WIX_PAYMENTS_SITE_ID`, `WIX_PAYMENTS_WEBHOOK_PUBLIC_KEY`, `PROMO_CODE_FREE` (+ unset `PROMO_CODE_TRIAL`). Webhook registration: ORDER_APPROVED, SUBSCRIPTION_CANCELED, SUBSCRIPTION_ENDED.

---

## 2. Target architecture (Apple native auto-renewable subscriptions)

Principle: **Apple owns the money, the backend owns the truth.** The app never
asserts a purchase; it submits Apple-signed data, and the backend verifies the
JWS chain to Apple's root CA before any entitlement is written.

```
iPhone (StoreKit 2)                    Base44 backend                       Apple
──────────────────                     ──────────────                       ──────
purchase / restore ──signedTransaction(JWS)──► apple-purchases (verify JWS,
                                                x5c→Apple Root CA, bundle id,
                                                product allowlist, env)
                                       └─► upsert ApplePurchase
                                           (keyed by original_transaction_id,
                                            linked to user via appAccountToken)
                                       └─► return authoritative entitlement

App Store ──App Store Server Notifications V2 (signedPayload JWS)──►
                                       apple-notifications-webhook
                                       (DID_RENEW / EXPIRED / GRACE_PERIOD_EXPIRED
                                        / REFUND / REVOKE / OFFER_REDEEMED /
                                        DID_FAIL_TO_RENEW / SUBSCRIBED …)
                                       └─► update ApplePurchase, idempotent
                                            on latest_transaction_id

app launch / foreground ──► apple-purchases (getEntitlements) ──► merged
                            entitlement = max(web, apple) rendered by
                            useSubscription; same value the server gates on
```

### Key mechanisms per requirement
1. **Apple handles billing** — StoreKit 2 `Product.purchase()` for the
   auto-renewable product; no payment handling in app or backend.
2. **Backend verification** — `apple-purchases` verifies the
   `signedTransaction` JWS: x5c certificate chain pins to **Apple Root CA-G3**,
   `bundleId` matches, `productId` in the configured allowlist, `environment`
   read from the payload (sandbox vs Production selects the App Store Server API
   base URL). Client-reported state is never trusted. Where a notification or
   re-check is needed, the backend calls the **App Store Server API** (Get All
   Subscription Statuses / Get Transaction Info) with an ES256 API-key JWT.
3. **Account association** — the app passes the signed-in user's
   `appAccountToken` (a per-user UUID) into every purchase and re-submits it on
   restore; the backend resolves entitlements to accounts from
   `appAccountToken`, cross-checked against **Get App Transaction Info / Set
   App Account Token** so a purchase made before sign-in is claimed at
   sign-in. One Apple `original_transaction_id` maps to exactly one account at
   a time; a later claim from a different account supersedes it (revoking the
   earlier account's entitlement).
4. **Restore / reinstall / other device** — `Transaction.currentEntitlements`
   on any device + backend re-verification; purchases live in the Apple ID, so
   sign-in on another device + restore → verify → same entitlement.
5. **Lifecycle** — notifications mapped: `DID_RENEW`/`OFFER_REDEEMED` → active
   with `expires_date`; `DID_FAIL_TO_RENEW`+`GRACE_PERIOD` → access kept during
   Apple's grace period; `GRACE_PERIOD_EXPIRED` → suspended;
   `EXPIRED` → expired; `REFUND`/`REVOKE` → immediate revocation (refund also
   backstops via Get Refund History); `CONSUMPTION_REQUEST` → Send Consumption
   Information. Idempotency: processed `notificationUUID` log + monotonic
   `latest_transaction_id` compare, so redelivered/out-of-order events can't
   roll state backwards.
6. **Server-side enforcement** — `apple-purchases` (and the merged
   `entitlements` action) is the single authoritative source; new
   `base44/shared/entitlement.js` computes the merged verdict (pure, unit
   tested) and is imported by the backend functions so the same code decides on
   the server. Concretely: `run-summaries` gains an entitlement guard, and
   playlist-generation moves its gate check to a backend call. Honest
   limitation: RLS cannot read across entities, and the LLM playlist call is a
   frontend SDK call — full server enforcement of *feature* endpoints means
   routing generation through backend functions (Phase 6 option) or accepting
   UI-level gating there with server-verified entitlement data. Decision needed
   (see §7).
7. **Existing data untouched** — nothing in the Wix flow, `Subscription`
   records, integrations, or run data changes in Phase 1–5. Web subscriptions
   keep working exactly as today; `computeEntitlements` stays intact and the
   merged entitlement **adds** Apple access on top.
8. **No duplicates / no revocation** — separate `ApplePurchase` entity; the
   merge rule is `hasAccess = webEntitlement.hasAccess || appleEntitlement.hasAccess`;
   neither source can cancel the other. Only Apple notifications write Apple
   entitlements; only the Wix webhook writes web ones.
9. **Promo codes → Apple offers** — the custom trial flow is replaced on iOS by
   (a) **introductory offer** (e.g. first month free, one per Apple ID,
   eligibility handled by Apple) and (b) **offer codes** (one-time codes
   redeemed in-app via `offerCodeRedemption` or a redemption URL) for
   comped/grant access. `PROMO_CODE_FREE`-style permanent grants have no direct
   Apple equivalent (offer codes support free/recurring offers) — keep the web
   promo UI as-is for web users, and use ASC offer codes for comped iOS users.
   This also retires the unset-`PROMO_CODE_TRIAL` blocker on the iOS path.
10. **ASC configuration, code, secrets, tests** — enumerated in §5.

### Data model
New entity `base44/entities/ApplePurchase.jsonc` (Subscription stays untouched):

```
user_id                     — linked PacePlay account (from appAccountToken)
original_transaction_id     — natural key (upsert key)
latest_transaction_id       — ordering + idempotency
product_id, environment     — allowlisted; sandbox|Production
status                      — active|grace_period|billing_retry|expired|revoked|refunded
expires_date                — ISO
purchase_date, revoked_date, refund_date
auto_renew_status, in_billing_retry, grace_period_expires_date
offer_type, offer_identifier   — intro offer / offer code tracking
last_notification_type, last_notification_uuid
```
RLS mirrors Subscription: read owner-or-admin, all writes admin-only (service
role only). Web `Subscription` and `ApplePurchase` never cross-write.

### New backend surface
| Function | Purpose |
|---|---|
| `apple-purchases` | Client + internal: `verifyTransaction` (JWS → verified upsert), `entitlements` (authoritative merged check), `restore` (appAccountToken claim / re-link), `startOfferCodeRedemption` glue |
| `apple-notifications-webhook` | Notifications V2 endpoint at `https://pace-beat-stride.base44.app/functions/apple-notifications-webhook`; verify signedPayload, dispatch by `notificationType`/`subtype`, idempotent |
| `base44/shared/appleJWS.js` | JWS verification: x5c chain → Apple Root CA-G3 pin, ES256, payload extraction (shared by both functions) |
| `base44/shared/entitlement.js` | Pure merged entitlement logic + Apple status mapping (unit tested in `tests/`) |

New native plugin `native/storekit-bridge/` (Swift + Capacitor, following the
existing plugin layout): `initialize`, `getProducts`, `purchase(productId,
appAccountToken)`, `currentEntitlements` → returns raw `signedTransaction` JWS
strings, `restore`, `redeemOfferCode`, transaction-updates listener.
JS side: `src/lib/storeKit.js` + `src/hooks/useApplePurchases.js`.

### App Store Connect configuration (builder action, no code)
1. Subscription group **"PacePlay Premium"**; auto-renewable product
   `paceplay_premium_monthly`, £2.00/month (mirrors web price — commission
   difference noted below), localised descriptions.
2. Introductory offer (e.g. 1 month free, first-time subscribers) + offer codes.
3. **In-App Purchase Key** (.p8) for App Store Server API → secrets.
4. App Store Server Notifications **V2** URL: production + sandbox → the
   webhook URL above.
5. Sandbox tester accounts; StoreKit configuration file for local testing.

### Secrets (set via platform Secrets, never in code)
`APPLE_IAP_PRIVATE_KEY` (p8 contents), `APPLE_IAP_KEY_ID`,
`APPLE_IAP_ISSUER_ID` (ASC API key issuer), `APPLE_IAP_BUNDLE_ID`
(`Florenceanne123`), `APPLE_PRODUCT_IDS` (allowlist). Verification of Apple's
JWS needs **no secret** (public chain); the secrets above are only for calling
the App Store Server API. Existing Wix secrets stay untouched.

### Library choice
Apple's official TypeScript **App Store Server Library** (`app-store-server-library`
npm) would cover JWT creation and JWS verification; it must run in the Deno
backend runtime. Fallback (and default plan): hand-rolled verification in
`base44/shared/appleJWS.js` using `@noble/curves` + `@noble/x509`-style pure-JS
cert parsing, pinned Apple Root CA-G3 (public, vendored as a constant). This is
the riskiest novel code and gets the deepest unit tests. Decision noted in §7.

---

## 3. Phased migration & testing plan

**Phase 0 — App Store Connect prep (no app change).** Products, offers, p8 key,
notifications URL, sandbox testers. Blocking prerequisite; do first.

**Phase 1 — Backend foundation (inert until Phase 2 flag).**
`ApplePurchase` entity + RLS; `shared/appleJWS.js` + `shared/entitlement.js`;
`apple-purchases` and `apple-notifications-webhook` functions; vitest suites
(JWS verification against fixtures — real sandbox JWS captured in testing;
entitlement merge; notification dispatch table; idempotency ordering).
Production behaviour unchanged — nothing calls the new code yet.

**Phase 2 — Native plugin + purchase UI behind a flag.** `storekit-bridge`
plugin; `src/lib/storeKit.js`; `src/hooks/useApplePurchases.js`; Subscribe page
renders native purchase + Restore Purchases + offer-code redemption on
`isNativeIOS()` (web users see the unchanged Wix flow); merged entitlement in
`subscriptionAccess.js` + `useSubscription.js`; Account page shows Apple
subscription state + "Manage in App Store" link. Flag default: on only in
native builds — web checkout untouched.

**Phase 3 — Notifications V2.** Register URL in ASC; `Request a Test
Notification`; handler in production URL; verify sandbox notifications
(`environment` field distinguishes).

**Phase 4 — Sandbox + TestFlight verification on device.** Purchase, renewal
(forward clock), restore on reinstall + second device + different account sign-in,
cancel → EXPIRED, billing failure → grace period kept then GRACE_PERIOD_EXPIRED,
refund → immediate lock, revoke (family sharing if enabled), offer code and
intro offer redemption, existing web subscriber still has access, deleted
account re-signup can claim purchase via appAccountToken re-link.

**Phase 5 — Ship & coexist.** TestFlight → App Review (native subscription UI is
the required 3.1.1 posture; web checkout only reachable from browsers).
Existing web subscribers: nothing changes, Wix webhook stays live. No data
migration needed — none possible for billing; Apple and web entitlements
coexist indefinitely by design.

**Phase 6 — Optional later cleanups (only if approved).** (a) Move playlist
generation behind backend entitlement gate for true server-side feature
enforcement; (b) deprecate web checkout for iOS-originated users entirely
(native only already does this); (c) retire web promo codes if Apple offers
prove sufficient.

### Existing subscribers (requirement 8)
- Web (`Subscription`) records: **no writes, no migration, no deletion**. Their
  entitlement continues to flow from the unchanged Wix webhook path.
- New Apple purchases create **new** `ApplePurchase` rows only.
- A user with both (e.g. paid web sub whose Apple sub lapses, or vice versa):
  merged access = union; expiry of one never removes the other. Documented in
  the merge logic + tests.
- Web "subscribe in your browser" notice for native users is replaced by the
  native purchase UI once Phase 2 ships — that is the only visible change.

### Promo-code treatment (requirement 9)
- iOS: introductory offer + offer codes replace the custom trial.
- Web: `redeem-promo` and the Subscribe promo UI stay as-is (untouched in this
  migration). The `PROMO_CODE_TRIAL` secret remains unset; completing those
  tests is **not** on the critical path and is skipped unless Phase 4 testing
  reveals a dependency.

---

## 4. Estimated complexity

**Large.** ~2–3 weeks of focused work across phases:
- Phase 1 (backend + crypto + tests): highest technical risk (JWS chain
  verification in Deno) — 3–4 days.
- Phase 2 (native plugin, Swift/StoreKit 2 + UI): 4–5 days, includes StoreKit
  2's iOS 15+ constraint — current target supports iOS 15+ recommended
  (Capacitor 5 min is iOS 13; deployment target must become 15.0+ or use
  StoreKit 1 fallback — decision below).
- Phase 3–5 (notifications + device testing + submission): 4–6 days incl.
  Apple's sandbox lag (renewals compress to minutes in sandbox, expiry testing
  needs clock changes).

## 5. App Store Connect config checklist (builder)
☐ Subscription group + monthly product + price  ☐ Intro offer + offer codes
☐ In-App Purchase key (.p8) → secrets  ☐ Notifications V2 URLs (prod+sandbox)
☐ Sandbox testers  ☐ StoreKit config file  ☐ Deployment target ≥ iOS 15
☐ Review notes updated (IAP replaces the "subscribe on web" notice)

## 6. Exact files (implementation blueprint, unchanged until approved)
**New:** `base44/entities/ApplePurchase.jsonc` · `base44/functions/apple-purchases/entry.ts` ·
`base44/functions/apple-notifications-webhook/entry.ts` · `base44/shared/appleJWS.js` ·
`base44/shared/entitlement.js` · `native/storekit-bridge/{package.json, ios/*}` ·
`src/lib/storeKit.js` · `src/hooks/useApplePurchases.js` · `tests/appleEntitlement.test.js` ·
`tests/appleJWS.test.js` · `tests/appleNotifications.test.js`
**Changed:** `src/lib/subscriptionAccess.js` (merge fn) · `src/hooks/useSubscription.js` ·
`src/pages/Subscribe.jsx` (native branch) · `src/pages/Account.jsx` (Apple status) ·
`src/App.jsx` (no new route needed) · `base44/functions/delete-account/entry.ts` (also clear
ApplePurchase rows + release appAccountToken claim) · `native/EXPORT-CHECKLIST.md`
(IAP capability, secrets, ASC steps) · `base44/functions/run-summaries/entry.ts`
(entitlement gate, Phase 6 option)
**Unchanged:** `Subscription.jsonc`, `create-checkout`, `wix-payments-webhook`,
`redeem-promo`, all run/integration entities and functions.

## 7. Decisions required from you
1. **Deployment target**: require iOS 15+ for StoreKit 2 (recommended), or
   support iOS 13/14 with a legacy receipt fallback (extra work)?
2. **Apple's library vs hand-rolled JWS verification** in the Deno backend
   (default plan: hand-rolled with fixture tests)?
3. **Pricing on Apple**: keep £2.00/month single product, or add annual +
   intro offer length (e.g. 1 month free)? Apple takes 15–30% commission — the
   net differs from web; keep prices equal or adjust?
4. **Grace period length** in ASC (default Apple-recommended settings ok?).
5. **Server-side feature enforcement depth**: accept backend gating on the
   server functions only (playlist generation stays UI-gated), or approve the
   Phase 6 refactor of playlist generation into a backend function?
6. **Family Sharing**: enable for the subscription (affects revoke handling) —
   yes/no?
7. Confirm **native users must be signed in** to purchase (required for
   appAccountToken account association; store page would otherwise be
   inaccessible to them).

---

## 8. Decisions confirmed (2026-10-12)

1. **Minimum iOS: 15+** — StoreKit 2 only, no legacy receipt fallback.
2. **Verification: official Apple library preferred** (`app-store-server-library`
   npm). Phase 1 runs a fixture test in the Deno backend runtime first; the
   hand-rolled JWS verification in `shared/appleJWS.js` is the fallback only if
   the library is not reliable there. Either way: chain → Apple Root CA-G3,
   bundleId, productId allowlist, `environment` from the signed payload — never
   a client assertion alone.
3. **Pricing: £2.00/month only at launch.** Annual comes later. Introductory
   offer: **7-day free trial** (new subscribers, once per Apple ID), configured
   in App Store Connect; duration can change later without code.
4. **Family Sharing: OFF at launch.** Simpler ownership; revoke handling limited
   to refunds/cancellations.
5. **Enforcement: phased, with a hard launch gate.** Apple purchases are NOT
   enabled until critical premium operations have server-side entitlement
   checks. Revised order:
   - Phase 1 — backend foundation (entity, JWS verification, entitlement merge, tests)
   - **Phase 1.5 (NEW) — server-side enforcement**: entitlement guard on
     `run-summaries` and every other premium backend operation; migrate the
     playlist-generation gate to a server-verified check where necessary.
     Launch gate verified by a test proving an unentitled caller is refused by
     the backend, not just the UI.
   - Phase 2 — native plugin + purchase UI (flag-gated to internal builds)
   - Phase 3 — notifications V2 → Phase 4 — sandbox/TestFlight → Phase 5 — ship.
   Purchase flow and access control are tested together before any production
   enablement.
6. **Sign-in required to purchase** — confirmed (needed for account association).
7. **appAccountToken policy (hard requirement):** a **stable, server-generated
   UUID per PacePlay user**, minted by a backend function
   (`crypto.randomUUID()`), stored on the user's record, read by the client for
   the purchase call only. The client can never choose or forge it; never an
   email address. On account deletion the token is released so a future account
   on the same Apple ID re-links cleanly.
8. **Safeguards confirmed:** web and Apple subscriptions remain separate
   systems; entitlements recognise both (union); no automatic cancellation or
   migration of existing Wix subscribers; existing `Subscription` records and
   the Wix webhook path are untouched throughout.

Phase 0 deliverable (ASC setup guide + prerequisites): `native/APPLE-ASC-SETUP-GUIDE.md`.

---

## 9. Webhook authentication design (Phase 3 acceptance criteria)

The notifications endpoint is publicly reachable, and every request is treated
as untrusted regardless of source IP or headers:

1. **Everything from the signed payload only.** The request body is
   `{signedPayload: <JWS>}`. `notificationType`, `subtype`, and all transaction
   data are read exclusively from inside the verified JWS — no unsigned body
   field is ever trusted.
2. **Full JWS verification** (shared module, unit-tested): x5c chain validated
   to the pinned Apple Root CA-G3 cert, chain order and validity windows
   checked, signature verified with the leaf public key.
3. **Identifier checks before processing:** `bundleId === expected bundle`,
   `environment` matches the route the notification arrived on (Production
   URL → "Production", Sandbox URL → "Sandbox"); mismatches are rejected and
   logged, not applied.
4. **Idempotency (Apple retries, sometimes concurrently):** dedupe on the
   payload's `notificationUUID`, and apply state changes keyed by
   `latest_transaction_id` only if not already applied. Duplicate delivery →
   200 with no state change.
5. **Out-of-order safety with refund precedence:** notifications are applied
   by reconciling the incoming `signedTransactionInfo` against the stored
   record — using Apple's signed data (transaction revision, `expires_date`,
   `revocation_date`, status) plus App Store Server API lookups where the
   notification alone is ambiguous — not raw arrival timestamps. Two rules:
   - **Out-of-order noise must not regress state**: a retried or older event
     (e.g. EXPIRED arriving after a newer RENEWAL that the signed data shows
     as active) must never roll a transaction backwards.
   - **Terminal negative states always win**: a genuine REFUND or REVOCATION
     is reflected immediately even if it arrives after a newer renewal event,
     because it revokes that specific transaction. The stored record is
     per-transaction (`original_transaction_id` + `transaction_id`), so
     revocation of one transaction never silently "expires away" when a later
     event for a different transaction arrives, and a later renewal creates a
     new transaction that is evaluated independently of the revoked one.
6. **Fast, logged 2xx** for handled/known payloads; permanent 4xx for
   malformed payloads so Apple stops retrying poison messages; 5xx only for
   transient storage errors.

## 10. Entitlement fallback rules (Phase 1 acceptance criteria)

Web and Apple entitlements are evaluated **independently** and merged as a
union; neither can create, extend, nor cancel the other:

1. An Apple purchase grants access **only** while its signed transaction data
   shows it active: `expires_date` in the future, status not refunded/revoked,
   and billing-retry/grace states handled explicitly (grace → brief access;
   billing-retry → access until `expires_date` per Apple's guidance, never
   beyond it).
2. **An expired Apple subscription grants nothing by itself.** Expiry removes
   the Apple-side grant only.
3. **A refund/revocation touches only the `ApplePurchase` record.** It must
   never write to, cancel, or alter a `Subscription` (Wix) record. A user with
   a valid, separately-paid Wix subscription keeps full access after any Apple
   refund.
4. Conversely, a cancelled Wix subscription does not touch `ApplePurchase`.
5. The union check runs server-side on every entitlement evaluation: access =
   (valid Wix record) OR (verified active Apple transaction). Each check
   re-derives from its own source of truth at evaluation time — no cached or
   combined status field that one side could corrupt.
</content>