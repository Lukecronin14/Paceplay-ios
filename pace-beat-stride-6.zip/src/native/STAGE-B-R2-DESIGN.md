# Stage B / R2 — Active-Run Checkpointing & Recovery (DESIGN — awaiting approval)

**Date:** 2026-10-13 · **Status:** Design only. No code changed. Stage A closed; IAP migration remains paused.

---

## 1. Current failure points (source inspection)

1. **Route and metrics are written only at stop** — `LiveRunActive.jsx` `handleStop` (L388–396) is the sole writer of `route`, `actual_distance_km`, `actual_time_min`, `actual_pace_per_km`. Start/pause/resume write only `status` (L325–336, 347, 366). A crash, force-close, or refresh mid-run loses the entire run.
2. **Navigation unmounts the run page** — in `AppLayout.jsx` the `/live-run/:id` route renders inside the `AnimatePresence` outlet (L153–165); tapping any bottom-nav tab or `PageHeader onBack` (L505) unmounts `LiveRunActive`. `useRunTracker` cleanup clears the GPS watch and timer (L147–156); there is no `beforeunload`/navigation guard. The record stays `status:'active'` forever with no data.
3. **Tracker state lives only in refs** — `positionsRef`, `splitsRef`, `totalDistanceRef`, `clockRef` (`useRunTracker.js` L14–26). Nothing readable outside the component.
4. **No persisted pause accounting** — `LiveRun` stores only status flips (`active`/`paused`). `RunClock`'s `pausedMs` / `pauseStartedAtMs` are never written to the record, so a reopened run cannot reconstruct elapsed time without either counting paused wall-clock time (regression of Stage A's F1) or losing time.
5. **Stop has no completed-guard** — a stale instance (two tabs, or a resumed page after a race) could overwrite a `completed` record's results.
6. **Recovery detection is absent** — no screen or Home/Live-tab check offers resume for a run left in `active`/`paused`; a user re-entering `/live-run/:id` sees the "ready" view and starting again would overwrite `start_time` on the same record.

**LiveRun entity (relevant current shape):** `status: ready|active|paused|completed`, `start_time`, `route[]`, `actual_*` fields; RLS owner-or-admin on read/update (already correctly scoped). No checkpoint fields exist today.

---

## 2. Proposed state model

### New LiveRun fields (additive; existing records simply lack them)

```
checkpoint: {                    // last durable checkpoint (object field)
  seq            number         // monotonically increasing; concurrent-save arbiter
  at_ms          number         // wall-clock ms of the checkpoint
  distance_m     number         // carried distance state (authoritative, not recomputed)
  clock: {
    start_time_ms   number      // mirrors run.start_time (epoch ms)
    paused_ms       number      // completed pause durations (RunClock.pausedMs)
    pause_started_at_ms number|null  // pause in progress at checkpoint
  }
  splits         array          // km splits so far (same shape as tracker.splits)
  route          array          // downsampled route so far (same shape as LiveRun.route, 250-cap)
  last_point     object|null    // {lat,lng,t} — tail of positionsRef (dedupe anchor)
}
discard_requested  boolean      // set when the user chooses Discard from recovery
```

Status enum gains **`abandoned`** (additive; safe for existing data — old clients treat unknown statuses as not-active, which is exactly the desired behaviour).

### RunClock restoration (pure addition to `src/lib/runClock.js`)

`RunClock.fromState({ start_time_ms, paused_ms, pause_started_at_ms })` returns a clock whose `elapsedMs(now)` is identical to the uninterrupted instance. No behaviour change to existing methods; existing tests untouched, new tests added.

**Why this preserves Stage A timing exactly:** recovery reconstructs the same three state fields the clock already uses; paused time is excluded by the same code path Stage A tests cover. Elapsed can never duplicate or vanish because `start_time_ms` is the original `start_time`, not a new one.

### Checkpoint trigger points and frequency

| Trigger | Frequency / moment | Why |
|---|---|---|
| Interval while `active` | every **20 s** | bounded loss window; ≤3 entity writes/min, modest |
| Pause, Resume, km-split crossing | immediately | captures the high-value state transitions |
| `visibilitychange → hidden`, `pagehide` | immediately | covers backgrounding/tab close without waiting 20 s |
| localStorage mirror | on **every** tracker position update | free crash buffer between server checkpoints |

**Bounded data loss:** worst case ≈ 20 s of GPS + at most the current pace window (≤6 points). The localStorage mirror reduces it further on web (survives process kill; the server checkpoint survives even a cleared cache).

---

## 3. Checkpoint / recovery flow

```
START      → clock.start; checkpoint seq 1 written with start_time
RUNNING    → every tracker update: localStorage mirror
             every 20s / on transitions: server checkpoint (seq++)
PAUSE      → clock.pause; immediate checkpoint (pause_started_at_ms set)
RESUME     → clock.resume; immediate checkpoint (paused_ms folded in)
STOP       → guard: re-read record; if already 'completed', refuse to overwrite
             else final write (status completed, actual_*, full route) + clear buffer
CRASH      → next open of /live-run/:id sees status active|paused + checkpoint
             → RECOVERY SCREEN
```

**Recovery screen** (new component, replaces the "ready" view in this situation):
- Shows target, saved distance, saved active elapsed, checkpoint age.
- **Resume** — restores RunClock from `checkpoint.clock`, seeds tracker with `checkpoint.distance_m / splits / route / last_point`, restarts the GPS watch, continues from seq+1. No new record, no new `start_time`.
- **Discard** — confirm dialog → sets `status:'abandoned'`, clears the checkpoint and local buffer. Discarded runs are never silently deleted; they appear in history as "abandoned" (no actual_* metrics).
- **Ambiguity rule:** if both server checkpoint and localStorage mirror exist, the **newer** (`at_ms`) wins; if the mirror is newer by more than one interval it is adopted and flushed to the server immediately.

**Detection beyond the deep link:** the Live tab (`LiveRunSetup`) and Home check `LiveRun.filter({ status: { $in: ['active','paused'] } })` (owner-scoped by RLS) and surface a single "Unfinished run" prompt linking to the recovery screen. Only the most recent unfinished run is offered.

---

## 4. Data integrity rules

- **No new records on recovery:** every checkpoint/update targets the run's own `id`; `handleStart` is unreachable when `status !== 'ready'`.
- **Concurrent saves:** `seq` is written with every checkpoint; a write carrying a lower `seq` than the server record's is skipped client-side (read-back on each checkpoint flush — one extra cheap `get`-per-flush can be avoided by using the update response; write conflicts last-write-wins, but seq monotonicity makes a stale page lose cleanly). Stop re-reads before the final write (completed-guard).
- **Route dedupe:** on resume, points are merged keyed by timestamp `t`; points with `t ≤ last_point.t` are dropped; distance is **carried state** (`distance_m`), never recomputed across the checkpoint boundary — only post-resume deltas add to it.
- **Completed immutability:** checkpoint writes are skipped once the server record is `completed`; the final write includes the guard in rule 3 above.
- **Ownership:** all reads/writes go through the existing `LiveRun` RLS (owner-or-admin). No new backend surface, no user-supplied user ids, no changes to RLS config.

## 5. Failure handling (no silently discarded runs)

| Situation | Behaviour |
|---|---|
| **Offline** | tracker keeps running; localStorage mirror always works; server checkpoints queue and flush with retry on reconnect. Stop offline: final result written to the mirror flagged `final-pending`; next app open flushes it before anything else. UI shows "Saved on device, syncing later". |
| **Checkpoint write fails** | non-blocking; retry with backoff (3 attempts per interval); local buffer remains authoritative; a toast appears only if 3 consecutive flushes fail. |
| **GPS permission revoked mid-run** | distance freezes (current behaviour); recovery from any later crash still preserves the run. A banner is proposed as a separate R10 item, not in R2 scope. |
| **Force-close / crash** | mirror + server checkpoint survive; recovery screen offers Resume/Discard on next open. |
| **Incomplete recovery data** | if a record is `active|paused` but has **no** `checkpoint` (legacy run, pre-R2): offer "Resume (approximate)" computing elapsed from `start_time` minus nothing (assumes no pauses — disclosed as approximate) or Discard. If not even `start_time` exists: Discard-only with an explanation. Never auto-resume and never overwrite. |

## 6. Privacy and storage

- Only the `LiveRun` record gains checkpoint data; the route in checkpoints is the **same downsampled 250-point shape** as `LiveRun.route` — no raw-accumulation copies.
- The localStorage mirror is transient: cleared on Stop, Discard, and successful final save; holds at most one run at a time.
- No health, heart-rate, or credential data is involved; no new entity is created; RLS untouched.

## 7. iOS limitations — two separate problems

- **Recovery after interruption (R2 scope, works everywhere):** checkpoint + resume covers crash, refresh, tab switch, and app kill. Verified in browser tests; iOS-specific behaviour only needs the device pass.
- **Continued tracking while locked/backgrounded (NOT R2):** on iOS Safari the OS suspends JS after the screen locks — checkpointing bounds the loss (≤20 s) but cannot keep tracking. Continued locked-screen tracking requires the external Capacitor build with `RunBackgroundBridge` (already wired for foreground) plus **physical-device testing** of: 10-min locked run, `AVAudioSession` survival (F7), incoming-call recovery (F8). This remains the F6/F7 device-test gate and is explicitly out of R2's automated-test scope.

---

## 8. Files, entities, functions to change

| File | Change |
|---|---|
| `src/lib/runClock.js` | add `fromState()` restore helper (pure; + tests) |
| `src/lib/runCheckpoint.js` | **NEW** — pure serialize/restore/merge/dedupe logic (+ tests) |
| `src/hooks/useRunTracker.js` | expose `snapshot()` / `restore(snapshot)`; accept seeded distance/positions/splits; no logic change to Stage A pause math |
| `src/hooks/useRunCheckpoint.js` | **NEW** — mirror + server flush scheduler, retry/backoff, seq handling |
| `src/pages/LiveRunActive.jsx` | wire checkpoint loop; recovery screen branch; beforeunload guard; completed-guard on stop; discard flow |
| `src/components/live/RecoveryPrompt.jsx` | **NEW** — resume/discard UI |
| `base44/entities/LiveRun.jsonc` | add `checkpoint` fields + `abandoned` status (additive) |
| `src/pages/LiveRunSetup.jsx`, `src/pages/Home.jsx` | unfinished-run detection prompt (one filter call each) |

**No backend functions change.** All writes are client-side through existing owner-scoped SDK calls.

## 9. Migration / compatibility risks

- Existing records simply lack `checkpoint` — all new code treats it as optional (§5 incomplete-data rule). No backfill, no data rewrite, no RLS change.
- `abandoned` status is additive; PostRunSummary/history pages must tolerate it (render "Abandoned", no metrics) — a small guard, included in B3.
- Risk: a user running two devices on the same live run concurrently — seq arbitration means one device's checkpoints win; documented, not silently corrupted.

## 10. Staged implementation plan

| Batch | Content | Verification |
|---|---|---|
| **B1** | Pure modules: `RunClock.fromState` + `runCheckpoint` (serialize/restore/merge) + unit tests | vitest: restore yields identical elapsed; merge dedupes by `t`; no distance recompute |
| **B2** | Tracker snapshot/restore + entity fields + checkpoint wiring + recovery screen + stop guard + beforeunload | simulated crash/reopen flow; paused-exclusion regression suite |
| **B3** | Offline flush + `final-pending` completion + abandoned history guard + unfinished-run prompts on Live/Home | vitest + manual browser pass |
| **B4** | Physical-device pass (locked-screen tracking, incoming call) | per `EXPORT-CHECKLIST.md` §6 — separate from R2 sign-off |

## 11. Acceptance criteria

1. **Simulated crash/reopen:** start a run, advance ≥2 checkpoints, hard-reload the page mid-run → recovery screen appears → Resume restores distance, elapsed, splits and route within tolerance; **no duplicate route points** (merge by `t`) and **no distance double-count** (carried `distance_m`).
2. **Paused time stays excluded:** pause 60 s mid-run → elapsed/split/final pace identical to an uninterrupted run of equal active time — **including across recovery** (resume after restore shows no paused-time jump; `RunClock.fromState` unit-tested against the same fixtures as Stage A's `runClock` tests).
3. **No duplicate runs:** recovery operates on the same record id; no code path creates a second `LiveRun` for a recoverable run.
4. **Completed runs immutable:** a second End Run (stale instance) is refused; checkpoint writes skipped once `completed`.
5. **Bounded loss:** kill the tab at any moment → at most ~20 s of GPS data unrecoverable (≤ last checkpoint interval).
6. **Offline:** stop with no connectivity → "saved on device"; on next open the run completes server-side without duplication.
7. **Scope:** every write owner-scoped (existing RLS); no changes to subscription logic, account deletion, or unrelated features.
8. **No silent discards:** every unfinished run is surfaced with Resume/Discard; legacy checkpoint-less runs disclose the approximation before resuming.
9. **Completed-run immutability (server-side):** every checkpoint, pause/resume and final write goes through a **conditional `updateMany` whose server-evaluated filter excludes terminal statuses** (`status $nin ['completed','abandoned']`, plus the run's own id) — the data layer, not the client, refuses the match for finished runs; a read-back confirms the outcome. **Reported limitation:** the platform has no atomic compare-and-swap on single-record `update`; two devices stopping near-simultaneously could both pass the guard. Resolution: after the guarded write, each device re-reads and **adopts the server record** if already completed — the first confirmed result wins, both are within tolerance, and nothing is double-counted. If this residual race were unacceptable, the alternative is a new backend function doing the guard read-write under service role — not chosen in this design because it adds server surface R2 does not need.
10. **Checkpoint ordering and concurrency (no assumed atomicity):** `seq` alone is NOT treated as atomic. Server-side, the conditional filter of safeguard 9 is the only platform-level gate; client-side, `applyCheckpoint` rejects any checkpoint with `seq ≤ current.seq` before it can be queued, and each flush is confirmed by the write response before `seq` advances locally. Two app instances on the same run: both may checkpoint (harmless, idempotent content); only one may stop (safeguard 9). A stale tab's in-flight checkpoint can land after a newer one — last-write-wins on that single field, mitigated by the stop path always superseding checkpoints, and by `applyCheckpoint` re-loading the server `checkpoint.seq` on resume so recovery never regresses to stale data.
11. **Realistic data-loss bounds (no over-promise):** the server checkpoint is the durable guarantee; the localStorage mirror is best-effort. Loss bounds per scenario: (a) browser tab crash — the mirror usually survives the process, so loss ≈ seconds; if the mirror did not flush, loss ≤ last confirmed server checkpoint + its in-flight window, i.e. **~20–40 s**, not strictly 20 s; (b) force-kill of the app process (native/webview, storage may not flush) — ≤ ~40 s; (c) no GPS fixes during the loss window — no additional loss (the mirror/checkpoint is written on any fix, and distance is carried state); (d) offline at the loss moment — the server bound grows until the next successful flush; the mirror is the fallback and is itself best-effort; (e) in-flight write lost at termination — the previous **confirmed** checkpoint is the guarantee. Nothing guarantees ≤20 s in every scenario; ~40 s is the worst-case bound, and loss is always bounded, never the whole run.
12. **Local/server reconciliation (mirror = best-effort):** on recovery, the server checkpoint wins unless the local mirror is valid **and** newer by `at_ms` (`pickNewerMirror`; tie → server, as the confirmed copy). The chosen snapshot is flushed to the server immediately so the two converge. Duplicate prevention: route merge dedupes by point timestamp `t` and distance is carried state, so replaying a mirror twice cannot double-count. Corrupted/unavailable local data: `parseLocalMirror` returns null for any non-JSON, schema-invalid or stale input, and recovery proceeds from the server checkpoint or the legacy path — a bad mirror can never poison recovery. Pending offline final saves are marked `final-pending` in the mirror and are flushed (guarded by safeguard 9) before anything else on next open.