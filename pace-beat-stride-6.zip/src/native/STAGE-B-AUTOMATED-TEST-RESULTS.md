# Stage B — Automated Browser Regression Suite (Phase 1: built; not executed here)

**Date:** 2026-10-13 (Europe/London) · **Phase 1 harness:** built & validated · **Browser scenarios executed here:** 0 of 5 · **Stage B:** OPEN (Phase 1 passing is NOT Stage B sign-off)

**Status:** The Phase 1 Playwright suite now exists in this project (`e2e/`) and is ready to run on your computer. This build environment has no browser and cannot run it, so scenario results below are **NOT RUN (BLOCKED)** — with exact commands to run them locally. The existing 177 unit tests and the production build were re-run after adding the harness (real exit codes in §4).

---

## 1. Scenario results

| # | Scenario | Status | Where |
|---|---|---|---|
| A | Refresh recovery | **NOT RUN (BLOCKED)** — no browser in this build environment | `npm run test:e2e` locally |
| B | Pause-excluded timing | **NOT RUN (BLOCKED)** | same |
| C | Offline checkpoint recovery | **NOT RUN (BLOCKED)** | same |
| D | Two-tab completion race | **NOT RUN (BLOCKED)** | same |
| E | Resume / failed / successful discard | **NOT RUN (BLOCKED)** | same |
| P-1 | Losing tab keeps tracking after terminal (detector) | **NOT RUN** — built as `test.fail()` (expected failure) | same |
| P-2 | Completion screen shows persisted values (detector) | **NOT RUN** — built as `test.fail()` (expected failure) | same |
| P-3 | No overlapping offline save attempts (detector) | **NOT RUN** — built as a normal assertion inside C | same |

No assertions were executed; no evidence (run IDs, route counts, traces) was captured here. Nothing is reported as passed. No records were created, modified or deleted — the seeded 0.18 km run (`6ace096645065b4f5d424864`) was re-confirmed untouched (paused, seq 1, 180 m).

## 2. What was actually run (real exit codes)

| Command | Exit code | Result |
|---|---|---|
| `npx vitest run` | **0** | 14 files, **177/177 passed** |
| `npm run build` | **0** | Production build OK |
| `npx playwright test --config e2e/playwright.config.js --list` | **0** | Config valid; **7 tests listed** (A–E, P-1, P-2) — proof the harness compiles and resolves |
| `npx playwright install chromium` (browser install for execution) | **blocked** | This build environment refuses browser installs (`npx playwright install` is rejected by the tooling). No substitute exists, so the browser suite cannot execute here — confirmed twice on 2026-10-13. |

## 3. The harness (Phase 1 — built)

`e2e/fakeBackend.js` (in-memory backend, SIMULATION), `e2e/geoStub.js` (deterministic GPS), `e2e/playwright.config.js`, `e2e/vite.e2e.config.js`, `e2e/recovery.spec.js` (7 tests), `e2e/README.md` (non-developer setup + troubleshooting). `@playwright/test` is a **dev dependency only**; `npm run build` and the app's code are unchanged — verified by the exit-0 build above.

**Design guarantees:**
- Runs the real app (UI, tracker, checkpoint logic, localStorage, reloads, two tabs) in Chromium against a local Vite dev server; every `/api` call is answered by the in-process fake backend via request interception. Production servers are never contacted.
- Test identity is a **normal `user` role** (never admin) whose access exists only inside the simulator as an active Subscription record — the app's real paywall logic is exercised, not bypassed, and nothing is granted in production.
- GPS is an injected stub emitting exact coordinates ~100 m apart at exact (faked-clock) timestamps; the 60 s pause is fast-forwarded by Playwright's clock (no real waiting); offline aborts every `/api` call and flips `navigator.onLine` + real offline/online events.
- Per-test evidence: trace (screenshots, console, network), a `final-store` attachment (all final records, every API request, checkpoint-sequence history, overlap counters), HTML report.
- The fake backend emulates the terminal-status guard (`status: { $nin: [completed, abandoned] }` → `updated: 0/1`). **It does not prove real backend atomicity, authentication or RLS** — those were verified separately against live servers (Stage B2/B3 probes) and remain pending for end-to-end re-confirmation.

**Run it locally (see `e2e/README.md` for the full non-developer guide):**
```bash
npm install
npx playwright install chromium
npm run test:e2e        # suite; P-1/P-2 show as "failed (expected)" by design
npm run test:e2e:report # HTML report with traces, screenshots and final store dumps
```

**Expected first-run outcome:** A, B, C, D, E and the P-3 detector should pass; **P-1 and P-2 are expected to fail** (they reproduce the known defects) and Playwright marks them "failed (expected)" so the suite still exits 0. If either unexpectedly passes after a fix, remove its `test.fail()`. If any of A–E fails, the failure (assertion + trace) is the report; the smallest fix would then be proposed separately — app code is not touched to make tests pass.

## 4. Code-reading notes (no fixes applied)

- **P-1 (confirmed by reading `LiveRunActive.jsx`):** the terminal-takeover path (`onTerminal`) swaps the view but never calls `tracker.stop()`, so the GPS watch and the 1 s timer keep running in the losing tab. Smallest fix: stop the tracker (and players) inside `onTerminal` before adopting the server record.
- **P-2 (confirmed by reading `PostRunSummary.jsx`):** the summary renders `tracker.distanceKm`/`tracker.elapsedSec` (in-memory) rather than the persisted `run.actual_*`; after a reload the fresh tracker reads zero. Smallest fix: render `run.actual_*` with the tracker as fallback.
- **P-3 (partial):** `writeServerCheckpoint` is guarded by `busyRef`, so writes serialize; the suite asserts max one in-flight `update-many` and a bounded retry volume. **Related observation (new, not one of the three):** a flush that returns early because another is busy yields `{ updated: 0 }`, which callers in `handleStart`/`handleStop` interpret as "run already finished" — a possible false rollback. Not reproduced by the suite; flagged for review only.
- Music stop in P-1 is N/A in this phase (no music service is connected in the simulator); the report labels it N/A rather than passing.

## 5. Next steps

1. **Run the same scenarios through Base44 with zero downloads:** open the in-app **Testing Agent** (test-tube icon, side panel) and give it scenario goals in plain English, e.g. "Start a 2 km live run, refresh the page halfway through, and confirm the recovery prompt restores the saved distance and time", or "Finish a live run in one tab while another tab has the same run open, and confirm only the first finish counts". This executes the real app's flows for you inside Base44 — it does not run the Playwright code, but it covers the same user journeys.
2. **Alternatively, run the Playwright suite once on any computer** (needs a one-time helper install; see `e2e/README.md`) and send back the outcome: any A–E failure becomes a targeted fix proposal with its regression test.
3. **Phase 2 (optional, real backend):** same spec against the real preview with a dedicated test account you create and entitle (owner decision), plus session capture — closes the "real server" gap for the terminal guard.
4. Manual browser checks remain superseded by this suite for the browser layer only; **physical iPhone tests 6–10 stay BLOCKED** (Capacitor build, signing, hardware).
5. Stage B remains OPEN until A–E pass in a browser and the iPhone tests pass.