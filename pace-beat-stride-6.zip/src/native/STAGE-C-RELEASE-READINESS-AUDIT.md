# PacePlay — Stage C: Release Readiness Audit

**Date:** 2026-10-13 · **Mode:** Read-only. No code, subscriptions, permissions, or data changed.

Sources: this audit plus verified prior stages (Stage A closed with all live checks passing; Stage B code complete, browser tests **not executed**, device tests pending). Every "confirmed" item below was verified by reading the live source today.

---

## 1. The short version

The app is functionally rich and its payment/token security core is in good shape. The biggest launch risks are **not** security — they are:

1. **Nothing has been tested on a physical iPhone.** Locked-screen runs, background music, incoming calls, and HealthKit on device are all unverified (item U1).
2. **The stage-2 recovery work has never been run in a real browser** — the automated suite could not execute in Base44 (browser install blocked), and the Testing Agent could not complete the flow (item U2).
3. **Two known subscription fairness defects** still live in the payment path (items C4, H2).
4. **Starting a run is fragile when music search fails** (item H1).

---

## 2. Confirmed issues (verified in code today)

### CRITICAL

- **C1 — No iOS device test pass has ever happened.** Confirmed: no native `ios/` project exists; the published iOS wrapper ships without HealthKit and without any locked-screen tracking mechanism. On an installed iOS app, locking the screen very likely suspends GPS, tracking and music — the app's core promise. *Cannot be claimed launch-ready until the device pass in `native/EXPORT-CHECKLIST.md` §6 is done.*
- **C2 — Stage B run-recovery suite never executed.** Confirmed twice (2026-10-13): the build environment refuses browser installs, so scenarios A–E never ran. Code and 177 unit tests are green, but the actual behaviour (refresh mid-run → recovery prompt) is unproven in a real browser.
- **C3 — Premium features are enforced only by the UI.** Confirmed: the server function `run-summaries` has **no entitlement check**, and playlist generation is a plain frontend LLM call. Anyone technically inclined can call the function or the AI playlist tool directly without paying. Known and documented (IAP plan Phase 1.5), unfixed.

### HIGH

- **H1 — Music search blocks and delays the run start.** Confirmed in `LiveRunActive.jsx` (search finishes before the tracker starts; a failed search leaves the runner with no music and no explanation). Unfixed.
- **H2 — Cancelling cuts premium access immediately** instead of at the end of the paid period (`create-checkout` sets `canceled` instantly; entitlement logic gives no access for `canceled`). A paying user who cancels loses access that day. Unfixed.
- **H3 — Account deletion cancels nothing at the payment provider.** Deleting the in-app account erases data (verified complete in Stage A) but Wix-side billing continues. Users may churn angrily. Documented limitation; needs a product decision before launch.

### MEDIUM

- **M1 — Starting checkout burns trial eligibility.** A user who *begins* checkout and abandons it is marked "trial already redeemed" and can never use a trial promo code. Also inconsistent: checkout stamps a 14-day trial shape; promo path grants 30 days. Unfixed.
- **M2 — Strava route prediction misses modern activity records and fails on expired tokens.** `predictRoute` still filters the deprecated `type` field (line 258) and skips the token-refresh guard every other action uses. Terrain prediction shows "no recent runs" for newer Strava accounts. Unfixed.
- **M3 — No size limits on music search input.** A logged-in user can hang the Spotify search function with thousands of tracks. Not a data-theft risk, but a stability risk.
- **M4 — HealthKit import can duplicate workouts** once a user exceeds 500 stored runs (dedupe only inspects the last page). Edge case, but wrong data is wrong data.
- **M5 — The trial promo code has a hardcoded fallback.** With `PROMO_CODE_TRIAL` still unset, the fallback code `Trialmethis` grants a 30-day trial to anyone who knows it. Fine for testing; a live hole if published.

### LOW

- **L1 — GPS-permission loss gives no feedback** (no "GPS unavailable" banner; unfixed).
- **L2 — Elevation estimates from Strava prediction are crude** (assumed segment length; can be off ~10×).
- **L3 — GPX export interpolates route numbers into XML without type validation** (crafted payload could inject XML into the file sent to Strava).
- **L4 — Two dead UI files import uninstalled packages** (`input-otp.jsx`, `resizable.jsx`) — latent build breakers only, currently ignored.
- **L5 — Parkrun catalogue is fetched client-side, uncached across sessions** (multi-MB fetch per session; failures propagate).

---

## 3. Unverified risks (need real-world testing before launch)

- **U1 — Locked-screen behaviour on iPhone (the big one).** Wake Lock is unsupported on iOS Safari; the published iOS wrapper has no background bridge; the background audio session may not hold without actual audio playback. Needs the device pass.
- **U2 — Browser recovery scenarios A–E** (refresh recovery, pause timing offline, offline checkpoints, two-tab finish race, discard) — the Playwright suite exists and lists 7 tests but has never executed.
- **U3 — Apple Music playback paths** (queue adoption, gapless advance, lock-screen controls) — coherent code, zero runtime verification.
- **U4 — Spotify takeover/queue races mid-run** (device switching, track-end races) — needs a real device.
- **U5 — Incoming-call interruption recovery** (does time, music and GPS survive?) — needs a real device.
- **U6 — Parkrun terrain data completeness** — admin-maintained segments were never audited record-by-record; missing data degrades the playlist gently (acceptable) but should be spot-checked for popular events.
- **U7 — Two known-defect regressions (P-1, P-2)** marked expected-failures in the test suite — pending validation of terminal-state cleanup and persisted completion-screen values.

---

## 4. What is already in good shape (verified, launch-positive)

- Payment webhook: JWT-verified, idempotent, keyed on checkout/subscription IDs, fails closed ✅ (Stage A live-verified)
- Subscription data writes locked to admins via RLS; all writes through service-role functions ✅
- `apple-music-token`: authenticated + per-user rate limit, live-verified 401/429 ✅
- Account deletion: covers all six user-owned entities incl. health data, credential clearing ✅
- Pause-time math, terminal-run immutability, checkpoint ordering: unit-tested and data-layer probed ✅
- Build + 177/177 unit tests + production build pass ✅

---

## 5. Recommended next 3 actions (in order)

1. **Run the recovery + run flows in a real browser, then on an iPhone.** Desktop browser pass (Stage B scenarios A–E, or the Testing Agent with plain-English goals) followed by the physical-device pass in `native/EXPORT-CHECKLIST.md` §6. Everything else is guesswork until the real-device gate closes.
2. **Fix the two payment-fairness defects (H2 cancel-at-period-end, M1 trial burn)** — small, contained, and directly user-visible; both have existing test suites to extend.
3. **Close the C3 server-side enforcement gap before promoting the paid product:** add an entitlement check to `run-summaries` (and decide whether playlist generation moves behind a backend gate) so premium access is enforced by the server, not just the UI.

*No changes made. Awaiting approval for Stage C remediation planning.*