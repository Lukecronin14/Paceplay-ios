# Stage B — End-to-End Test Plan (Checkpointing & Recovery)

**Date:** 2026-10-13 · Covers Batches B1–B3. Stage B is **not** claimed production-ready: every item marked **[DEVICE]** below requires the installed iOS app on a physical iPhone and has never been verified on hardware.

Legend: 🟢 = automated (vitest suite, runs on every change) · 🔵 = live data-layer probe (real backend, scratch records, deleted after) · 🖥️ = any desktop browser, manual · **[DEVICE]** = physical iPhone, manual.

---

## 1. Pause/resume timing (Stage A / R1)

| Scenario | How | Status |
|---|---|---|
| Paused time excluded from elapsed, splits, final pace (no pauses) | 🟢 `runClock` | Pass |
| One pause, multiple pauses, double-pause guard, stop-after-resume | 🟢 `runClock` | Pass |
| Pace window after resume never spans the pause gap (no absurd first pace) | 🟢 `runClockRestore` + tracker logic | Pass |
| Real GPS pacing across a real pause on a moving runner | **[DEVICE]** | Pending |

## 2. Checkpointing & refresh/crash recovery (B1/B2)

| Scenario | How | Status |
|---|---|---|
| Clock serialization/restore exactness (running + paused) | 🟢 `runClockRestore` (14) | Pass |
| Checkpoint validation, seq ordering (stale/duplicate/out-of-order), route merge/dedupe, mirror reconciliation, legacy plans, terminal immutability | 🟢 `runCheckpoint` (30) | Pass |
| Reopen round-trips running and paused; seq continuation; JSON round-trip | 🟢 `recoveryFlow` (16) | Pass |
| B3 entry-point detection, abandoned non-resumability, offline-flush convergence, discard-failure retention, completed immutability | 🟢 `b3Recovery` (16) | Pass |
| Conditional-write atomicity: same-field races, 6-writer hammer, stale checkpoint after completion refused | 🔵 B2 probes | Pass |
| Checkpoint object round-trips deep-equal through storage; cleared on finish; `$nin` filters supported | 🔵 B2/B3 probes | Pass |
| **Manual:** start a run, walk 30 s+, hard-refresh the browser → recovery prompt restores distance/splits/clock exactly | 🖥️ | Pending |
| **Manual:** close the tab mid-run (beforeunload), reopen → same recovery flow; Discard keeps run as discarded in history | 🖥️ | Pending |
| **Manual:** two browser tabs on the same run → exactly one can finish it; the other adopts the server record | 🖥️ | Pending |
| Real crash/force-kill on device (not refresh) + locked-screen behaviour | **[DEVICE]** | Pending |

## 3. Offline recovery (B3)

| Scenario | How | Status |
|---|---|---|
| Offline checkpoint data converges on reconnect: replayed flush is idempotent, no seq regression, no duplicate route points | 🟢 `b3Recovery` + 🔵 flush-replay probe | Pass |
| Corrupt/unavailable mirror never poisons recovery | 🟢 `b3Recovery` | Pass |
| Failed discard keeps the run recoverable (prompt stays, nothing silently dropped) | 🟢 `b3Recovery` + code path | Pass |
| **Manual:** go offline mid-run (DevTools offline), keep running, reconnect → checkpoint flushes, no duplicates, no lost km | 🖥️ | Pending |
| **Manual:** go offline, close app, come back online, reopen app → mirror adoption + flush on open | 🖥️ | Pending |
| True network loss on device (cellular dead zone) during a run | **[DEVICE]** | Pending |

## 4. GPS route continuity

| Scenario | How | Status |
|---|---|---|
| Monotonic timestamp guard: no duplicate points across a recovery boundary | 🟢 + restore logic | Pass |
| Route merge dedupe by timestamp, 250-point cap, most-recent kept | 🟢 `runCheckpoint` | Pass |
| Restored route seeds distance and continues from the carried last point | 🟢 `recoveryFlow` | Pass |
| **Manual:** refresh mid-run → route on the map continues seamlessly from the restored track, no jump/duplicate | 🖥️ | Pending |
| Real GPS accuracy filtering (>40 m rejection), real distance vs walked distance, background fixes | **[DEVICE]** | Pending |

## 5. Terminal-state protection & history

| Scenario | How | Status |
|---|---|---|
| After completion: stale checkpoint / results overwrite / status flip all refused (`updated: 0`), record untouched | 🔵 B3 probe | Pass |
| After discard: checkpoint and resume writes refused; status stays `abandoned`, checkpoint null | 🔵 B3 probe | Pass |
| Abandoned runs render distinctly in Run History, cannot be resumed | 🟢 predicate tests + UI | Done (visual check pending) |
| Entry points (Home, Live setup) detect the same single unfinished run; new-run creation blocked until resolved | 🟢 + UI | Done (visual check pending) |
| **Manual:** visual pass of Home prompt, Live setup prompt, recovery screen, history rendering at mobile + tablet widths | 🖥️ | Pending |

## 6. Physical-iPhone pass (blocks any "production-ready" claim)

All **[DEVICE]** items, on the **installed iOS app** (per `EXPORT-CHECKLIST.md` §6):

1. Locked-screen 10-min run with music: tracking, km checkpoints and track switching survive the lock (F6/F7).
2. Incoming-call interruption mid-run: distance continues, music recovers, no duplicate track adoption (F8).
3. Real GPS: accuracy filtering, distance/pace sanity, background fixes (native bridge path).
4. Force-kill mid-run → reopen → recovery restores within the documented loss bound (~20–40 s).
5. HealthKit import + re-import (no duplicates) on device.
6. App-reopen flush after a genuinely offline period on cellular.

---

## Current automated totals

**14 test files, 177/177 passing; production build exit 0.**
Automated ✅ covers all logic; 🖥️ browser items are quick manual passes; the **[DEVICE]** list is the remaining gate. Until §6 completes, Stage B remains verified-in-code, not production-ready.