# PacePlay — Stage D1: Native iOS Readiness Audit

**Date:** 2026-10-13 · **Mode:** Read-only. No code, settings, or data changed.

Sources read: `native/README.md`, `native/EXPORT-CHECKLIST.md`, `native/capacitor.config.json`, `native/run-background-bridge/ios/RunBackgroundBridge/Plugin.swift` + `Plugin.h`, `src/lib/native.js`, `src/lib/runBackground.js`, `src/lib/healthKit.js`, `src/hooks/useAudioKeepAlive.js`, plus the verified Stage C release audit.

---

## 1. What works in the published app (no external build)

The Base44-published iOS app is a **webview wrapper over the live web app**. Inside it:

| Capability | Status in published wrapper |
|---|---|
| Live Run UI, pace tracking **with screen on** | ✅ Works (browser Geolocation in the webview) |
| Pause/resume, splits, checkpoints, mid-run recovery | ✅ Works (server-backed, web-agnostic) |
| Music: Spotify app takeover + Apple Music (MusicKit JS) | ✅ Works while the screen is on |
| Subscriptions, promo codes, account deletion | ✅ Works (server-side functions) |
| Screen Wake Lock | ❌ Not supported on iOS Safari — irrelevant on iPhone |
| Silent keep-alive audio | ❌ Deliberately disabled on native iOS (`useAudioKeepAlive` skips native) — unjustified background-audio usage under App Review |
| **Locked-screen GPS / tracking / music switching** | ❌ **Does not work.** iOS suspends the webview seconds after lock; there is no native bridge in the wrapper |
| **HealthKit import** | ❌ Sample data only. HealthKit cannot ship in the platform wrapper |

**Conclusion:** the published app is a good demo/planning surface, but its two signature native features — locked-screen run tracking and real Apple Health data — cannot exist in it at all.

## 2. What requires the external Capacitor/Xcode build

Everything ships as ready code; nothing is implemented yet on device because **no `ios/` project has ever been generated** (verified: `native/` holds only the two plugin packages + config).

1. **HealthKitBridge** (read-only HealthKit: workouts, routes, HR, cadence, calories)
   - Code complete and registered (`Plugin.m`/`Plugin.h`, web fallback intact).
   - Needs: Xcode HealthKit capability, `NSHealthShareUsageDescription`, regenerated provisioning profile, bundle ID `Florenceanne123` / Team `CN782GYTY3`.
2. **RunBackgroundBridge** (locked-screen runs)
   - Plugin code complete: background location updates (When-In-Use is sufficient) + a `mixWithOthers` playback audio session that keeps the webview's JS alive so GPS, pace assessment, and Spotify track switching continue while locked.
   - Needs: Xcode Background Modes (**Location updates** + **Audio**), `NSLocationWhenInUseUsageDescription`.
   - ⚠️ iOS review note: a playback audio session with no audible content can be rejected or interrupted by iOS; the current design relies on the session keeping the process alive. This has never been observed on a device.
3. **App Store distribution itself** — export → `cap add ios` → capabilities → device pass → Archive → TestFlight. Known pipeline issues: ITMS-90085 (no architectures) and ITMS-91198 (font bundle) — expected to be resolved by a local Archive, unconfirmed.
4. **OAuth redirects** — unchanged (webview loads the live app URL); Spotify/Strava dashboards must list the published URL. No client secrets ship in the bundle.

## 3. Music playback specifics

- **Spotify:** playback runs in the Spotify app; the webview only commands it. While locked, the bridge's audio session should keep the JS poll alive so segment switches still fire. Unverified on device (risk U4).
- **Apple Music:** MusicKit JS inside the webview — pauses with the webview under lock in the published wrapper; in the Capacitor build it depends on the same audio session (risk U3: queue adoption, gapless advance, lock-screen controls never observed).
- **Interruptions (calls, Siri):** no recovery path is device-verified (risk U5). RunClock/checkpoint logic is unit-tested, but "did time and music survive a phone call?" is unknown.

## 4. Three biggest launch risks

1. **The core promise is unproven on the only device that matters.** Locked-screen tracking — the headline feature — works in neither the published wrapper (impossible) nor any Capacitor build (none exists). Every claim about background GPS, music switching while locked, and call interruptions is currently a design, not a result.
2. **The whole native build exists only as instructions.** No `ios/` project, no device install, no Archive has ever happened; the two known App Store upload blockers (ITMS-90085/91198) are still open, and the HealthKit + Background Modes + provisioning setup is fully manual with a strict bundle-ID coupling — a single mismatch crashes the app on launch.
3. **Background-audio design may not survive iOS or App Review.** The bridge keeps an inactive-content playback session alive to prevent webview suspension; iOS can tear it down (and does when nothing audible plays), and App Review can reject unjustified background audio. There is no fallback if this fails: locked-screen runs simply stop.

## 5. Simplest next steps for a non-developer (in order)

1. **Free, no Mac needed — prove the web app first.** Run one full Live Run in the desktop browser: start, pause, refresh the page mid-run, resume, finish. (This closes Stage C's unrun recovery suite.)
2. **One-time Mac session — build the real app.** Follow `native/EXPORT-CHECKLIST.md` top to bottom: export the code (App Settings → export), run the listed terminal commands, tick the two Xcode capabilities, add the two permission sentences. It is copy-paste work; ~1–2 hours.
3. **The device gate.** On your iPhone: HealthKit import + re-import (no duplicates), then a locked-screen walk/run of ~500 m — distance and pace must be right after unlock and the current song must finish and switch. If step 3 fails, risk #3 is real and needs a design change (e.g. real audible audio or a native rewrite of the tracker) — that decision should come *before* any App Store submission.

*No changes made. Next stage on request: Stage D2 (payment-fairness fixes) or D3 (remediation of anything the device pass uncovers).*