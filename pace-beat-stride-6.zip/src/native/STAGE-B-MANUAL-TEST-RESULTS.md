# Stage B — Manual Browser E2E Tests: Procedure & Results

**Prepared:** 2026-10-13 · **Executed so far:** 0 of 5 browser tests · **Stage B:** OPEN

Statuses used: **PASS**, **FAIL**, **BLOCKED**, **NOT RUN**. A test is PASS only if it was actually executed in a browser and every pass criterion was observed and recorded below.

Evidence labels (never interchangeable):
- **[AUTO]** vitest unit/integration suite (pure logic, no browser, no network)
- **[PROBE]** data-layer probe against the real backend (scratch records, no UI)
- **[MANUAL]** human-executed browser test (the only label that can make A–E PASS)
- **[INSPECTION]** reading source code. Never counts as a pass or a fail. It only predicts what to look for.

---

## 0. Setup verification (performed 2026-10-13)

| Item | Finding | Evidence |
|---|---|---|
| Admin identity | The preview session user comes from the platform's signed-in user (`auth.me()` via AuthContext). Account `6a15…2943`, role **admin**. | [PROBE] |
| Paywall vs admin | Existing behaviour: admins bypass gated routes (`AppLayout.jsx` `authorizedForPath`, admin returns true) and the Home → /subscribe redirect (`Home.jsx` skips `role === 'admin'`). The admin's own Subscription record is an expired trial (ended 2026-10-12). It does not matter because of the role bypass. **Nothing changed.** | [INSPECTION] + [PROBE] |
| Seeded fixture exists | `6ace096645065b4f5d424864`: status **paused**, owner = admin account, target 0.5 km / 4 min, empty track pool. | [PROBE] |
| Fixture recoverable | Checkpoint passes every `validateCheckpoint` rule: seq 1, distance_m 180, clock {start 10:32:18Z, paused_ms 0, pause_started_at 10:35:18Z}, 3 route points, 0 splits, valid last_point. So `planRecovery` gives mode **checkpoint** (exact restore). | [PROBE] + [INSPECTION] |
| Entry-point detection | The exact `useUnfinishedRun` query (owner-scoped, active/paused, newest first) returns **only** this fixture. | [PROBE] |
| Data environment | The fixture lives in the database that holds the existing run history (production data). The preview's **Test Data switch must be OFF** to see it. The Testing Agent uses a separate environment and a fresh non-admin user, so it can't see the fixture and is stopped by the paywall. That is an environment limitation, not evidence for or against recovery. | [PROBE] + platform docs |

**Fixture caveats.** I created this fixture synthetically with a data tool. The run tracker did not produce it. Use it **only** for Test E (prompt display, recovery screen, resume into the paused view, failed discard and successful discard). Do **not** un-pause it with the in-run Resume button. Its route is in central London, and the tracker has no jump filter, so the first real or emulated fix would add the straight-line distance to your location. While it exists, Live setup blocks creating new runs (Generate is disabled), so **run Test E first**.

**Do not use** `6acbb05c89ec84f347fa5682`. It's a pre-existing "ready" record from 11 Oct, not a test fixture. This replaces my earlier suggestion to use it.

---

## 1. Environment & prerequisites (all browser tests)

1. **Browser:** desktop Chrome (needs the DevTools Sensors and Network offline features). Record the Chrome version.
2. **Where to open the app:** in its **own top-level tab**, signed in as the admin. Use either the preview opened in a new tab or the published URL, and use the published URL only if the app was republished after the B3 changes. Don't use the embedded builder preview pane: geolocation permission inside an iframe and the two-tab test are unreliable there.
3. **DevTools:** in Network **and** Console, turn on **Preserve log** so evidence survives hard refreshes. Set the Network filter to `LiveRun`.
4. **Location:** open Sensors (Cmd/Ctrl+Shift+P, then "Show Sensors"), set Location to **Custom location**, latitude `51.50000`, longitude `-0.12000`.
   - **Accuracy field:** on Chrome 138+ the Custom location form has an **Accuracy** box — set it to **10**. (Older versions don't expose it; don't guess.)
   - **Accuracy pre-flight (mandatory):** run this in the Console:
     `navigator.geolocation.getCurrentPosition(p => console.log('accuracy m:', p.coords.accuracy), e => console.log('geo error:', e.message), { enableHighAccuracy: true })`
     The value must be **≤ 40**. The tracker rejects every fix with accuracy over 40 m (`useRunTracker.js`). If it's higher, mark A–D **BLOCKED (environment)**, not FAIL. The alternative is a phone browser walked outdoors. That counts only as a mobile-browser run, **not** toward the physical-iPhone gate.
5. **Movement:** a fix counts only if it's more than 1 m from the last accepted fix. One "step" means increasing latitude by **+0.0003** (≈33 m). A single **+0.0100** step (≈1.1 km) crosses a km boundary and produces a split. That is synthetic input, so note it in the results.
6. **Hard refresh** (Cmd/Ctrl+Shift+R) during a run shows the browser's "Reload site?" dialog (the app's beforeunload guard). Choose **Reload**.
7. **Order:** E, then A, B, C, D. Each of A–D uses a **newly generated, dedicated run**: Live tab, set distance/time, Generate (this uses AI credits, about 20–40 s).
8. Other tabs **don't refresh on focus**. Reload explicitly when checking prompts across tabs.

## 2. Evidence capture

- **Server record (authoritative):** after each checkpoint moment marked "PROBE" below, send the run ID to the build assistant for a **read-only** integrity probe. It reports status, updated_date, checkpoint {seq, at_ms, distance_m, clock, route count, splits count}, actual_* fields, final route point count, duplicate-timestamp count and non-monotonic-timestamp count. Alternative: Dashboard → Data → LiveRun.
- **Local mirror:** paste this in the Console on the run page. It prints no secrets:
  ```js
  (() => { const id = location.pathname.split('/').pop(); const m = JSON.parse(localStorage.getItem('liverun_checkpoint_' + id) || 'null'); return m && { seq: m.seq, at: new Date(m.at_ms).toISOString(), distance_m: Math.round(m.distance_m), clock: m.clock, splits: m.splits.length, route: m.route.length, dupT: m.route.length - new Set(m.route.map(p => p.t)).size }; })()
  ```
  Between server flushes, the mirror's seq is **confirmed server seq + 1**. It's speculative by design, not a regression.
- **Network:** each `updateMany` response shows `updated: 1` (accepted) or `updated: 0` (refused by the terminal-status guard). Record the time and response of each one that matters.
- **Expected console messages:** `Checkpoint flush failed (…)` while offline, and `Discard failed:` for E's offline discard. Anything else is a finding and must be recorded.
- **Run History:** open `/run-history` and compare its distance and time with the probe's actual_* values.
- **Redaction:** never paste request headers (Authorization), cookies, or a full localStorage dump. It contains Spotify, Strava and Apple Music tokens. Only use the mirror snippet above.

**Per-test record template:** Run ID · environment (Chrome version, URL type, location method, reported accuracy) · wall-clock start/end · server status initial → final · checkpoint seq timeline · distance and route values (UI, mirror, server) · console errors · failed requests · result.

---

## 3. Inspection-predicted issues (NOT test results; confirm or refute during testing)

| ID | Where it would show | Prediction (from source) | Impact | Smallest fix (proposed, **not implemented**) |
|---|---|---|---|---|
| P-1 | Test D, tab B | When a tab adopts a terminal server record (`onTerminal`, the lost finish race, the refused discard), it doesn't stop local tracking: the GPS watch and the 1 s timer keep running, and music isn't paused. | Display and resources only. Every server write from that tab is refused. | In those three paths, call `tracker.stop()`, pause the player if it's ready, and clear the mirror. About 5 lines in LiveRunActive. |
| P-2 | Test D, tab B. Also any reopened completed run | The "Run Complete" summary shows **local tracker** values, not the persisted `actual_*`. Tab B can show 0.00 km / 0:00, or with P-1 a still-ticking time, while the server holds the real result. This predates Stage B. | A misleading summary. Stored data is correct. | In PostRunSummary, use `run.actual_distance_km` / `actual_time_min` when they exist and fall back to the tracker. About 4 lines. Splits for a reopened run are not persisted (out of scope). |
| P-3 | Test C | While offline, every 1 s tick starts another flush attempt, because a failure doesn't reset the interval. Expect about 3 failed requests per second, the "Checkpoints not syncing" toast repeating every few seconds, and after reconnect the seq rising by **several** within a few seconds as queued retries succeed. | Noise and request volume. The data isn't harmed: the mirror is written before each attempt, the confirmed seq only advances on success, and the checkpoint route is replaced, not appended. | Allow only one flush loop at a time (a guard flag spanning the retries in `useRunCheckpoint`). About 4 lines. The interval is unchanged. |

---

## 4. Matrix

| # | Test | Status | Executed by / when |
|---|---|---|---|
| A | Refresh recovery | **NOT RUN** | — |
| B | Pause-excluded timing | **NOT RUN** | — |
| C | Offline checkpoint recovery | **NOT RUN** | — |
| D | Two-tab completion race | **NOT RUN** | — |
| E | Resume & discard (Home + Live) | **NOT RUN** | — |
| 6–10 | Physical iPhone | **BLOCKED** | See §6 |

---

## 5. Test procedures

### Test E — Resume and discard (run FIRST; uses the fixture)
**Prerequisites:** §1 items 1–3. The fixture is present (re-check with a probe on the day). The browser is online.
**Steps:**
1. Open Home. Find the "Unfinished run detected" card.
2. Open the Live tab. Find the same card. Check that Generate is disabled and the helper text says to finish or discard first.
3. On Home, click **Resume**. The recovery screen opens. Record its values. Don't press anything. Leave using the Live tab.
4. On Live, click **Resume**. On the recovery screen, press **Resume Run**. Record the view. **Do not press the in-run Resume.** Then PROBE.
5. Click the back arrow to Live. DevTools Network → **Offline**. Click **Discard**, then **Confirm Discard**.
6. Go back online. PROBE.
7. Click **Confirm Discard** again. Check Live, then switch to Home, then reload. Run the mirror snippet with the fixture ID: `localStorage.getItem('liverun_checkpoint_6ace096645065b4f5d424864')`. Open `/run-history`. PROBE.

**Expected (pass criteria):**
- Steps 1–2: both cards read "0.18 km saved · 0.5 km target" (metric setting) and show **the same run**.
- Step 3: recovery screen shows **0.18 km done**, **0:03:00 active time**, **0 km splits**, "saved N min ago". Active time must be exactly 3:00, however long the fixture has been paused. That deterministically checks pause exclusion.
- Step 4: paused live view with the PAUSED badge, 0.18 km, elapsed 3:00 and not ticking. Server: still `paused`, checkpoint seq **1 → 2** within about 2 s, clock values unchanged.
- Step 5: "Could not discard — check your connection. Your run stays recoverable." The card stays. Console shows `Discard failed:`.
- Step 6: server still `paused`, checkpoint present.
- Step 7: the card disappears on Live **and** Home, and stays gone after reload. Generate is enabled. The mirror key is `null`. Run History shows the run as **discarded**. Server: `abandoned`, checkpoint `null`.

**Actual:** Not executed. · **Evidence now:** [AUTO] b3Recovery (discard-failure retention, entry-point predicate). [PROBE] B3 (writes refused after discard). [PROBE 2026-10-13] the fixture is visible to the hook query. · **Status: NOT RUN**

### Test A — Refresh recovery
**Prerequisites:** Test E completed (no unfinished run). §1 all items, with accuracy pre-flight ≤ 40.
**Steps:**
1. Live: set 2 km / 16 min, then Generate. Record the run ID from the URL.
2. **Start Live Run** and allow location. Make 4 steps about 5 s apart, then one **+0.0100** step (crosses km 1), then 2 more steps.
3. Wait at least 25 s without moving. Confirm in Network an `updateMany` with `updated: 1`. Run the mirror snippet. Record the on-screen distance and elapsed time, plus the wall-clock time. PROBE.
4. Hard refresh, then Reload.
5. On the recovery screen, record distance, active time and splits. Note the wall-clock time.
6. **Resume Run.** Make 2 more steps. Watch the distance.
7. **End Run.** Record the summary values. PROBE. Open `/run-history`.

**Expected:**
- Step 5: distance equals the step-3 value (±0.01 km). Active time equals wall-clock time since Start (±2 s): the run was active, so the reload gap counts as running time. Splits = **1**.
- If the mirror was newer than the server copy, Network shows one load-time `updateMany` (updated: 1) **before** you press anything. That's expected (B3 reopen convergence).
- Step 6: elapsed keeps ticking from the recovered value. Distance grows from the restored value, with no reset to 0 and no jump back.
- Step 7 PROBE: status `completed`, checkpoint `null`. actual_distance_km matches the summary (±0.01). actual_time_min × 60 matches the summary time (±2 s). Route point count ≥ the step-3 mirror route count + new points. **0 duplicate** and **0 non-monotonic** timestamps. Run History matches.

**Actual:** Not executed. · **Evidence now:** [AUTO] runClockRestore, recoveryFlow, runCheckpoint (merge/dedupe). [PROBE] B2 checkpoint round-trip. · **Status: NOT RUN**

### Test B — Pause-excluded timing
**Prerequisites:** as for A, with no unfinished run.
**Steps:**
1. Generate a 0.5 km / 4 min run. Record the ID. Start it and make 2 steps. Run about 20 s.
2. Press **Pause** and record the elapsed value **E_p** and the wall-clock time. Run the mirror snippet: `pause_started_at_ms` must be set.
3. Wait **at least 60 s** (time it). Elapsed must stay at E_p.
4. Hard refresh, then Reload. Record the recovery-screen active time.
5. **Resume Run**. You land in the paused view. Then press the in-run **Resume** and record the wall-clock time. After 3 s, run the mirror snippet. PROBE.
6. Run about 15 s, then **End Run**. PROBE.

**Expected:**
- Step 4: active time = **E_p (±1 s)**, not E_p + 60 s.
- Step 5: the paused view shows the PAUSED badge with elapsed E_p, not ticking. After Resume, elapsed continues from E_p. Mirror and server clock: `pause_started_at_ms` null, `paused_ms` ≈ the measured pause, from Pause press to Resume press (±2 s). Server status `active`.
- Step 6: actual_time_min × 60 ≈ total wall time from Start to End minus the measured pause (±3 s).

**Actual:** Not executed. · **Evidence now:** [AUTO] runClock (pause accounting), runClockRestore (paused round-trip). · **Status: NOT RUN**

### Test C — Offline checkpoint recovery
**Prerequisites:** as for A. Note the wall-clock time before Generate (used to count runs created).
**Steps:**
1. Generate a 0.5 km / 4 min run and Start it. Make 2 steps. Wait for an `updateMany` with `updated: 1`. PROBE and record the server seq **S0** and distance **d0**.
2. Network → **Offline**.
3. Over about 30 s, make 3 steps. Record the on-screen distance **d1**, the console messages, and how often the toast appears. Run the mirror snippet.
4. Network → **No throttling** (online). Within about 5 s, check for an `updateMany` with `updated: 1`. PROBE right away.
5. Make 1 step, then **End Run**. PROBE and also count the runs created since the step-1 note.

**Expected:**
- Step 3: tracking keeps working locally (distance rises to d1). The mirror shows d1 and seq S0+1. Expect the `Checkpoint flush failed` errors and the "Checkpoints not syncing" toast (cadence per P-3).
- Step 4: a successful write follows reconnection. Server seq **> S0 and never below S0**. It may rise by several, per P-3. Server distance_m ≥ d1 at reconnect. No duplicate route timestamps.
- Step 5: exactly **one** LiveRun created in the window. Final route has 0 duplicate and 0 non-monotonic timestamps. Final distance is consistent with the UI.
- *Optional C2 (plan §3):* offline, close the tab, go online, reopen the run URL. The recovery screen shows the mirror data, and Network shows the load-time convergence write.

**Actual:** Not executed. · **Evidence now:** [AUTO] b3Recovery (offline-flush convergence, corrupt-mirror safety). [PROBE] B3 flush-replay (idempotent, no seq regression). **These are not a browser network-disconnection test.** · **Status: NOT RUN**

### Test D — Two-tab completion race
**Prerequisites:** as for A.
**Steps:**
1. Tab A: Generate a 0.5 km / 4 min run, Start it, make 2 steps, wait for `updated: 1`.
2. Copy the URL into **tab B** (same browser). B shows the recovery screen. Record any load-time `updateMany` from B. Don't press anything in B.
3. Tab A: **End Run**. PROBE and save this as the reference snapshot.
4. Tab B: press **Resume Run**. Watch for about 5 s and record what B shows. Check whether its time or distance values keep changing (P-1) and whether they match the reference (P-2). PROBE.
5. Tab B: reload. Record the view. Open Home and Live in B and check for an unfinished-run prompt.
6. *Optional D2:* repeat with a new run, but in step 4 press **Discard → Confirm Discard** in B instead of Resume.

**Expected:**
- **Server (integrity):** after steps 4, 5 and D2, status stays `completed`. actual_*, route and updated_date are **identical** to the step-3 reference. checkpoint stays `null`. Every write from B returns `updated: 0`. It is never `abandoned` and never `active`.
- **Tab B (behaviour):** within about 2 s of Resume, B leaves the active view and shows the completed state. It must not keep running as active. After reload, no recovery prompt appears and Home/Live show no unfinished-run prompt.
- **PASS requires both.** If the server criteria hold but B shows wrong or ticking values (P-1/P-2), record **FAIL** with "data integrity held" in the notes.

**Actual:** Not executed. · **Evidence now:** [PROBE] B2 same-field races, 6-writer hammer, stale checkpoint after completion refused. B3 completed immutability. · **Status: NOT RUN**

---

## 6. Physical iPhone tests (separate gate)

| # | Test | Status | What's needed |
|---|---|---|---|
| 6 | Force-quit and reopen | **BLOCKED** | External Capacitor iOS build with the RunBackgroundBridge plugin (`native/`, `EXPORT-CHECKLIST.md`), Xcode signing on an Apple Developer account, a physical iPhone (TestFlight or direct install) |
| 7 | GPS + elapsed with the screen locked | **BLOCKED** | Same as 6, plus outdoor GPS and a 10-minute run with music |
| 8 | Recovery after an incoming call | **BLOCKED** | Same as 6, plus a second phone to place the call |
| 9 | Cellular lost, then restored | **BLOCKED** | Same as 6, plus a SIM with cellular data and the ability to disable it mid-run |
| 10 | HealthKit permissions and on-device behaviour | **BLOCKED** | Same as 6, plus the HealthKitBridge plugin, the HealthKit entitlement and usage strings, and real workouts in Apple Health. The published web wrapper can't provide HealthKit. |

## 7. Stage B close criteria

Stage B closes only when A–E are **PASS** (or any FAIL has an approved fix and a re-test PASS) **and** tests 6–10 are **PASS** on hardware. Until then the status is verified in code, **not** production-ready.