# Stage C1 — Post-Publish Verification Plan (Server-Side Premium Checks)

**Date:** 2026-10-13 (Europe/London) · **Status:** READY TO PUBLISH · **No code changes needed for this plan**

## What changed (recap)

8 premium-only operations across 3 backend functions now verify the signed-in user's
subscription server-side: `run-summaries`; Spotify `searchTracks` / `searchAndExportPlaylist`
/ `createPlaylist`; Strava `getActivities` / `getActivity` / `predictRoute` / `uploadGpx`.
All connection, token, profile, playlist-reading and disconnect operations stay open.
Unit-tested (11 new tests), build passes. The guard is additive — nothing else changed.

## Safety principles

- **Never verify "denied" with an admin account.** Admins bypass the check by design,
  so an admin would always be granted — it proves nothing about normal users.
- **Never touch real subscriptions.** All entitlement testing happens on two disposable
  test accounts created only for this purpose.
- **Premium account uses the real grant path.** The free promo code is redeemed through
  the existing Subscribe-page flow (same mechanism real users get), so no records are
  edited by hand, no payment is made, and no trial dates are written (trial eligibility
  is not burned).
- **Cleanup is simple.** Both test accounts (and their one Subscription record) can be
  deleted afterwards; nothing they touch affects other users.

## Publish first

Publish the app — backend function updates deploy on publish. Allow a few minutes for
propagation (a known platform delay) before running the checks below.

## Test accounts (create before publishing checks)

| Account | Role | Setup |
|---|---|---|
| **P1** — premium | `user` | Invite via App Users. Sign in, open **Subscribe**, redeem the free promo code (the `PROMO_CODE_FREE` secret). Result: Subscription status `free` = premium. |
| **N1** — no premium | `user` | Invite via App Users. Do nothing else — no subscription record exists, so every premium check must deny. |

Both accounts should connect Spotify and/or Strava during setup (that part is free-tier
and required by several checks below).

## Checks — access GRANTED (P1)

All should return success (HTTP 200). Optional confirmation: browser DevTools → Network
tab, filter "functions".

1. **Run History** loads and lists past runs (`run-summaries` → 200).
2. **Plan export:** open a plan in My Plans → Export to Spotify succeeds (`searchAndExportPlaylist` → 200).
3. **Live run music:** start a live run → track playback selects real tracks (`searchTracks` → 200).
4. **Strava runs list:** Strava Runs page lists activities (`getActivities` → 200).
5. **Strava run detail:** open one activity (`getActivity` → 200).
6. **Terrain prediction:** live-run setup with a Strava route → predicted terrain appears (`predictRoute` → 200).
7. **GPX export:** Run History → Send to Strava succeeds (`uploadGpx` → 200).
8. **Free flows unaffected:** Home-page Spotify/Strava connect and the onboarding music picker still work (these must NOT be gated).

## Checks — access DENIED (N1)

All premium operations should fail closed (HTTP 403, "Premium subscription required") and
the UI should show its locked state, never the data.

1. **Home page** works normally; Spotify/Strava connect still succeeds (proves the guard didn't over-block free flows — most important regression check).
2. **Run History:** locked UI shown, no run data (`run-summaries` → 403 in Network tab).
3. **My Plans:** locked UI shown.
4. **Live run:** setup screen works, but during a run the music selector cannot fetch tracks (`searchTracks` → 403) — the run itself still tracks distance/time (generation is a separate, known ungated path; see "Known gaps").
5. **Strava Runs / Strava run detail:** locked or empty-with-lock; list/detail calls → 403.
6. **GPX export / terrain prediction:** not offered or → 403.

## Known gaps (unchanged by this stage, documented)

- **`active` (real paid) status** is verified by unit tests only — proving it live would
  require a real purchase on a test account; defer to billing-change testing.
- **AI playlist generation** is a direct frontend AI call, not a backend function —
  server-gating it needs the documented backend migration (Phase 6).
- **Record writes** (runs/plans) remain owner-scoped by row-level security; RLS cannot
  read subscriptions.

## Cleanup

Delete P1 and N1 (App Users) and P1's single Subscription record when done. The owner's
real subscription and all other users are untouched throughout.