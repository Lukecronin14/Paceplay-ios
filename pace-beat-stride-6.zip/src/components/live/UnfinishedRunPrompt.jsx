import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { TERMINAL_STATUSES } from '@/lib/runCheckpoint';
import { mirrorKey } from '@/hooks/useRunCheckpoint';
import { formatDisplayDistance, displayUnit } from '@/lib/units';
import { AlertTriangle, Loader2, Play, Trash2 } from 'lucide-react';

/**
 * Entry-point unfinished-run prompt (Batch B3). Shown by Home and Live setup
 * for a run detected by useUnfinishedRun. Resume opens the run's own recovery
 * screen (planRecovery decides exact/approximate); Discard is a GUARDED write
 * (terminal-status filter, user-scoped by RLS) — on failure the prompt stays
 * and the run is never silently discarded.
 */
export default function UnfinishedRunPrompt({ run, onResolved }) {
  const navigate = useNavigate();
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);

  const savedKm = Number(run.checkpoint?.distance_m) > 0 ? run.checkpoint.distance_m / 1000 : 0;

  const handleDiscard = async () => {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    setBusy(true);
    setError(false);
    try {
      const res = await base44.entities.LiveRun.updateMany(
        { id: run.id, status: { $nin: TERMINAL_STATUSES } },
        { $set: { status: 'abandoned', checkpoint: null } }
      );
      if (res?.updated === 1) {
        try { localStorage.removeItem(mirrorKey(run.id)); } catch { /* best-effort */ }
        setConfirming(false);
        onResolved?.();
      } else {
        // updated: 0 — the run went terminal elsewhere (guarded write refused).
        // Not a failure: refresh so the prompt follows the server record.
        setConfirming(false);
        onResolved?.();
      }
    } catch (err) {
      console.error('Discard failed:', err);
      // Keep the prompt on screen — the run is never silently discarded.
      setError(true);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-xl p-4 mb-6">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm text-amber-800 dark:text-amber-300">Unfinished run detected</p>
          <p className="text-sm text-amber-700 dark:text-amber-400 mb-3">
            {savedKm > 0 && (
              <>{formatDisplayDistance(savedKm, 2)} {displayUnit()} saved · </>
            )}
            {formatDisplayDistance(run.target_distance_km, 1)} {displayUnit()} target
          </p>
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              className="h-9 rounded-lg"
              onClick={() => navigate(`/live-run/${run.id}`)}
              disabled={busy}
            >
              <Play className="w-4 h-4 mr-1.5" /> Resume
            </Button>
            <Button
              size="sm"
              variant={confirming ? 'destructive' : 'outline'}
              className="h-9 rounded-lg"
              onClick={handleDiscard}
              disabled={busy}
            >
              {busy ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Trash2 className="w-4 h-4 mr-1.5" />}
              {confirming ? 'Confirm Discard' : 'Discard'}
            </Button>
          </div>
          {confirming && !error && (
            <p className="text-xs text-amber-700 dark:text-amber-400 mt-2">
              The run will be kept in your history as discarded, without results.
            </p>
          )}
          {error && (
            <p className="text-xs text-amber-800 dark:text-amber-300 mt-2 font-medium">
              Could not discard — check your connection. Your run stays recoverable.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}