import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mountain, TrendingUp, TrendingDown, Minus, Loader2, MapPin } from 'lucide-react';

const GRADIENT_STYLES = {
  steep_uphill: { label: 'Steep Uphill', color: 'bg-red-500', icon: TrendingUp, text: 'text-red-600 dark:text-red-400' },
  uphill: { label: 'Uphill', color: 'bg-orange-500', icon: TrendingUp, text: 'text-orange-600 dark:text-orange-400' },
  slight_uphill: { label: 'Slight Uphill', color: 'bg-amber-400', icon: TrendingUp, text: 'text-amber-600 dark:text-amber-400' },
  flat: { label: 'Flat', color: 'bg-green-500', icon: Minus, text: 'text-green-600 dark:text-green-400' },
  slight_downhill: { label: 'Slight Downhill', color: 'bg-cyan-400', icon: TrendingDown, text: 'text-cyan-600 dark:text-cyan-400' },
  downhill: { label: 'Downhill', color: 'bg-blue-500', icon: TrendingDown, text: 'text-blue-600 dark:text-blue-400' },
  steep_downhill: { label: 'Steep Downhill', color: 'bg-indigo-500', icon: TrendingDown, text: 'text-indigo-600 dark:text-indigo-400' },
};

export default function RoutePrediction({ targetDistance, onTerrainReady }) {
  const [prediction, setPrediction] = useState(null);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [enabled, setEnabled] = useState(false);

  const stravaToken = localStorage.getItem('strava_access_token');

  const fetchPrediction = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('stravaIntegration', {
        action: 'predictRoute',
        accessToken: stravaToken,
        targetDistance,
      });

      if (res.data?.prediction) {
        setPrediction(res.data.prediction);
        setSummary(res.data.summary);
        setEnabled(true);
        onTerrainReady?.(res.data.prediction, res.data.summary);
      } else {
        setError(res.data?.message || 'No route data available');
      }
    } catch (err) {
      setError('Failed to fetch route prediction');
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = () => {
    if (enabled) {
      setEnabled(false);
      onTerrainReady?.(null, null);
    } else if (prediction) {
      setEnabled(true);
      onTerrainReady?.(prediction, summary);
    } else {
      fetchPrediction();
    }
  };

  if (!stravaToken) {
    return (
      <Card className="border-dashed">
        <CardContent className="p-4 flex items-center gap-3">
          <MapPin className="w-5 h-5 text-muted-foreground shrink-0" />
          <div className="text-sm">
            <p className="font-medium">Terrain-Aware Mode</p>
            <p className="text-xs text-muted-foreground">Connect Strava to predict terrain from your running history</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={enabled ? 'border-primary/40 bg-primary/5' : ''}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Mountain className="w-4 h-4 text-primary" />
            Terrain Prediction
          </CardTitle>
          <Button
            size="sm"
            variant={enabled ? 'default' : 'outline'}
            onClick={handleToggle}
            disabled={loading}
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : null}
            {enabled ? 'Active' : prediction ? 'Enable' : 'Predict'}
          </Button>
        </div>
      </CardHeader>

      {error && (
        <CardContent className="pt-0 pb-3">
          <p className="text-xs text-destructive">{error}</p>
        </CardContent>
      )}

      {enabled && prediction && summary && (
        <CardContent className="pt-0 space-y-3">
          <div className="flex flex-wrap gap-2 text-xs">
            <span className="px-2 py-1 rounded-md bg-card border border-border capitalize">
              {summary.terrain_type} terrain
            </span>
            <span className="px-2 py-1 rounded-md bg-card border border-border">
              ~{summary.elevation_gain_m}m elevation
            </span>
            <span className="px-2 py-1 rounded-md bg-card border border-border">
              {summary.runs_analyzed} runs analysed
            </span>
          </div>

          <div className="space-y-1">
            {prediction.map((seg) => {
              const style = GRADIENT_STYLES[seg.gradient] || GRADIENT_STYLES.flat;
              const Icon = style.icon;
              return (
                <div key={seg.km} className="flex items-center gap-2 text-xs">
                  <span className="w-8 text-muted-foreground font-medium">KM{seg.km}</span>
                  <div className="flex-1 flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${style.color}`} />
                    <Icon className={`w-3 h-3 ${style.text}`} />
                    <span className="font-medium">{style.label}</span>
                  </div>
                  <span className="text-muted-foreground tabular-nums">
                    {seg.avg_grade > 0 ? '+' : ''}{seg.avg_grade}%
                  </span>
                  {seg.pace_adjustment_min_per_km !== 0 && (
                    <span className={`tabular-nums ${seg.pace_adjustment_min_per_km > 0 ? 'text-chart-3' : 'text-primary'}`}>
                      {seg.pace_adjustment_min_per_km > 0 ? '+' : ''}{seg.pace_adjustment_min_per_km}s
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      )}
    </Card>
  );
}