import React, { useState } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import { Drawer, DrawerTrigger, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Check, ChevronDown } from 'lucide-react';
import { formatDisplayDistance } from '@/lib/units';

export default function PresetSelector({ presets, distance, unitLabel = 'km', onSelect }) {
  const isMobile = useIsMobile();
  const [open, setOpen] = useState(false);
  const current = presets.find((p) => p.dist === distance);

  if (!isMobile) {
    return (
      <div className="flex gap-2 flex-wrap">
        {presets.map((p) => (
          <button
            key={p.label}
            onClick={() => onSelect(p)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all
              ${current?.label === p.label
                ? 'border-primary bg-primary/10 text-primary'
                : 'border-border bg-card hover:border-primary/30 hover:bg-primary/5'}`}
          >
            {p.label}
          </button>
        ))}
      </div>
    );
  }

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        <Button variant="outline" className="w-full justify-between rounded-xl">
          {current ? `${current.label} — ${formatDisplayDistance(current.dist, 1)}${unitLabel} · ${current.time}min` : 'Choose a preset'}
          <ChevronDown className="w-4 h-4" />
        </Button>
      </DrawerTrigger>
      <DrawerContent>
        <DrawerHeader className="text-left">
          <DrawerTitle>Choose a preset</DrawerTitle>
        </DrawerHeader>
        <div className="px-2 pb-6 space-y-1">
          {presets.map((p) => (
            <button
              key={p.label}
              onClick={() => { onSelect(p); setOpen(false); }}
              className="w-full flex items-center justify-between px-4 py-3 rounded-lg text-sm hover:bg-muted text-left"
            >
              <span>{p.label} — {formatDisplayDistance(p.dist, 1)}{unitLabel} · {p.time}min</span>
              {current?.label === p.label && <Check className="w-4 h-4 text-primary" />}
            </button>
          ))}
        </div>
      </DrawerContent>
    </Drawer>
  );
}