import React from 'react';
import { Music, Play, Pause, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Apple Music counterpart of SpotifyPlayer — plays in-page via MusicKit,
// so there's no device picker.
export default function AppleMusicPlayer({ player, connected }) {
  if (!connected) {
    return (
      <div className="bg-muted/50 rounded-xl p-4 text-center">
        <Music className="w-5 h-5 text-muted-foreground mx-auto mb-2" />
        <p className="text-sm font-medium mb-1">Apple Music not connected</p>
        <p className="text-xs text-muted-foreground">Connect Apple Music from the home page to enable live music playback during your run.</p>
      </div>
    );
  }

  if (player.error) {
    return (
      <div className="bg-destructive/5 border border-destructive/20 rounded-xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm font-medium text-destructive mb-0.5">Playback unavailable</p>
          <p className="text-xs text-destructive/80">{player.error}</p>
        </div>
      </div>
    );
  }

  if (!player.isReady) {
    return (
      <div className="bg-muted/50 rounded-xl p-4 flex items-center justify-center gap-2">
        <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
        <p className="text-sm text-muted-foreground">Preparing Apple Music...</p>
      </div>
    );
  }

  const { progressMs = 0, durationMs = 0 } = player.playbackTime || {};

  return (
    <div className="bg-card rounded-xl border border-border p-3">
      <div className="flex items-center gap-3">
        <Button
          size="icon"
          onClick={player.togglePlay}
          className="rounded-full w-10 h-10 shrink-0 bg-rose-600 hover:bg-rose-700"
        >
          {player.isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 bg-rose-500 rounded-full animate-pulse" />
            <span className="text-xs font-medium text-rose-600 dark:text-rose-400">Playing via Apple Music</span>
          </div>
          <p className="text-xs text-muted-foreground">
            {player.isPlaying ? 'Playing' : 'Paused'} · Auto-selecting tracks by pace
          </p>
        </div>
      </div>
      {durationMs > 0 && (
        <div className="mt-2 h-1 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full bg-rose-500 rounded-full transition-[width] duration-1000 ease-linear"
            style={{ width: `${Math.min(100, Math.max(0, (progressMs / durationMs) * 100))}%` }}
          />
        </div>
      )}
    </div>
  );
}