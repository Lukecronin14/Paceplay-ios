import React from 'react';
import { Music, ChevronRight, SkipForward } from 'lucide-react';
import { selectTrack } from '@/lib/paceUtils';
import { kmToDisplay, displayUnit } from '@/lib/units';

const scenarioConfig = {
  on_pace: { label: 'On Pace', color: 'bg-primary/10 text-primary border-primary/20' },
  behind_pace: { label: 'Push', color: 'bg-chart-3/10 text-chart-3 border-chart-3/20' },
  ahead_pace: { label: 'Settle', color: 'bg-chart-4/10 text-chart-4 border-chart-4/20' },
};

export default function NowPlaying({ trackPool, currentKm, paceDeviation, totalKm, actualTrack, upNext, onSkip }) {
  const pool = trackPool || [];
  const unit = displayUnit().toUpperCase();
  const toDisplayIndex = (kmNumber) => Math.max(1, Math.ceil(kmToDisplay(kmNumber)));
  const totalDisplay = Math.max(1, Math.round(kmToDisplay(totalKm)));
  const clampedKm = Math.min(currentKm, pool.length - 1);
  const segment = pool[clampedKm] || pool[pool.length - 1];
  // Show the track actually playing (Spotify matched it), falling back to the
  // pace-recommended one when playback hasn't started yet.
  const track = actualTrack || selectTrack(segment, paceDeviation);
  // Prefer the track actually queued with Spotify; fall back to the
  // pace-recommended one when nothing is lined up yet.
  const nextTrack = upNext || (pool[clampedKm + 1] ? selectTrack(pool[clampedKm + 1], 0) : null);

  if (!track) return null;

  const scenario = scenarioConfig[track.scenario] || scenarioConfig.on_pace;

  return (
    <div className="bg-card rounded-2xl border border-border overflow-hidden">
      <div className="p-5 sm:p-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-muted-foreground uppercase tracking-wide">
            {unit} {Math.min(toDisplayIndex(currentKm + 1), totalDisplay)} of {totalDisplay}
          </span>
          <div className="flex items-center gap-1.5">
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-md border ${scenario.color}`}>
              {scenario.label}
            </span>
            {onSkip && (
              <button
                type="button"
                onClick={onSkip}
                aria-label="Skip to the next pace-matched track"
                className="w-11 h-11 -mr-2 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/60 active:scale-95 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <SkipForward className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center shrink-0">
            <Music className="w-6 h-6 text-primary" />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="font-heading font-semibold text-base sm:text-lg truncate">{track.title}</h3>
            <p className="text-sm text-muted-foreground truncate">{track.artist}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm font-medium text-primary">{track.bpm} BPM</span>
              {track.energy && <span className="text-xs text-muted-foreground">· {track.energy}</span>}
            </div>
          </div>
        </div>
      </div>

      {nextTrack && (
        <div className="border-t border-border p-4 bg-muted/30">
          <p className="text-xs text-muted-foreground mb-2">Up next — {unit} {Math.min(toDisplayIndex(currentKm + 2), totalDisplay)}</p>
          <div className="flex items-center gap-3">
            <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium truncate">{nextTrack.title}</p>
              <p className="text-sm text-muted-foreground truncate">{nextTrack.artist} · {nextTrack.bpm} BPM</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}