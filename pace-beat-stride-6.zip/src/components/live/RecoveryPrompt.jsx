import React, { useMemo, useState } from 'react';
import { RunClock } from '@/lib/runClock';
import { Button } from '@/components/ui/button';
import { formatDisplayDistance, formatDisplayPace, displayUnit } from '@/lib/units';
import { AlertTriangle, History, Play, Trash2 } from 'lucide-react';

function formatElapsed(totalSec) {
  const s = Math.max(0, Math.floor(totalSec));
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  return `${h}:${String(m % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

/**
 * Recovery screen for a reopened unfinished run (Stage B / R2, Batch B2).
 * plan comes from planRecovery(): 'checkpoint' (exact restore), 'legacy'
 * (approximate restore, disclosed) or 'discard_only'.
 */
export default function RecoveryPrompt({ run, plan, onResume, onDiscard }) {
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);

  const saved = useMemo(() => {
    if (plan.mode !== 'checkpoint' || !plan.checkpoint) return null;
    const clock = RunClock.fromState(plan.checkpoint.clock);
    return {
      distanceKm: plan.checkpoint.distance_m / 1000,
      elapsedSec: Math.floor(clock.elapsedMs(Date.now()) / 1000),
      splits: plan.checkpoint.splits.length,
      ageMin: Math.max(0, Math.floor((Date.now() - plan.checkpoint.at_ms) / 60000)),
    };
  }, [plan]);

  const handleDiscard = async () => {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    setBusy(true);
    try {
      await onDiscard();
    } finally {
      setBusy(false);
    }
  };

  const handleResume = async () => {
    setBusy(true);
    try {
      await onResume();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-10 max-w-2xl mx-auto">
      <div className="bg-card rounded-2xl border border-border p-5">
        <div className="flex items-center gap-2 mb-3">
          <History className="w-5 h-5 text-primary" />
          <span className="text-sm font-medium text-primary">Unfinished run</span>
        </div>
        <h1 className="font-heading text-2xl font-bold mb-1">
          Resume your {formatDisplayDistance(run.target_distance_km, 1)} {displayUnit()} run?
        </h1>
        {run.target_pace_per_km > 0 && (
          <p className="text-sm text-muted-foreground mb-4">
            Target pace: {formatDisplayPace(run.target_pace_per_km)} /{displayUnit()}
          </p>
        )}

        {plan.mode === 'checkpoint' && saved && (
          <>
            <p className="text-sm text-muted-foreground mb-4">
              Progress was saved {saved.ageMin === 0 ? 'moments' : `${saved.ageMin} min`} ago.
            </p>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-muted/50 rounded-xl p-3 text-center">
                <p className="text-lg font-bold font-heading">{formatDisplayDistance(saved.distanceKm, 2)}</p>
                <p className="text-xs text-muted-foreground">{displayUnit()} done</p>
              </div>
              <div className="bg-muted/50 rounded-xl p-3 text-center">
                <p className="text-lg font-bold font-heading">{formatElapsed(saved.elapsedSec)}</p>
                <p className="text-xs text-muted-foreground">active time</p>
              </div>
              <div className="bg-muted/50 rounded-xl p-3 text-center">
                <p className="text-lg font-bold font-heading">{saved.splits}</p>
                <p className="text-xs text-muted-foreground">km splits</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mb-4 flex items-start gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              Elapsed time excludes pauses, exactly as recorded during the run.
            </p>
          </>
        )}

        {plan.mode === 'legacy' && (
          <p className="text-sm text-muted-foreground mb-4">
            This run was started before progress saving existed. Resuming keeps the original
            start time, but elapsed time is approximate: it assumes no pauses were taken.
          </p>
        )}

        {plan.mode === 'discard_only' && (
          <p className="text-sm text-muted-foreground mb-4">
            This run has no saved progress, so it cannot be resumed. You can discard it to clear
            it from your active runs.
          </p>
        )}

        <div className="flex gap-3">
          {(plan.mode === 'checkpoint' || plan.mode === 'legacy') && (
            <Button onClick={handleResume} disabled={busy} size="lg" className="flex-1 rounded-xl">
              <Play className="w-5 h-5 mr-2" />
              {plan.mode === 'legacy' ? 'Resume (approximate)' : 'Resume Run'}
            </Button>
          )}
          <Button
            onClick={handleDiscard}
            disabled={busy}
            variant={confirming ? 'destructive' : 'outline'}
            size="lg"
            className="flex-1 rounded-xl"
          >
            <Trash2 className="w-5 h-5 mr-2" />
            {confirming ? 'Confirm Discard' : 'Discard'}
          </Button>
        </div>
        {confirming && (
          <p className="text-xs text-muted-foreground text-center mt-3">
            The run will be kept in your history as discarded, without results.
          </p>
        )}
      </div>
    </div>
  );
}