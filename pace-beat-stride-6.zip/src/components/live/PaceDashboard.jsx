import React from 'react';
import { formatTime, getPaceColor } from '@/lib/paceUtils';
import { formatDisplayPace, formatDisplayDistance, displayUnit } from '@/lib/units';
import { Clock, Flag, TrendingUp } from 'lucide-react';

export default function PaceDashboard({ tracker, targetDistanceKm, targetTimeMin }) {
  const { distanceKm, currentPace, elapsedSec, paceDeviation, targetPace } = tracker;
  const unit = displayUnit();
  const progress = targetDistanceKm > 0 ? Math.min((distanceKm / targetDistanceKm) * 100, 100) : 0;
  const projectedSec = currentPace > 0 ? elapsedSec + (targetDistanceKm - distanceKm) * currentPace * 60 : 0;

  const deviationLabel = paceDeviation <= 0 ? 'Ahead of pace' : paceDeviation <= 0.15 ? 'Slightly behind' : 'Behind pace';
  const deviationBadge = paceDeviation <= 0
    ? 'bg-primary/10 text-primary'
    : paceDeviation <= 0.15
    ? 'bg-chart-3/10 text-chart-3'
    : 'bg-destructive/10 text-destructive';

  return (
    <div className="bg-card rounded-2xl border border-border p-5 sm:p-6 space-y-4">
      <div className="text-center">
        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Current Pace</p>
        <p className={`font-heading font-bold text-5xl sm:text-6xl ${getPaceColor(paceDeviation)}`}>
          {formatDisplayPace(currentPace)}
        </p>
        <p className="text-sm text-muted-foreground mt-1">Target: {formatDisplayPace(targetPace)} /{unit}</p>
      </div>

      <div className="flex justify-center">
        <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${deviationBadge}`}>
          <TrendingUp className="w-3 h-3" />
          {deviationLabel} ({paceDeviation > 0 ? '+' : ''}{(paceDeviation * 100).toFixed(0)}%)
        </div>
      </div>

      <div>
        <div className="flex justify-between text-sm mb-1.5">
          <span className="font-medium">{formatDisplayDistance(distanceKm)} / {formatDisplayDistance(targetDistanceKm, 1)} {unit}</span>
          <span className="text-muted-foreground">{progress.toFixed(0)}%</span>
        </div>
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-muted/50 rounded-xl p-3 text-center">
          <Clock className="w-4 h-4 text-muted-foreground mx-auto mb-1" />
          <p className="font-heading font-bold text-lg">{formatTime(elapsedSec)}</p>
          <p className="text-xs text-muted-foreground">Elapsed</p>
        </div>
        <div className="bg-muted/50 rounded-xl p-3 text-center">
          <Flag className="w-4 h-4 text-muted-foreground mx-auto mb-1" />
          <p className="font-heading font-bold text-lg">{formatTime(projectedSec)}</p>
          <p className="text-xs text-muted-foreground">Projected</p>
        </div>
      </div>
    </div>
  );
}