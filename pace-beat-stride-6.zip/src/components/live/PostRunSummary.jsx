import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle2, Trophy, MapPin, Clock, Gauge, Target, Music, TrendingDown, TrendingUp } from 'lucide-react';
import { formatTime } from '@/lib/paceUtils';
import { formatDisplayPace, formatDisplayDistance, displayUnit } from '@/lib/units';
import ShareRunButton from '@/components/share/ShareRunButton';

function StatCard({ icon: Icon, label, value, target, accent }) {
  return (
    <div className="bg-card rounded-xl border border-border p-4 text-center">
      <Icon className={`w-4 h-4 mx-auto mb-1.5 ${accent || 'text-muted-foreground'}`} />
      <p className="text-sm text-muted-foreground mb-1">{label}</p>
      <p className="font-heading font-bold text-lg sm:text-xl">{value}</p>
      {target && <p className="text-sm text-muted-foreground mt-0.5">Target: {target}</p>}
    </div>
  );
}

export default function PostRunSummary({ run, tracker }) {
  const unit = displayUnit();
  const actualPace = tracker.distanceKm > 0 ? tracker.elapsedSec / 60 / tracker.distanceKm : 0;
  const targetPace = run.target_pace_per_km || 0;
  const beatTarget = tracker.distanceKm >= run.target_distance_km * 0.95 && tracker.elapsedSec / 60 <= run.target_time_min;
  const paceDiff = actualPace - targetPace;
  const paceFaster = paceDiff < 0;
  const distancePercent = run.target_distance_km > 0 ? Math.min(100, (tracker.distanceKm / run.target_distance_km) * 100) : 0;
  const timeDiffMin = tracker.elapsedSec / 60 - run.target_time_min;
  const trackCount = (run.track_pool || []).reduce((sum, seg) => sum + (seg.tracks?.length || 0), 0);
  const shareText = `Just ran ${formatDisplayDistance(tracker.distanceKm)} ${unit} in ${formatTime(tracker.elapsedSec)} (${formatDisplayPace(actualPace)} /${unit}) with PacePlay${beatTarget ? ' — beat my target time!' : ''} 🎧🏃`;

  return (
    <div className="p-4 sm:p-6 md:p-10 max-w-2xl mx-auto">
      {/* Header */}
      <div className="text-center mb-6">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${beatTarget ? 'bg-primary/10' : 'bg-accent/10'}`}>
          {beatTarget ? <Trophy className="w-8 h-8 text-primary" /> : <CheckCircle2 className="w-8 h-8 text-accent" />}
        </div>
        <h1 className="font-heading text-2xl sm:text-3xl font-bold mb-1">Run Complete!</h1>
        <p className="text-sm text-muted-foreground">
          {beatTarget
            ? 'You beat your target time!'
            : tracker.distanceKm >= run.target_distance_km * 0.95
              ? 'Great effort — you finished the distance.'
              : 'Run ended early. Every step counts!'}
        </p>
      </div>

      {/* Key Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <StatCard icon={MapPin} label="Distance" value={`${formatDisplayDistance(tracker.distanceKm)} ${unit}`} target={`${formatDisplayDistance(run.target_distance_km)} ${unit}`} />
        <StatCard icon={Clock} label="Time" value={formatTime(tracker.elapsedSec)} target={`${run.target_time_min}:00`} />
        <StatCard icon={Gauge} label="Avg Pace" value={formatDisplayPace(actualPace)} target={formatDisplayPace(targetPace)} accent={paceFaster ? 'text-primary' : 'text-chart-3'} />
        <StatCard icon={Target} label="Target Pace" value={formatDisplayPace(targetPace)} />
      </div>

      {/* Performance Analysis */}
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Trophy className="w-4 h-4 text-primary" />
            Performance vs Target
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Distance progress */}
          <div>
            <div className="flex justify-between text-sm mb-1.5">
              <span className="text-muted-foreground">Distance Completed</span>
              <span className="font-medium">{distancePercent.toFixed(0)}%</span>
            </div>
            <div className="h-2.5 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${distancePercent}%` }} />
            </div>
          </div>

          {/* Pace comparison */}
          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              {paceFaster ? <TrendingDown className="w-4 h-4 text-primary" /> : <TrendingUp className="w-4 h-4 text-chart-3" />}
              <span className="text-sm font-medium">Pace</span>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold">
                {paceFaster ? 'Faster' : 'Slower'} by {formatDisplayPace(Math.abs(paceDiff))} /{unit}
              </p>
              <p className="text-sm text-muted-foreground">{formatDisplayPace(actualPace)} vs {formatDisplayPace(targetPace)}</p>
            </div>
          </div>

          {/* Time comparison */}
          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">Time</span>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold">
                {timeDiffMin <= 0 ? `${Math.abs(timeDiffMin).toFixed(1)} min under` : `${timeDiffMin.toFixed(1)} min over`}
              </p>
              <p className="text-sm text-muted-foreground">{formatTime(tracker.elapsedSec)} vs {run.target_time_min}:00 target</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Per-KM Splits */}
      {tracker.splits?.length > 0 && (
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Gauge className="w-4 h-4 text-primary" />
              Kilometer Splits
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {tracker.splits.map((split, i) => {
                const faster = split.paceMinPerKm < targetPace;
                return (
                  <div key={i} className="flex items-center justify-between px-4 py-2.5">
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                        {split.km}
                      </span>
                      <div>
                        <p className="text-sm font-medium">{formatDisplayPace(split.paceMinPerKm)} /{unit}</p>
                        <p className="text-sm text-muted-foreground">{formatTime(Math.round(split.splitTimeSec))} split</p>
                      </div>
                    </div>
                    {faster
                      ? <span className="text-sm font-medium text-primary flex items-center gap-1"><TrendingDown className="w-3 h-3" /> On target</span>
                      : <span className="text-sm font-medium text-chart-3 flex items-center gap-1"><TrendingUp className="w-3 h-3" /> Slower</span>
                    }
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Music Summary */}
      {run.track_pool?.length > 0 && (
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Music className="w-4 h-4 text-accent" />
              Music Playlist · {trackCount} tracks
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border max-h-60 overflow-y-auto">
              {run.track_pool.map((seg, i) => (
                <div key={i} className="px-4 py-2.5">
                  <p className="text-sm font-medium text-muted-foreground mb-1.5">
                    KM {seg.km} · {seg.target_bpm} BPM target
                  </p>
                  <div className="space-y-1">
                    {seg.tracks?.map((t, j) => (
                      <div key={j} className="flex items-center gap-2 text-sm">
                        <span className={`w-2 h-2 rounded-full shrink-0 ${t.scenario === 'on_pace' ? 'bg-primary' : t.scenario === 'behind_pace' ? 'bg-chart-3' : 'bg-chart-4'}`} />
                        <span className="font-medium truncate flex-1">{t.title}</span>
                        <span className="text-xs text-muted-foreground hidden sm:inline truncate max-w-24">{t.artist}</span>
                        <span className="text-sm font-medium text-primary shrink-0">{t.bpm}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="space-y-3">
        <ShareRunButton text={shareText} />
        <Link to="/live-run"><Button variant="outline" className="w-full">New Live Run</Button></Link>
        <Link to="/"><Button variant="ghost" className="w-full">Back Home</Button></Link>
      </div>
    </div>
  );
}