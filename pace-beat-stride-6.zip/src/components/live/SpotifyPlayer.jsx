import React from 'react';
import { Music, Play, Pause, Loader2, AlertCircle, Smartphone, Laptop, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SpotifyPlayer({ player, spotifyToken }) {
  if (!spotifyToken) {
    return (
      <div className="bg-muted/50 rounded-xl p-4 text-center">
        <Music className="w-5 h-5 text-muted-foreground mx-auto mb-2" />
        <p className="text-sm font-medium mb-1">Spotify not connected</p>
        <p className="text-xs text-muted-foreground">Connect Spotify from the home page to enable live music playback during your run.</p>
      </div>
    );
  }

  if (player.error) {
    return (
      <div className="bg-destructive/5 border border-destructive/20 rounded-xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm font-medium text-destructive mb-0.5">Playback unavailable</p>
          <p className="text-xs text-destructive/80">{player.error}</p>
          <Button
            variant="outline"
            size="sm"
            className="mt-2 h-7 text-xs"
            onClick={player.refreshDevices}
          >
            <RefreshCw className="w-3 h-3 mr-1" /> Retry
          </Button>
        </div>
      </div>
    );
  }

  if (!player.isReady) {
    return (
      <div className="bg-muted/50 rounded-xl p-4">
        <div className="flex items-center justify-center gap-2 mb-3">
          <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Looking for Spotify devices...</p>
        </div>
        {player.devices?.length > 0 ? (
          <div className="space-y-1.5 no-scrollbar">
            <p className="text-xs text-muted-foreground mb-2">Select a device to play on:</p>
            {player.devices.map(d => (
              <button
                key={d.id}
                onClick={() => player.transferPlayback(d.id)}
                aria-label={`Play on ${d.name}`}
                className="w-full flex items-center gap-2 p-2 rounded-lg hover:bg-accent/10 transition-colors text-left"
              >
                {d.type === 'phone' ? <Smartphone className="w-4 h-4 text-primary" /> : <Laptop className="w-4 h-4 text-primary" />}
                <span className="text-sm font-medium flex-1">{d.name}</span>
                <span className="text-xs text-muted-foreground">{d.is_active ? 'Active' : 'Tap to use'}</span>
              </button>
            ))}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground text-center">
            Open Spotify on your phone or computer and play any song to make it appear here.
          </p>
        )}
      </div>
    );
  }

  const { progressMs = 0, durationMs = 0 } = player.playbackState || {};

  return (
    <div className="bg-card rounded-xl border border-border p-3">
      <div className="flex items-center gap-3">
        <Button
          size="icon"
          onClick={player.togglePlay}
          className="rounded-full w-10 h-10 shrink-0"
        >
          {player.isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <span className="text-xs font-medium text-primary">Playing on {player.activeDevice?.name || 'Spotify'}</span>
          </div>
          <p className="text-xs text-muted-foreground">
            {player.isPlaying ? 'Playing' : 'Paused'} · Auto-selecting tracks by pace
          </p>
        </div>
      </div>
      {durationMs > 0 && (
        <div className="mt-2 h-1 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-[width] duration-1000 ease-linear"
            style={{ width: `${Math.min(100, Math.max(0, (progressMs / durationMs) * 100))}%` }}
          />
        </div>
      )}
    </div>
  );
}