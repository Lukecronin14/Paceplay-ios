import React, { useEffect, useState } from 'react';
import { Loader2, Check } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const STEPS = [
  'Reading your music taste',
  'Analysing terrain and target pace',
  'Matching BPM to every kilometre',
  'Finalising your playlist',
];

export default function GeneratingPlaylistProgress({ segments = 0 }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setStep((s) => Math.min(s + 1, STEPS.length - 1));
    }, 2500);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-4" role="status" aria-live="polite">
      <div className="flex items-center gap-2 text-sm font-medium text-primary">
        <Loader2 className="w-4 h-4 animate-spin" />
        Building your playlist — this can take a moment
      </div>
      <ol className="space-y-2">
        {STEPS.map((label, i) => (
          <li key={label} className="flex items-center gap-2.5 text-sm">
            {i < step ? (
              <Check className="w-4 h-4 text-primary shrink-0" />
            ) : i === step ? (
              <Loader2 className="w-4 h-4 animate-spin text-primary shrink-0" />
            ) : (
              <span className="w-4 h-4 rounded-full border border-border shrink-0" />
            )}
            <span className={i <= step ? 'text-foreground' : 'text-muted-foreground'}>{label}</span>
          </li>
        ))}
      </ol>
      {segments > 0 ? (
        <div className="space-y-2 pt-1" aria-hidden="true">
          {Array.from({ length: segments }).map((_, i) => (
            <div key={i} className="rounded-lg border border-border/60 bg-card/50 p-3 space-y-2.5">
              <div className="flex items-center justify-between">
                <Skeleton className="h-4 w-16 rounded" />
                <Skeleton className="h-4 w-24 rounded" />
              </div>
              {[0, 1, 2].map((t) => (
                <div key={t} className="flex items-center gap-2">
                  <Skeleton className="w-2 h-2 rounded-full shrink-0" />
                  <Skeleton className="h-4 flex-1 rounded" />
                  <Skeleton className="h-4 w-10 rounded shrink-0" />
                </div>
              ))}
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-2 pt-1">
          <Skeleton className="h-11 w-full rounded-lg" />
          <Skeleton className="h-11 w-full rounded-lg" />
          <Skeleton className="h-11 w-2/3 rounded-lg" />
        </div>
      )}
    </div>
  );
}