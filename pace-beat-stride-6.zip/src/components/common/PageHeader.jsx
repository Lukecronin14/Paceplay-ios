import React from 'react';
import { ArrowLeft, Footprints } from 'lucide-react';

export default function PageHeader({ title, logo = false, onBack }) {
  return (
    <div
      className="sticky top-0 z-30 bg-background/95 backdrop-blur -mx-4 sm:-mx-6 md:-mx-10 px-4 sm:px-6 md:px-10 py-3 border-b border-border"
      style={{ top: 'env(safe-area-inset-top)' }}
    >
      <div className="flex items-center gap-1">
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            aria-label="Go back"
            className="-ml-2 w-11 h-11 flex items-center justify-center rounded-lg hover:bg-muted/60 active:scale-95 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        )}
        {logo ? (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <Footprints className="w-4 h-4" />
            </div>
            {title && <h1 className="font-heading font-bold text-base sm:text-lg leading-tight">{title}</h1>}
          </div>
        ) : (
          title && <h1 className="font-heading font-bold text-base sm:text-lg leading-tight">{title}</h1>
        )}
      </div>
    </div>
  );
}