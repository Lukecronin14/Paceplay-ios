import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Top-level error boundary: without it, any render error unmounts the whole
// app to a blank page that only a manual reload recovers from.
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    console.error('App render error:', error, info?.componentStack);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-background">
          <div className="text-center space-y-4 max-w-sm">
            <div className="w-14 h-14 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-7 h-7 text-destructive" />
            </div>
            <h2 className="font-heading text-xl font-bold">Something went wrong</h2>
            <p className="text-sm text-muted-foreground">
              An unexpected error occurred. Reload to get back to the app.
            </p>
            {this.state.error?.message && (
              <p className="text-xs text-muted-foreground break-words">
                {String(this.state.error.message)}
              </p>
            )}
            <Button onClick={() => window.location.reload()} className="w-full">
              <RefreshCw className="w-4 h-4" /> Reload app
            </Button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}