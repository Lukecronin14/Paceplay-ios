import React, { useState, useRef, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';

const THRESHOLD = 70;
const RESISTANCE = 0.5;

// True when the touch target sits inside a nested scrollable container
// (overflow-y-auto / overflow-auto / scroll) — let that container scroll
// normally instead of triggering pull-to-refresh.
const isInNestedScrollable = (el) => {
  let node = el;
  while (node && node !== document.body && node !== document.documentElement) {
    const overflowY = window.getComputedStyle(node).overflowY;
    if (overflowY === 'auto' || overflowY === 'scroll') return true;
    node = node.parentElement;
  }
  return false;
};

export default function PullToRefresh({ enabled = true, onRefresh, children }) {
  const startYRef = useRef(0);
  const pullingRef = useRef(false);
  const pullRef = useRef(0);
  const refreshingRef = useRef(false);
  const onRefreshRef = useRef(onRefresh);
  onRefreshRef.current = onRefresh;

  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    const setPullBoth = (v) => { pullRef.current = v; setPull(v); };
    const scrollTop = () => window.scrollY || document.documentElement.scrollTop || 0;

    const onStart = (e) => {
      if (isInNestedScrollable(e.target)) {
        pullingRef.current = false;
        return;
      }
      if (scrollTop() <= 0 && !refreshingRef.current) {
        startYRef.current = e.touches[0].clientY;
        pullingRef.current = true;
      } else {
        pullingRef.current = false;
      }
    };
    const onMove = (e) => {
      if (!pullingRef.current) return;
      const delta = e.touches[0].clientY - startYRef.current;
      if (delta > 0 && scrollTop() <= 0) {
        e.preventDefault();
        setPullBoth(Math.min(delta * RESISTANCE, THRESHOLD * 1.4));
      } else if (delta <= 0 && pullRef.current > 0) {
        setPullBoth(0);
      }
    };
    const onEnd = async () => {
      if (!pullingRef.current) return;
      pullingRef.current = false;
      if (pullRef.current >= THRESHOLD) {
        refreshingRef.current = true;
        setRefreshing(true);
        setPullBoth(THRESHOLD);
        try {
          await onRefreshRef.current?.();
        } finally {
          refreshingRef.current = false;
          setRefreshing(false);
          setPullBoth(0);
        }
      } else {
        setPullBoth(0);
      }
    };

    window.addEventListener('touchstart', onStart, { passive: true });
    window.addEventListener('touchmove', onMove, { passive: false });
    window.addEventListener('touchend', onEnd, { passive: true });
    window.addEventListener('touchcancel', onEnd, { passive: true });
    return () => {
      window.removeEventListener('touchstart', onStart);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onEnd);
      window.removeEventListener('touchcancel', onEnd);
    };
  }, [enabled]);

  const active = enabled && (pull > 0 || refreshing);

  return (
    <>
      {active && (
        <div
          className="flex items-center justify-center pointer-events-none"
          style={{ position: 'fixed', top: 0, left: 0, right: 0, height: pull, zIndex: 60 }}
        >
          <RefreshCw
            className={refreshing ? 'animate-spin text-primary' : 'text-muted-foreground'}
            style={{
              transform: `rotate(${pull * 3}deg)`,
              transition: refreshing ? 'none' : 'transform 0.15s ease',
            }}
          />
        </div>
      )}
      {children}
    </>
  );
}