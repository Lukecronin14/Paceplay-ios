import React, { useState, useEffect, Suspense, lazy } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Home as HomeIcon, Map, Music, Activity, User, Loader2 } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { useSubscription } from '@/hooks/useSubscription';
import { useTokenRefresh } from '@/hooks/useTokenRefresh';
import FeatureLock from '@/components/subscription/FeatureLock';
const Home = lazy(() => import('@/pages/Home'));
const LiveRunSetup = lazy(() => import('@/pages/LiveRunSetup'));
const Account = lazy(() => import('@/pages/Account'));
const RoutesHub = lazy(() => import('@/pages/RoutesHub'));

const navItems = [
  { path: '/', icon: HomeIcon, label: 'Home' },
  { path: '/live-run', icon: Activity, label: 'Live' },
  { path: '/routes', icon: Map, label: 'Routes' },
  { path: '/account', icon: User, label: 'Account' },
];

// Bottom-nav tab pages kept mounted (keep-alive) so switching tabs preserves state.
const tabComponents = {
  '/': Home,
  '/routes': RoutesHub,
  '/live-run': LiveRunSetup,
  '/account': Account,
};

// Returns the bottom-nav tab a given pathname belongs to (exact or a sub-route of it).
const findTabRoot = (pathname) =>
  navItems.find(({ path }) => {
    if (path === '/') return pathname === '/';
    return pathname === path || pathname.startsWith(path + '/');
  })?.path;

function TabLoader() {
  return (
    <div className="flex items-center justify-center min-h-[40vh]">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
    </div>
  );
}

export default function AppLayout() {
  const { pathname } = useLocation();
  const { user } = useAuth();
  const { isLoading: subLoading, hasAccess } = useSubscription();
  useTokenRefresh();

  // Home, Parkruns and the Account hub are browsable without a subscription;
  // the gated feature pages themselves keep their lock.
  const isPublicPath = (p) => p === '/' || p.startsWith('/routes') || p.startsWith('/parkruns') || p.startsWith('/account');
  const isGatedPath = (p) => !isPublicPath(p);
  const authorizedForPath = (p) => {
    if (p === '/admin/users') return user?.role === 'admin';
    if (!user) return false;
    if (user.role === 'admin') return true;
    if (subLoading) return true; // avoid a flash while the subscription resolves
    return !!hasAccess;
  };

  const [visited, setVisited] = useState(() => {
    const tab = Object.keys(tabComponents).find((p) => p === pathname);
    return tab ? [tab] : [];
  });

  // Remember each tab's last deep sub-route so re-tapping the tab restores it.
  const [tabStack, setTabStack] = useState({});

  useEffect(() => {
    const tab = Object.keys(tabComponents).find((p) => p === pathname);
    if (tab) setVisited((prev) => (prev.includes(tab) ? prev : [...prev, tab]));
  }, [pathname]);

  useEffect(() => {
    const tabRoot = findTabRoot(pathname);
    if (tabRoot && pathname !== tabRoot) {
      setTabStack((prev) => (prev[tabRoot] === pathname ? prev : { ...prev, [tabRoot]: pathname }));
    }
  }, [pathname]);

  const isTabRoot = Object.prototype.hasOwnProperty.call(tabComponents, pathname);

  return (
    <div className="min-h-screen bg-background font-body">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex fixed left-0 top-0 bottom-0 w-64 flex-col bg-card border-r border-border z-40" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="p-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <Music className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-heading font-bold text-lg leading-tight">PacePlay</h1>
              <p className="text-xs text-muted-foreground">Run to your rhythm</p>
            </div>
          </Link>
        </div>
        <nav className="flex-1 px-3 space-y-1">
          {navItems.map(({ path, icon: Icon, label }) => {
            const active = pathname === path || (path !== '/' && pathname.startsWith(path));
            return (
              <Link
                key={path}
                to={active ? path : (tabStack[path] || path)}
                onClick={() => {
                  if (active) setTabStack((prev) => {
                    const next = { ...prev };
                    delete next[path];
                    return next;
                  });
                }}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all
                  ${active
                    ? 'bg-primary/10 text-primary'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
              >
                <Icon className="w-5 h-5" />
                {label}
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-border">
          <p className="text-xs text-muted-foreground text-center">Powered by AI playlist matching</p>
        </div>
      </aside>

      {/* Main content */}
      <main className="md:ml-64 min-h-screen pb-safe" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        {visited.map((path) => {
          const Comp = tabComponents[path];
          const isActive = pathname === path;
          const locked = isGatedPath(path) && !authorizedForPath(path);
          return (
            <motion.div
              key={path}
              initial={{ opacity: 0, x: 12 }}
              animate={isActive ? { opacity: 1, x: 0 } : { opacity: 0, x: 12 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
              className={isActive ? '' : 'hidden'}
              aria-hidden={!isActive}
            >
              {locked ? <FeatureLock /> : (
                <Suspense fallback={<TabLoader />}>
                  <Comp />
                </Suspense>
              )}
            </motion.div>
          );
        })}
        <AnimatePresence mode="wait">
          {!isTabRoot && (
            <motion.div
              key={pathname}
              initial={{ x: '100%', opacity: 0.9 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0.9 }}
              transition={{ type: 'tween', ease: 'easeInOut', duration: 0.28 }}
            >
              {isGatedPath(pathname) && !authorizedForPath(pathname) ? <FeatureLock /> : <Outlet />}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card/95 backdrop-blur-xl border-t border-border z-40" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        <div className="flex items-center justify-around py-2 px-2">
          {navItems.map(({ path, icon: Icon, label }) => {
            const active = pathname === path || (path !== '/' && pathname.startsWith(path));
            return (
              <Link
                key={path}
                to={active ? path : (tabStack[path] || path)}
                aria-label={`Go to ${label}`}
                onClick={() => {
                  if (active) setTabStack((prev) => {
                    const next = { ...prev };
                    delete next[path];
                    return next;
                  });
                }}
                className={`flex flex-col items-center gap-1 px-2 py-3 rounded-lg transition-all flex-1
                  ${active ? 'text-primary' : 'text-muted-foreground'}`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs font-medium">{label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}