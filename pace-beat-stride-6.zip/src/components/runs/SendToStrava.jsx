import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Upload, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

export default function SendToStrava({ run }) {
  const [status, setStatus] = useState('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const accessToken = localStorage.getItem('strava_access_token');
  const hasRoute = run.route ? run.route.length >= 2 : run.has_route;

  if (!hasRoute) {
    return <p className="text-xs text-muted-foreground">No GPS route recorded for this run.</p>;
  }

  if (!accessToken) {
    return <p className="text-xs text-muted-foreground">Connect Strava on the home page to export this route.</p>;
  }

  const handleExport = async () => {
    setStatus('uploading');
    setErrorMsg('');
    try {
      // The run may be a lightweight summary (history list) — fetch the full record on export
      const full = await base44.entities.LiveRun.get(run.id);
      const route = full.route || [];
      if (route.length < 2) {
        setStatus('error');
        setErrorMsg('No GPS route recorded for this run.');
        return;
      }
      const date = full.start_time
        ? new Date(full.start_time).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
        : new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
      const res = await base44.functions.invoke('stravaIntegration', {
        action: 'uploadGpx',
        accessToken,
        expiresAt: localStorage.getItem('strava_expires_at'),
        name: `PacePlay Run · ${date}`,
        description: 'Tracked with PacePlay — AI-adaptive running playlists that match your pace. 🎧🏃 https://pace-beat-stride.base44.app',
        route,
        startTime: full.start_time || new Date(route[0].t).toISOString(),
      });

      if (res.data?.error) {
        setStatus('error');
        setErrorMsg(res.data.error);
        return;
      }
      if (res.data?.accessToken && res.data?.expiresAt) {
        localStorage.setItem('strava_access_token', res.data.accessToken);
        localStorage.setItem('strava_expires_at', String(res.data.expiresAt));
      }
      setStatus('success');
    } catch (err) {
      setStatus('error');
      setErrorMsg(err.message || 'Failed to upload to Strava');
    }
  };

  if (status === 'success') {
    return (
      <div className="flex items-center gap-2 text-sm text-orange-600 dark:text-orange-400 font-medium">
        <CheckCircle2 className="w-4 h-4" />
        <span>Sent to Strava! Check your activities.</span>
      </div>
    );
  }

  return (
    <div>
      <Button
        onClick={handleExport}
        disabled={status === 'uploading'}
        variant="outline"
        size="sm"
        className="border-orange-300 dark:border-orange-700 text-orange-700 dark:text-orange-400 hover:bg-orange-50 dark:hover:bg-orange-950 rounded-xl"
      >
        {status === 'uploading' ? (
          <><Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> Uploading...</>
        ) : (
          <><Upload className="w-4 h-4 mr-1.5" /> Send to Strava</>
        )}
      </Button>
      {status === 'error' && (
        <p className="text-xs text-destructive mt-2 flex items-center gap-1">
          <AlertCircle className="w-3 h-3 shrink-0" /> {errorMsg}
        </p>
      )}
    </div>
  );
}