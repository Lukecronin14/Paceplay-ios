import React from 'react';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { ShieldAlert } from 'lucide-react';

const UserNotRegisteredError = () => {
  const { logout } = useAuth();
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/10 p-4">
      <div className="max-w-md w-full text-center">
        <div className="w-16 h-16 rounded-2xl bg-amber-100 dark:bg-amber-900 flex items-center justify-center mx-auto mb-6">
          <ShieldAlert className="w-8 h-8 text-amber-600 dark:text-amber-400" />
        </div>
        <h1 className="font-heading text-2xl font-bold mb-3">Account not activated</h1>
        <p className="text-muted-foreground mb-6">
          You're signed in, but this account doesn't have access to PacePlay yet. Ask an admin to invite
          your email, or sign in with a different account.
        </p>
        <Button onClick={() => logout()} variant="outline" className="rounded-xl">
          Sign out and try another account
        </Button>
      </div>
    </div>
  );
};

export default UserNotRegisteredError;