import React, { useState } from 'react';
import { Music, Zap, ChevronDown } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';

const energyColors = {
  low: 'bg-chart-4/10 text-chart-4',
  medium: 'bg-chart-3/10 text-chart-3',
  high: 'bg-primary/10 text-primary',
  very_high: 'bg-chart-5/10 text-chart-5',
};

const terrainColors = {
  steep_uphill: 'bg-red-100 text-red-700 dark:bg-red-900/60 dark:text-red-300',
  uphill: 'bg-orange-100 text-orange-700 dark:bg-orange-900/60 dark:text-orange-300',
  slight_uphill: 'bg-amber-100 text-amber-700 dark:bg-amber-900/60 dark:text-amber-300',
  flat: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300',
  slight_downhill: 'bg-sky-100 text-sky-700 dark:bg-sky-900/60 dark:text-sky-300',
  downhill: 'bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300',
  steep_downhill: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300',
};

const terrainEmoji = {
  steep_uphill: '⛰️',
  uphill: '↗️',
  slight_uphill: '↗',
  flat: '→',
  slight_downhill: '↘',
  downhill: '↘️',
  steep_downhill: '⬇️',
};

export default function PlaylistItem({ track, index }) {
  const [expanded, setExpanded] = useState(false);
  const minutes = Math.floor((track.duration_sec || 0) / 60);
  const seconds = (track.duration_sec || 0) % 60;

  // Derive terrain from segment_km label if available
  const terrainKey = track.terrain || null;
  const terrainLabel = terrainKey ? terrainKey.replace(/_/g, ' ') : null;

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="rounded-xl transition-colors group"
    >
      <div
        className="flex items-start gap-3 p-3 min-h-11 rounded-xl hover:bg-muted/50 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        onClick={() => track.terrain_reason && setExpanded(e => !e)}
        onKeyDown={(e) => {
          if (!track.terrain_reason) return;
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setExpanded(x => !x);
          }
        }}
        role={track.terrain_reason ? 'button' : undefined}
        tabIndex={track.terrain_reason ? 0 : undefined}
        aria-label={track.terrain_reason ? `${track.title} — show terrain match details` : undefined}
        aria-expanded={track.terrain_reason ? expanded : undefined}
      >
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center shrink-0 mt-0.5">
          <Music className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="font-medium text-sm truncate">{track.title}</p>
              <p className="text-sm text-muted-foreground truncate">{track.artist}</p>
            </div>
            <span className="text-sm text-muted-foreground shrink-0 mt-0.5">
              {minutes}:{seconds.toString().padStart(2, '0')}
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
            {track.segment_km && (
              <Badge variant="outline" className="text-sm font-mono">km {track.segment_km}</Badge>
            )}
            <Badge variant="outline" className="text-sm font-mono">
              {track.bpm} BPM
            </Badge>
            <Badge className={`text-sm ${energyColors[track.energy] || 'bg-muted text-muted-foreground'}`}>
              <Zap className="w-3 h-3 mr-0.5" />
              {track.energy}
            </Badge>
            {track.terrain_reason && (
              <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform ml-0.5 ${expanded ? 'rotate-180' : ''}`} />
            )}
          </div>
        </div>
      </div>

      {expanded && track.terrain_reason && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="mx-3 mb-2 px-3 py-2 rounded-lg bg-muted/40 border border-border/50"
        >
          <p className="text-sm text-muted-foreground leading-relaxed">
            <span className="font-medium text-foreground">Why this track: </span>
            {track.terrain_reason}
          </p>
        </motion.div>
      )}
    </motion.div>
  );
}