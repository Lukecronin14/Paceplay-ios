import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Music, Loader2, Check, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { fetchAppleMusicLibraryPlaylists, APPLE_MUSIC_USER_TOKEN_KEY } from '@/lib/appleMusicData';
import { useToast } from '@/components/ui/use-toast';

export default function AppleMusicPlaylistSelector() {
  const connected = !!localStorage.getItem(APPLE_MUSIC_USER_TOKEN_KEY);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selected, setSelected] = useState(new Set());
  const [saving, setSaving] = useState(false);

  const { data: prefs } = useQuery({
    queryKey: ['musicPrefs'],
    queryFn: async () => {
      const list = await base44.entities.MusicPreference.list();
      return list[0] || null;
    },
  });

  const { data: playlists, isLoading, isError } = useQuery({
    queryKey: ['appleMusicPlaylists'],
    queryFn: () => fetchAppleMusicLibraryPlaylists(30),
    enabled: !!connected,
  });

  useEffect(() => {
    if (prefs?.selected_apple_playlists) {
      setSelected(new Set(prefs.selected_apple_playlists.map(p => p.id)));
    }
  }, [prefs]);

  const togglePlaylist = async (playlistId) => {
    const previousSelected = new Set(selected);
    const newSelected = new Set(selected);
    if (newSelected.has(playlistId)) {
      newSelected.delete(playlistId);
    } else {
      newSelected.add(playlistId);
    }
    setSelected(newSelected);

    setSaving(true);
    try {
      const selectedPlaylists = (playlists || [])
        .filter(p => newSelected.has(p.id))
        .map(p => ({ id: p.id, name: p.name, image: p.image, track_count: p.track_count }));

      if (prefs?.id) {
        await base44.entities.MusicPreference.update(prefs.id, {
          selected_apple_playlists: selectedPlaylists,
        });
      } else {
        await base44.entities.MusicPreference.create({
          selected_apple_playlists: selectedPlaylists,
        });
      }
      queryClient.invalidateQueries({ queryKey: ['musicPrefs'] });
    } catch (err) {
      console.error('Failed to save playlist selection:', err);
      setSelected(previousSelected);
      toast({
        title: "Couldn't save your selection",
        description: 'Your playlist selection change was not saved. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  if (!connected) return null;

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="border-rose-200 bg-gradient-to-br from-rose-50 to-red-50 dark:from-rose-950 dark:to-red-950 dark:border-rose-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 font-heading text-base">
            <Music className="w-4 h-4 text-rose-600 dark:text-rose-400" />
            Your Running Playlists
          </CardTitle>
          <p className="text-xs text-rose-700 dark:text-rose-400">
            Select playlists you use for running. We'll prioritise tracks from these when generating new playlists.
          </p>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="w-5 h-5 text-rose-600 dark:text-rose-400 animate-spin" />
            </div>
          ) : isError ? (
            <div className="flex items-start gap-2 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-3">
              <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-red-700 dark:text-red-400 font-medium">Failed to load playlists</p>
                <p className="text-xs text-red-500 dark:text-red-400 mt-0.5">
                  Your Apple Music session may have expired. Try disconnecting and reconnecting Apple Music above.
                </p>
              </div>
            </div>
          ) : playlists?.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">No playlists found in your Apple Music library.</p>
          ) : (
            <div className="space-y-1 max-h-72 overflow-y-auto">
              {playlists?.map(playlist => (
                <label
                  key={playlist.id}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-rose-100/50 dark:hover:bg-rose-900/50 cursor-pointer transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => togglePlaylist(playlist.id)}
                    aria-label={`Toggle ${playlist.name}`}
                    className={`w-11 h-11 rounded-md border-2 flex items-center justify-center shrink-0 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
                      selected.has(playlist.id)
                        ? 'bg-rose-600 border-rose-600 text-white'
                        : 'border-rose-300 bg-white dark:border-rose-700 dark:bg-card'
                    }`}
                  >
                    {selected.has(playlist.id) && <Check className="w-3.5 h-3.5" />}
                  </button>
                  {playlist.image ? (
                    <img src={playlist.image} alt="" className="w-9 h-9 rounded object-cover shrink-0" />
                  ) : (
                    <div className="w-9 h-9 rounded bg-rose-200 dark:bg-rose-800 flex items-center justify-center shrink-0">
                      <Music className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{playlist.name}</p>
                    {playlist.track_count != null && (
                      <p className="text-xs text-muted-foreground">{playlist.track_count} tracks</p>
                    )}
                  </div>
                </label>
              ))}
            </div>
          )}
          <div className="mt-2 h-4">
            {saving ? (
              <p className="text-xs text-rose-600 dark:text-rose-400 flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" /> Saving...
              </p>
            ) : selected.size > 0 ? (
              <p className="text-xs text-rose-600 dark:text-rose-400">
                {selected.size} playlist{selected.size !== 1 ? 's' : ''} selected
              </p>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}