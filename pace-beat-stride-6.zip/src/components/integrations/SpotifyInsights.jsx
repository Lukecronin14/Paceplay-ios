import React from 'react';
import { Music2, Mic2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SpotifyInsights({ profile }) {
  if (!profile) return null;

  // Flatten all genres from top artists and deduplicate
  const genres = [...new Set(
    (profile.topArtists || []).flatMap(a => a.genres || [])
  )].slice(0, 12);

  const artists = profile.topArtists || [];

  if (genres.length === 0 && artists.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="grid md:grid-cols-2 gap-4"
    >
      {/* Top Genres */}
      {genres.length > 0 && (
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg bg-accent/10 flex items-center justify-center">
              <Music2 className="w-4 h-4 text-accent" />
            </div>
            <h3 className="font-heading font-semibold text-sm">Your Top Genres</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {genres.map((genre, i) => (
              <span
                key={i}
                className="px-3 py-1 rounded-full text-xs font-medium capitalize"
                style={{
                  backgroundColor: `hsl(${(i * 37 + 154) % 360} 60% 92%)`,
                  color: `hsl(${(i * 37 + 154) % 360} 60% 30%)`,
                }}
              >
                {genre}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Recent Artists */}
      {artists.length > 0 && (
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
              <Mic2 className="w-4 h-4 text-primary" />
            </div>
            <h3 className="font-heading font-semibold text-sm">Artists You're Listening To</h3>
          </div>
          <div className="space-y-2.5">
            {artists.map((artist, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="text-xs font-mono text-muted-foreground w-4">{i + 1}</span>
                {artist.image ? (
                  <img src={artist.image} alt={artist.name} className="w-8 h-8 rounded-full object-cover" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                    <Mic2 className="w-3.5 h-3.5 text-muted-foreground" />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{artist.name}</p>
                  {artist.genres?.length > 0 && (
                    <p className="text-xs text-muted-foreground truncate capitalize">{artist.genres[0]}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}