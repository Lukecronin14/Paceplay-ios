import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Music, ExternalLink, Clock, Mic2, ListMusic } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';
import SpotifyInsights from '@/components/integrations/SpotifyInsights';
import { clearSpotifyIntegration } from '@/lib/integrationStorage';

function TrackRow({ image, name, artist, playedAt }) {
  return (
    <div className="flex items-center gap-3">
      {image ? (
        <img src={image} alt={name} className="w-9 h-9 rounded object-cover flex-shrink-0" />
      ) : (
        <div className="w-9 h-9 rounded bg-green-100 dark:bg-green-900 flex items-center justify-center flex-shrink-0">
          <Music className="w-4 h-4 text-green-600 dark:text-green-400" />
        </div>
      )}
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium truncate">{name}</p>
        <p className="text-xs text-muted-foreground truncate">{artist}</p>
      </div>
      {playedAt && (
        <p className="text-xs text-muted-foreground flex-shrink-0">
          {new Date(playedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      )}
    </div>
  );
}

function ArtistRow({ image, name, genres }) {
  return (
    <div className="flex items-center gap-3">
      {image ? (
        <img src={image} alt={name} className="w-9 h-9 rounded-full object-cover flex-shrink-0" />
      ) : (
        <div className="w-9 h-9 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center flex-shrink-0">
          <Mic2 className="w-4 h-4 text-green-600 dark:text-green-400" />
        </div>
      )}
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium truncate">{name}</p>
        {genres?.length > 0 && (
          <p className="text-xs text-muted-foreground truncate">{genres.join(', ')}</p>
        )}
      </div>
    </div>
  );
}

export default function SpotifyConnect({ onConnectionChange }) {
  const [isLoading, setIsLoading] = useState(false);
  // A cached profile alone is not a live connection — the live run checks the
  // access token, so only show "Connected" when a real token exists too.
  const [profile, setProfile] = useState(() => {
    if (!localStorage.getItem('spotify_access_token')) return null;
    try {
      const cached = localStorage.getItem('spotify_profile_cache');
      return cached ? JSON.parse(cached) : null;
    } catch { return null; }
  });
  const [error, setError] = useState(null);

  const fetchProfile = async () => {
    const token = localStorage.getItem('spotify_access_token');
    if (!token) return;
    try {
      const res = await base44.functions.invoke('spotifyIntegration', {
        action: 'getProfile',
        accessToken: token
      });
      if (res.data && res.data.name) {
        setProfile(res.data);
        localStorage.setItem('spotify_profile_cache', JSON.stringify(res.data));
        onConnectionChange?.(true);
      }
    } catch {
      localStorage.removeItem('spotify_access_token');
      localStorage.removeItem('spotify_profile_cache');
      setProfile(null);
      onConnectionChange?.(false);
    }
  };

  useEffect(() => {
    const bootstrap = async () => {
      if (!localStorage.getItem('spotify_access_token')) {
        // Token expired or cleared, but the connection itself is still stored
        // server-side — silently mint a fresh access token so Home and the
        // live run agree without forcing a manual reconnect.
        try {
          const res = await base44.functions.invoke('spotifyIntegration', { action: 'refreshAccessToken' });
          const data = res.data || {};
          if (data.accessToken) {
            localStorage.setItem('spotify_access_token', data.accessToken);
            if (data.expiresIn) {
              localStorage.setItem('spotify_expires_at', String(Date.now() + data.expiresIn * 1000));
            }
          }
        } catch {}
      }
      if (!localStorage.getItem('spotify_access_token')) {
        // Genuinely disconnected (no server-side token either): drop the stale
        // cached profile so Home stops claiming a live connection.
        localStorage.removeItem('spotify_profile_cache');
        setProfile(null);
        onConnectionChange?.(false);
        return;
      }
      fetchProfile();
    };
    bootstrap();
    // Complete the connection when the callback page saves the token, even on
    // mobile browsers where the popup cannot close itself.
    const onStorage = (e) => {
      if (e.key === 'spotify_access_token' && e.newValue) fetchProfile();
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const handleConnect = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await base44.functions.invoke('spotifyIntegration', {
        action: 'getAuthUrl',
        redirectUri: `${window.location.origin}/spotify-callback`
      });
      const { authUrl } = response.data;
      const popup = window.open(authUrl, 'spotify_login', 'width=500,height=600');
      if (!popup) {
        window.location.href = authUrl;
        return;
      }
      const timer = setInterval(async () => {
        if (popup.closed) {
          clearInterval(timer);
          // The callback page saves the token before closing, so it is already
          // in localStorage when we get here. Allow slow devices a moment.
          await new Promise(resolve => setTimeout(resolve, 1000));
          setIsLoading(false);
          if (localStorage.getItem('spotify_access_token')) {
            await fetchProfile();
          } else {
            setError('Spotify connection did not complete. Finish the Spotify login and tap "Agree", then try again.');
            onConnectionChange?.(false);
          }
        }
      }, 500);
    } catch (err) {
      setIsLoading(false);
      if (err?.response?.status === 401) {
        setError('Please log in to PacePlay first, then connect Spotify.');
      } else {
        setError('Could not start the Spotify connection. Please try again.');
      }
    }
  };

  const handleDisconnect = async () => {
    localStorage.removeItem('spotify_access_token');
    localStorage.removeItem('spotify_profile_cache');
    setProfile(null);
    onConnectionChange?.(false);
    try { await clearSpotifyIntegration(); } catch {}
  };

  if (profile) {
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {profile.image ? (
                  <img src={profile.image} alt={profile.name} className="w-12 h-12 rounded-full object-cover ring-2 ring-green-400 dark:ring-green-500" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-green-200 dark:bg-green-800 flex items-center justify-center">
                    <Music className="w-6 h-6 text-green-700 dark:text-green-400" />
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-heading font-bold text-green-900 dark:text-green-200">{profile.name}</p>
                    <span className="px-2 py-0.5 text-xs font-medium bg-green-200 dark:bg-green-800 text-green-800 dark:text-green-300 rounded-full capitalize">{profile.plan}</span>
                  </div>
                  <p className="text-sm text-green-700 dark:text-green-400">{profile.email}</p>
                  <p className="text-xs text-green-700 dark:text-green-400">{profile.followers} followers · {profile.country}</p>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs font-medium text-green-700 dark:text-green-400">Connected</span>
                </div>
                {profile.spotifyUrl && (
                  <a href={profile.spotifyUrl} target="_blank" rel="noopener noreferrer"
                    className="text-xs text-green-700 dark:text-green-400 hover:text-green-800 flex items-center gap-1">
                    Open Spotify <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {/* Top Tracks */}
              {profile.topTracks?.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 mb-2">
                    <ListMusic className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
                    <p className="text-xs font-semibold text-green-800 dark:text-green-300 uppercase tracking-wide">Top Tracks</p>
                  </div>
                  <div className="space-y-2">
                    {profile.topTracks.map((track, i) => (
                      <TrackRow key={i} {...track} />
                    ))}
                  </div>
                </div>
              )}

              {/* Top Artists */}
              {profile.topArtists?.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 mb-2">
                    <Mic2 className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
                    <p className="text-xs font-semibold text-green-800 dark:text-green-300 uppercase tracking-wide">Top Artists</p>
                  </div>
                  <div className="space-y-2">
                    {profile.topArtists.map((artist, i) => (
                      <ArtistRow key={i} {...artist} />
                    ))}
                  </div>
                </div>
              )}

              {/* Recently Played */}
              {profile.recentTracks?.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 mb-2">
                    <Clock className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
                    <p className="text-xs font-semibold text-green-800 dark:text-green-300 uppercase tracking-wide">Recently Played</p>
                  </div>
                  <div className="space-y-2">
                    {profile.recentTracks.map((track, i) => (
                      <TrackRow key={i} {...track} />
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Button variant="outline" onClick={handleDisconnect} className="w-full border-green-300 text-green-700 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-900">
              Disconnect Spotify
            </Button>
          </CardContent>
        </Card>
        <SpotifyInsights profile={profile} />
      </motion.div>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-green-200 dark:border-green-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Music className="w-5 h-5 text-green-600 dark:text-green-400" />
          Connect Spotify
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Connect your Spotify account to export BPM-matched running playlists directly to your library.
        </p>
        {error && (
          <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-3 text-sm text-red-700 dark:text-red-400">
            <p>{error}</p>
            <p className="text-xs text-red-500 dark:text-red-400 font-mono mt-1 break-all">Redirect URI: {window.location.origin}/spotify-callback</p>
          </div>
        )}
        <Button onClick={handleConnect} disabled={isLoading} className="w-full bg-green-600 hover:bg-green-700">
          {isLoading ? 'Connecting...' : 'Connect with Spotify'}
        </Button>
      </CardContent>
    </Card>
  );
}