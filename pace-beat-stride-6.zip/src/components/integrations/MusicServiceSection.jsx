import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import SpotifyConnect from '@/components/integrations/SpotifyConnect';
import SpotifyPlaylistSelector from '@/components/integrations/SpotifyPlaylistSelector';
import AppleMusicConnect from '@/components/integrations/AppleMusicConnect';
import AppleMusicPlaylistSelector from '@/components/integrations/AppleMusicPlaylistSelector';
import {
  getPreferredMusicService,
  isSpotifyConnected,
  isAppleMusicConnected,
  setPreferredMusicService,
} from '@/lib/musicService';
import ResponsiveSelect from '@/components/common/ResponsiveSelect';

export default function MusicServiceSection({ onConnectionsChange }) {
  const [spotifyConnected, setSpotifyConnected] = useState(isSpotifyConnected());
  const [appleConnected, setAppleConnected] = useState(isAppleMusicConnected());
  const [preferred, setPreferred] = useState(getPreferredMusicService());

  const applyConnections = (spotify, apple) => {
    setSpotifyConnected(spotify);
    setAppleConnected(apple);
    onConnectionsChange?.(spotify || apple);

    // Keep a valid preferred service: fall back to the other connected
    // service on disconnect, or auto-pick when only one is connected.
    let pref = getPreferredMusicService();
    if (pref === 'spotify' && !spotify) pref = apple ? 'apple_music' : null;
    else if (pref === 'apple_music' && !apple) pref = spotify ? 'spotify' : null;
    else if (!pref && spotify && !apple) pref = 'spotify';
    else if (!pref && apple && !spotify) pref = 'apple_music';
    if (pref) setPreferredMusicService(pref);
    setPreferred(pref);
  };

  const handleSpotifyConnection = (connected) => applyConnections(connected, appleConnected);
  const handleAppleConnection = (connected) => applyConnections(spotifyConnected, connected);

  // Cross-tab connection changes (e.g. OAuth callback completing in a popup)
  useEffect(() => {
    const check = () => applyConnections(isSpotifyConnected(), isAppleMusicConnected());
    window.addEventListener('storage', check);
    return () => window.removeEventListener('storage', check);
  }, []);

  const chooseService = (id) => {
    setPreferredMusicService(id);
    setPreferred(id);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-1.5">
        <label className="text-sm font-medium">
          Music service
        </label>
        <ResponsiveSelect
          options={[{ value: 'spotify', label: 'Spotify' }, { value: 'apple_music', label: 'Apple Music' }]}
          value={preferred || undefined}
          onChange={chooseService}
          placeholder="Choose your music service"
          className="h-11"
        />
      </div>

      {!preferred && (
        <p className="text-xs text-muted-foreground">
          {spotifyConnected && appleConnected
            ? 'Both services connected — choose which one powers your playlists.'
            : 'Pick a service above to connect it and choose your running playlists.'}
        </p>
      )}

      {preferred === 'spotify' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <SpotifyConnect onConnectionChange={handleSpotifyConnection} />
          <SpotifyPlaylistSelector />
        </motion.div>
      )}

      {preferred === 'apple_music' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <AppleMusicConnect onConnectionChange={handleAppleConnection} />
          <AppleMusicPlaylistSelector />
        </motion.div>
      )}
    </div>
  );
}