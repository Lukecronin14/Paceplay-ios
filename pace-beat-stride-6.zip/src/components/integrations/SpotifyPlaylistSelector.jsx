import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Music, Loader2, Check, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

export default function SpotifyPlaylistSelector() {
  const token = localStorage.getItem('spotify_access_token');
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selected, setSelected] = useState(new Set());
  const [saving, setSaving] = useState(false);

  const { data: prefs } = useQuery({
    queryKey: ['musicPrefs'],
    queryFn: async () => {
      const list = await base44.entities.MusicPreference.list();
      return list[0] || null;
    },
  });

  const { data: playlists, isLoading, isError, error } = useQuery({
    queryKey: ['spotifyPlaylists'],
    queryFn: async () => {
      const res = await base44.functions.invoke('spotifyIntegration', {
        action: 'getPlaylists',
        accessToken: token,
      });
      return res.data?.playlists || [];
    },
    enabled: !!token,
  });

  useEffect(() => {
    if (prefs?.selected_running_playlists) {
      setSelected(new Set(prefs.selected_running_playlists.map(p => p.id)));
    }
  }, [prefs]);

  const togglePlaylist = async (playlistId) => {
    const previousSelected = new Set(selected);
    const newSelected = new Set(selected);
    if (newSelected.has(playlistId)) {
      newSelected.delete(playlistId);
    } else {
      newSelected.add(playlistId);
    }
    setSelected(newSelected);

    setSaving(true);
    try {
      const selectedPlaylists = (playlists || [])
        .filter(p => newSelected.has(p.id))
        .map(p => ({ id: p.id, name: p.name, image: p.image, track_count: p.track_count }));

      if (prefs?.id) {
        await base44.entities.MusicPreference.update(prefs.id, {
          selected_running_playlists: selectedPlaylists,
        });
      } else {
        await base44.entities.MusicPreference.create({
          selected_running_playlists: selectedPlaylists,
        });
      }
      queryClient.invalidateQueries({ queryKey: ['musicPrefs'] });
    } catch (err) {
      console.error('Failed to save playlist selection:', err);
      setSelected(previousSelected);
      toast({
        title: "Couldn't save your selection",
        description: 'Your playlist selection change was not saved. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  if (!token) return null;

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 font-heading text-base">
            <Music className="w-4 h-4 text-green-600 dark:text-green-400" />
            Your Running Playlists
          </CardTitle>
          <p className="text-xs text-green-700 dark:text-green-400">
            Select playlists you use for running. We'll prioritise tracks from these when generating new playlists.
          </p>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="w-5 h-5 text-green-600 dark:text-green-400 animate-spin" />
            </div>
          ) : isError ? (
            <div className="flex items-start gap-2 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-3">
              <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-red-700 dark:text-red-400 font-medium">Failed to load playlists</p>
                <p className="text-xs text-red-500 dark:text-red-400 mt-0.5">
                  Your Spotify token may have expired. Try disconnecting and reconnecting Spotify above to grant the updated permissions.
                </p>
              </div>
            </div>
          ) : playlists?.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">No playlists found in your Spotify library.</p>
          ) : (
            <div className="space-y-1 max-h-72 overflow-y-auto">
              {playlists?.map(playlist => (
                <label
                  key={playlist.id}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-green-100/50 dark:hover:bg-green-900/50 cursor-pointer transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => togglePlaylist(playlist.id)}
                    className={`w-11 h-11 rounded-md border-2 flex items-center justify-center shrink-0 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
                      selected.has(playlist.id)
                        ? 'bg-green-600 border-green-600 text-white'
                        : 'border-green-300 bg-white dark:border-green-700 dark:bg-card'
                    }`}
                  >
                    {selected.has(playlist.id) && <Check className="w-3.5 h-3.5" />}
                  </button>
                  {playlist.image ? (
                    <img src={playlist.image} alt="" className="w-9 h-9 rounded object-cover shrink-0" />
                  ) : (
                    <div className="w-9 h-9 rounded bg-green-200 dark:bg-green-800 flex items-center justify-center shrink-0">
                      <Music className="w-4 h-4 text-green-600 dark:text-green-400" />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{playlist.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {playlist.track_count} tracks{playlist.owner ? ` · ${playlist.owner}` : ''}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          )}
          <div className="mt-2 h-4">
            {saving ? (
              <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" /> Saving...
              </p>
            ) : selected.size > 0 ? (
              <p className="text-xs text-green-600 dark:text-green-400">
                {selected.size} playlist{selected.size !== 1 ? 's' : ''} selected
              </p>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}