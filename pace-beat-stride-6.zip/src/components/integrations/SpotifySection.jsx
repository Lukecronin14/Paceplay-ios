import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Music2, CheckCircle, Mic2, ListMusic, TrendingUp, ExternalLink, Loader2 } from 'lucide-react';

export default function SpotifySection() {
  const [profile, setProfile] = useState(() => {
    try {
      const cached = localStorage.getItem('spotify_profile_cache');
      return cached ? JSON.parse(cached) : null;
    } catch { return null; }
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleConnect = async () => {
    setIsLoading(true);
    setError(null);
    const response = await base44.functions.invoke('spotifyIntegration', {
      action: 'getAuthUrl',
      redirectUri: `${window.location.origin}/spotify-callback`
    });
    const { authUrl } = response.data;
    const popup = window.open(authUrl, 'spotify_login', 'width=500,height=600');
    if (!popup) {
      setError('Could not open Spotify login. Check if popups are blocked.');
      setIsLoading(false);
      return;
    }
    const timer = setInterval(async () => {
      if (popup.closed) {
        clearInterval(timer);
        await new Promise(resolve => setTimeout(resolve, 1500));
        try {
          const token = localStorage.getItem('spotify_access_token');
          if (token) {
            const res = await base44.functions.invoke('spotifyIntegration', {
              action: 'getProfile',
              accessToken: token
            });
            if (res.data?.name) {
              setProfile(res.data);
              localStorage.setItem('spotify_profile_cache', JSON.stringify(res.data));
            }
          }
        } catch {}
        setIsLoading(false);
      }
    }, 500);
  };

  if (profile) {
    const genres = [...new Set(profile.topArtists?.flatMap(a => a.genres || []) || [])].slice(0, 6);

    return (
      <Card className="border-[#1DB954]/30 bg-gradient-to-br from-card to-[#1DB954]/5">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="font-heading text-lg flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#1DB954] flex items-center justify-center">
                <Music2 className="w-4 h-4 text-white" />
              </div>
              Spotify Integration
            </CardTitle>
            <Badge variant="outline" className="text-xs border-[#1DB954]/50 text-[#14804A] dark:text-[#1DB954]">
              <CheckCircle className="w-3 h-3 mr-1" />
              Connected
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Your listening data is being used to personalise this playlist.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-3 gap-3">
            {/* Top Tracks */}
            {profile.topTracks?.length > 0 && (
              <div className="rounded-xl bg-muted/40 p-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <ListMusic className="w-3.5 h-3.5 text-[#14804A] dark:text-[#1DB954]" />
                  <p className="text-xs font-semibold uppercase tracking-wide text-[#14804A] dark:text-[#1DB954]">Top Tracks</p>
                </div>
                <div className="space-y-1.5">
                  {profile.topTracks.slice(0, 4).map((t, i) => (
                    <div key={i} className="flex items-center gap-2">
                      {t.image ? (
                        <img src={t.image} alt={t.name} className="w-7 h-7 rounded object-cover shrink-0" />
                      ) : (
                        <div className="w-7 h-7 rounded bg-[#1DB954]/20 shrink-0" />
                      )}
                      <div className="min-w-0">
                        <p className="text-xs font-medium truncate">{t.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{t.artist}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Top Artists */}
            {profile.topArtists?.length > 0 && (
              <div className="rounded-xl bg-muted/40 p-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <Mic2 className="w-3.5 h-3.5 text-[#14804A] dark:text-[#1DB954]" />
                  <p className="text-xs font-semibold uppercase tracking-wide text-[#14804A] dark:text-[#1DB954]">Top Artists</p>
                </div>
                <div className="space-y-1.5">
                  {profile.topArtists.slice(0, 4).map((a, i) => (
                    <div key={i} className="flex items-center gap-2">
                      {a.image ? (
                        <img src={a.image} alt={a.name} className="w-7 h-7 rounded-full object-cover shrink-0" />
                      ) : (
                        <div className="w-7 h-7 rounded-full bg-[#1DB954]/20 shrink-0" />
                      )}
                      <p className="text-xs font-medium truncate">{a.name}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Genres */}
            {genres.length > 0 && (
              <div className="rounded-xl bg-muted/40 p-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <TrendingUp className="w-3.5 h-3.5 text-[#14804A] dark:text-[#1DB954]" />
                  <p className="text-xs font-semibold uppercase tracking-wide text-[#14804A] dark:text-[#1DB954]">Your Genres</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {genres.map((g, i) => (
                    <span key={i} className="text-xs bg-[#1DB954]/10 text-[#14804A] dark:text-[#1DB954] px-2 py-0.5 rounded-full capitalize">
                      {g}
                    </span>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-3 leading-relaxed">
                  These genres and artists are being used to personalise your BPM-matched playlist.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Not connected
  return (
    <Card className="border-[#1DB954]/20 bg-gradient-to-br from-card to-[#1DB954]/5">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="font-heading text-lg flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#1DB954] flex items-center justify-center">
              <Music2 className="w-4 h-4 text-white" />
            </div>
            Spotify Integration
          </CardTitle>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          Connect Spotify to personalise your playlist with your actual listening data.
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {[
          { icon: ListMusic, title: 'Listening History', desc: 'Your top tracks shape the playlist choices.' },
          { icon: TrendingUp, title: 'Real BPM Matching', desc: 'Your taste informs the exact BPM targets per km.' },
          { icon: Mic2, title: 'Artist Seeds', desc: 'Songs chosen from artists you already love.' },
        ].map(f => (
          <div key={f.title} className="flex gap-3 p-3 rounded-xl bg-muted/40">
            <div className="w-8 h-8 rounded-lg bg-[#1DB954]/10 flex items-center justify-center shrink-0">
              <f.icon className="w-4 h-4 text-[#14804A] dark:text-[#1DB954]" />
            </div>
            <div>
              <p className="text-sm font-medium">{f.title}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{f.desc}</p>
            </div>
          </div>
        ))}
        {error && <p className="text-xs text-destructive">{error}</p>}
        <Button
          onClick={handleConnect}
          disabled={isLoading}
          className="w-full bg-[#1DB954] hover:bg-[#1DB954]/90 text-white rounded-xl font-semibold"
        >
          {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Music2 className="w-4 h-4 mr-2" />}
          {isLoading ? 'Connecting...' : 'Connect Spotify'}
        </Button>
      </CardContent>
    </Card>
  );
}