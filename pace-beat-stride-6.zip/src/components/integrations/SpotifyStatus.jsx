import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export default function SpotifyStatus() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkSpotifyConnection = async () => {
      const token = localStorage.getItem('spotify_access_token');
      if (token) {
        try {
          const res = await base44.functions.invoke('spotifyIntegration', {
            action: 'getProfile',
            accessToken: token
          });
          if (res.data) setProfile(res.data);
        } catch (err) {
          console.error('Failed to fetch Spotify profile:', err);
        }
      }
      setLoading(false);
    };

    checkSpotifyConnection();
  }, []);

  if (loading || !profile) return null;

  return (
    <div className="flex items-center gap-2 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-3 w-fit">
      {profile.image && (
        <img src={profile.image} alt={profile.name} className="w-8 h-8 rounded-full object-cover" />
      )}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-green-900 dark:text-green-200">{profile.name}</p>
        <p className="text-xs text-green-600 dark:text-green-400">Spotify connected</p>
      </div>
    </div>
  );
}