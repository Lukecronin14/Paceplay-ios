import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mountain, Map, GitBranch, ExternalLink, CheckCircle, Globe } from 'lucide-react';

const sources = [
  {
    name: 'OpenStreetMap',
    url: 'https://www.openstreetmap.org',
    status: 'available',
    statusLabel: 'Free & Open',
    color: 'text-primary',
    bgColor: 'bg-primary/10',
    borderColor: 'border-primary/20',
    description: 'Parkrun routes are community-mapped in OSM. Accessible via the Overpass API — no authentication needed.',
    capability: 'Route geometry, waypoints, surface type',
    endpoint: 'https://overpass-api.de/api/interpreter',
  },
  {
    name: 'Open-Elevation',
    url: 'https://open-elevation.com',
    status: 'available',
    statusLabel: 'Free & Open',
    color: 'text-primary',
    bgColor: 'bg-primary/10',
    borderColor: 'border-primary/20',
    description: 'Free REST API returning elevation in metres for any lat/lng. Based on SRTM data — 30m resolution globally.',
    capability: 'Elevation profile, gradient per km',
    endpoint: 'https://api.open-elevation.com/api/v1/lookup',
  },
  {
    name: 'Strava Segments',
    url: 'https://developers.strava.com',
    status: 'oauth',
    statusLabel: 'OAuth Required',
    color: 'text-chart-3',
    bgColor: 'bg-chart-3/10',
    borderColor: 'border-chart-3/20',
    description: 'Most parkruns have a corresponding Strava segment with crowdsourced elevation, average times, and effort data from thousands of runners.',
    capability: 'Elevation, average pace, segment leaderboard',
    endpoint: 'GET /segments/{id}',
  },
];

export default function RouteDataSection() {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="font-heading text-lg flex items-center gap-2">
          <Mountain className="w-5 h-5 text-primary" />
          Route & Terrain Data Sources
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          How we understand the terrain and cadence requirements for each parkrun route.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {sources.map((src) => (
          <div key={src.name} className={`rounded-xl border ${src.borderColor} p-4`}>
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-2">
                <div className={`w-7 h-7 rounded-lg ${src.bgColor} flex items-center justify-center shrink-0`}>
                  {src.name === 'OpenStreetMap' && <Map className={`w-3.5 h-3.5 ${src.color}`} />}
                  {src.name === 'Open-Elevation' && <Mountain className={`w-3.5 h-3.5 ${src.color}`} />}
                  {src.name === 'Strava Segments' && <GitBranch className={`w-3.5 h-3.5 ${src.color}`} />}
                </div>
                <p className="font-medium text-sm">{src.name}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Badge
                  variant="outline"
                  className={`text-xs ${src.color} border-current`}
                >
                  {src.status === 'available' ? (
                    <CheckCircle className="w-3 h-3 mr-1" />
                  ) : (
                    <Globe className="w-3 h-3 mr-1" />
                  )}
                  {src.statusLabel}
                </Badge>
                <a href={src.url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-3.5 h-3.5 text-muted-foreground hover:text-foreground transition-colors" />
                </a>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-2">{src.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">Provides: </span>
                {src.capability}
              </span>
            </div>
            <code className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded mt-2 block truncate">
              {src.endpoint}
            </code>
          </div>
        ))}

        <div className="bg-muted/50 rounded-xl p-4">
          <p className="text-sm text-muted-foreground leading-relaxed">
            <span className="font-medium text-foreground">How cadence is calculated: </span>
            For each kilometre, elevation gain/loss from Open-Elevation determines the gradient. 
            Gradient adjusts the target pace (e.g. +8 sec/km per 1% uphill gradient), which sets the 
            cadence (steps/min). BPM-matched songs are then selected within ±5 BPM of the cadence target.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}