import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { Activity, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { clearStravaIntegration } from '@/lib/integrationStorage';

export default function StravaConnect() {
  const [isLoading, setIsLoading] = useState(false);
  const [connected, setConnected] = useState(() => !!localStorage.getItem('strava_access_token'));
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState(null);

  // Verify the connection with a real server round-trip instead of trusting a
  // possibly-stale localStorage token. This also refreshes the access token and
  // pulls the actual athlete profile — the fetch the old "Synced" card faked.
  useEffect(() => {
    if (!connected) return undefined;
    let cancelled = false;
    (async () => {
      try {
        const res = await base44.functions.invoke('stravaIntegration', {
          action: 'getAthlete',
          accessToken: localStorage.getItem('strava_access_token'),
          expiresAt: localStorage.getItem('strava_expires_at'),
        });
        if (cancelled) return;
        if (res.data?.accessToken) {
          localStorage.setItem('strava_access_token', res.data.accessToken);
          if (res.data.expiresAt) localStorage.setItem('strava_expires_at', String(res.data.expiresAt));
        }
        setProfile(res.data?.profile || null);
      } catch (err) {
        if (cancelled) return;
        // The server has no valid Strava session — the local token is stale.
        if (err?.response?.status === 401) {
          localStorage.removeItem('strava_access_token');
          localStorage.removeItem('strava_expires_at');
          setConnected(false);
          setProfile(null);
        }
      }
    })();
    return () => { cancelled = true; };
  }, [connected]);

  const handleConnect = async () => {
    setIsLoading(true);
    setError(null);
    const response = await base44.functions.invoke('stravaIntegration', {
      action: 'getAuthUrl',
      redirectUri: `${window.location.origin}/strava-callback`
    });
    const { authUrl } = response.data;
    const popup = window.open(authUrl, 'strava_login', 'width=500,height=600');
    if (!popup) {
      window.location.href = authUrl;
      return;
    }
    const timer = setInterval(() => {
      if (popup.closed) {
        clearInterval(timer);
        if (localStorage.getItem('strava_access_token')) setConnected(true);
        setIsLoading(false);
      }
    }, 500);
  };

  const handleDisconnect = async () => {
    localStorage.removeItem('strava_access_token');
    localStorage.removeItem('strava_expires_at');
    setConnected(false);
    setProfile(null);
    try { await clearStravaIntegration(); } catch {}
  };

  if (connected) {
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="border-orange-200 bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950 dark:to-amber-950">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {profile?.avatar?.startsWith('http') ? (
                  <img src={profile.avatar} alt="" className="w-12 h-12 rounded-full object-cover shrink-0" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-orange-200 dark:bg-orange-800 flex items-center justify-center shrink-0">
                    <Activity className="w-6 h-6 text-orange-700 dark:text-orange-400" />
                  </div>
                )}
                <div>
                  <p className="font-heading font-bold text-orange-900 dark:text-orange-200">
                    {profile?.name ? profile.name : 'Strava Connected'}
                  </p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                    <span className="text-xs font-medium text-orange-700 dark:text-orange-400">Synced</span>
                  </div>
                </div>
              </div>
              <Link to="/strava-runs">
                <Button size="sm" className="bg-orange-600 hover:bg-orange-700 rounded-xl">
                  View My Runs <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            <Button variant="outline" onClick={handleDisconnect} className="w-full border-orange-300 dark:border-orange-700 text-orange-700 dark:text-orange-400 hover:bg-orange-100 dark:hover:bg-orange-900">
              Disconnect Strava
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950 dark:to-amber-950 border-orange-200 dark:border-orange-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-orange-600 dark:text-orange-400" />
          Connect Strava
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Connect Strava to see your completed runs and generate playlists for routes you want to run again.
        </p>
        {error && (
          <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-3 text-sm text-red-700 dark:text-red-400">
            <p>{error}</p>
          </div>
        )}
        <Button onClick={handleConnect} disabled={isLoading} className="w-full bg-orange-600 hover:bg-orange-700">
          {isLoading ? 'Connecting...' : 'Connect with Strava'}
        </Button>
      </CardContent>
    </Card>
  );
}