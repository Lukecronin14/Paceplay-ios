import React, { useState, useEffect } from 'react';
import { Music, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  connectAppleMusic,
  disconnectAppleMusic,
  fetchAndCacheAppleMusicProfile,
  APPLE_MUSIC_USER_TOKEN_KEY,
  APPLE_MUSIC_PROFILE_CACHE_KEY,
} from '@/lib/appleMusicData';

function TrackRow({ title, artist }) {
  return (
    <div className="flex items-start gap-2">
      <Music className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400 mt-0.5 shrink-0" />
      <p className="text-sm">
        {title} <span className="text-muted-foreground">— {artist}</span>
      </p>
    </div>
  );
}

export default function AppleMusicConnect({ onConnectionChange }) {
  const [connected, setConnected] = useState(() => !!localStorage.getItem(APPLE_MUSIC_USER_TOKEN_KEY));
  const [profile, setProfile] = useState(null);
  const [connecting, setConnecting] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [connectError, setConnectError] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    try {
      setProfile(JSON.parse(localStorage.getItem(APPLE_MUSIC_PROFILE_CACHE_KEY) || 'null'));
    } catch {}
    const check = () => setConnected(!!localStorage.getItem(APPLE_MUSIC_USER_TOKEN_KEY));
    window.addEventListener('storage', check);
    return () => window.removeEventListener('storage', check);
  }, []);

  const handleConnect = async () => {
    setConnecting(true);
    setConnectError(null);
    try {
      const p = await connectAppleMusic();
      setProfile(p);
      setConnected(true);
      onConnectionChange?.(true);
      toast({ title: 'Apple Music connected', description: 'Your listening history now feeds your playlists.' });
    } catch (err) {
      setConnectError(err?.message || 'Could not connect Apple Music.');
    } finally {
      setConnecting(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      setProfile(await fetchAndCacheAppleMusicProfile());
      toast({ title: 'Apple Music data refreshed' });
    } catch (err) {
      toast({ title: 'Could not refresh Apple Music data', description: err?.message, variant: 'destructive' });
    } finally {
      setRefreshing(false);
    }
  };

  const handleDisconnect = async () => {
    await disconnectAppleMusic();
    setConnected(false);
    setProfile(null);
    onConnectionChange?.(false);
  };

  if (connected) {
    const recentTracks = profile?.heavyRotation || [];
    const topArtists = profile?.topArtists || [];
    return (
      <Card className="bg-gradient-to-br from-rose-50 to-red-50 dark:from-rose-950 dark:to-red-950 border-rose-200 dark:border-rose-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Music className="w-5 h-5 text-rose-600 dark:text-rose-400" />
            Apple Music
            <CheckCircle2 className="w-4 h-4 text-rose-600 dark:text-rose-400 ml-auto" />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {topArtists.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-rose-800 dark:text-rose-300 uppercase tracking-wide mb-2">Favourite Artists</p>
              <div className="flex flex-wrap gap-1.5">
                {topArtists.slice(0, 6).map((artist) => (
                  <span
                    key={artist}
                    className="text-xs bg-rose-100 text-rose-800 dark:bg-rose-900 dark:text-rose-300 rounded-full px-2.5 py-1"
                  >
                    {artist}
                  </span>
                ))}
              </div>
            </div>
          )}
          {recentTracks.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-rose-800 dark:text-rose-300 uppercase tracking-wide mb-2">Recently Played</p>
              <div className="space-y-2">
                {recentTracks.slice(0, 5).map((track, i) => (
                  <TrackRow key={i} {...track} />
                ))}
              </div>
            </div>
          )}
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleRefresh}
              disabled={refreshing}
              className="flex-1 border-rose-300 text-rose-700 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900"
            >
              {refreshing ? 'Refreshing...' : 'Refresh'}
            </Button>
            <Button
              variant="outline"
              onClick={handleDisconnect}
              className="flex-1 border-rose-300 text-rose-700 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900"
            >
              Disconnect
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-rose-50 to-red-50 dark:from-rose-950 dark:to-red-950 border-rose-200 dark:border-rose-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Music className="w-5 h-5 text-rose-600 dark:text-rose-400" />
          Connect Apple Music
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Connect your Apple Music account so your listening history and favourite artists feed your personalised running playlists.
        </p>
        {connectError && (
          <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-3 text-sm text-red-700 dark:text-red-400 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <p>{connectError}</p>
          </div>
        )}
        <Button onClick={handleConnect} disabled={connecting} className="w-full bg-rose-600 hover:bg-rose-700">
          {connecting ? 'Connecting...' : 'Connect with Apple Music'}
        </Button>
      </CardContent>
    </Card>
  );
}