import React from 'react';
import { Music, ExternalLink, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function SpotifySync({ playlistTracks }) {
  return (
    <Card className="border-accent/20 bg-gradient-to-br from-card to-accent/5">
      <CardHeader>
        <CardTitle className="font-heading text-lg flex items-center gap-2">
          <Music className="w-5 h-5 text-accent" />
          Spotify Integration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Export this playlist to Spotify for seamless playback during your run.
        </p>

        <div className="bg-muted/40 rounded-lg p-3 text-xs text-muted-foreground space-y-1 border border-border/50">
          <p><strong>Data sources for terrain & cadence:</strong></p>
          <ul className="list-disc list-inside space-y-0.5 mt-2">
            <li>
              <span className="font-medium">Strava API</span> - Free tier available; provides segment data, elevation profiles, and performance metrics
            </li>
            <li>
              <span className="font-medium">Open-Elevation API</span> - Free, public elevation data for any coordinates
            </li>
            <li>
              <span className="font-medium">Google Maps API</span> - Elevation endpoint (paid, but accurate)
            </li>
            <li>
              <span className="font-medium">Cadence estimation</span> - Calculated from pace, terrain gradient, and distance
            </li>
          </ul>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="rounded-lg text-xs" disabled>
            <Music className="w-3 h-3 mr-1.5" />
            Connect Spotify
          </Button>
          <Button variant="outline" size="sm" className="rounded-lg text-xs" disabled>
            <ExternalLink className="w-3 h-3 mr-1.5" />
            Learn More
          </Button>
        </div>

        <div className="flex items-start gap-2 text-xs text-muted-foreground bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-2.5">
          <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-yellow-600" />
          <span>Coming soon: Connect your Spotify account to sync AI-generated playlists directly to your library.</span>
        </div>
      </CardContent>
    </Card>
  );
}