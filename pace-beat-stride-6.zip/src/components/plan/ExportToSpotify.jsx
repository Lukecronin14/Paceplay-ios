import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Music, ExternalLink, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

export default function ExportToSpotify({ plan }) {
  const [status, setStatus] = useState('idle'); // idle | loading | success | error | no_token
  const [result, setResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  const handleExport = async () => {
    const token = localStorage.getItem('spotify_access_token');
    if (!token) {
      setStatus('no_token');
      return;
    }

    setStatus('loading');
    setErrorMsg('');

    const res = await base44.functions.invoke('spotifyIntegration', {
      action: 'searchAndExportPlaylist',
      accessToken: token,
      parkrunName: plan.parkrun_name,
      targetTimeMin: plan.target_time_min,
      tracklist: (plan.playlist || []).map(t => ({ title: t.title, artist: t.artist }))
    });

    if (res.data?.success) {
      setResult(res.data);
      setStatus('success');
    } else {
      setErrorMsg(res.data?.error || 'Export failed');
      setStatus('error');
    }
  };

  if (status === 'success' && result) {
    return (
      <div className="flex items-center gap-3 p-3 rounded-xl bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800">
        <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-green-800 dark:text-green-300">Exported to Spotify!</p>
          <p className="text-xs text-green-600 dark:text-green-400">{result.tracksAdded} of {result.totalTracks} tracks added</p>
        </div>
        <a href={result.playlistUrl} target="_blank" rel="noopener noreferrer">
          <Button size="sm" className="bg-green-600 hover:bg-green-700 rounded-lg gap-1.5">
            <ExternalLink className="w-3.5 h-3.5" />
            Open
          </Button>
        </a>
      </div>
    );
  }

  if (status === 'no_token') {
    return (
      <div className="flex items-center gap-3 p-3 rounded-xl bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800">
        <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
        <p className="text-sm text-amber-800 dark:text-amber-300">Connect Spotify first on the Home page to export playlists.</p>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="flex items-center gap-3 p-3 rounded-xl bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800">
        <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0" />
        <div className="flex-1">
          <p className="text-sm text-red-800 dark:text-red-300">{errorMsg}</p>
        </div>
        <Button size="sm" variant="outline" onClick={() => setStatus('idle')}>Retry</Button>
      </div>
    );
  }

  return (
    <Button
      onClick={handleExport}
      disabled={status === 'loading' || !plan.playlist?.length}
      className="bg-green-600 hover:bg-green-700 gap-2 rounded-xl"
    >
      {status === 'loading' ? (
        <><Loader2 className="w-4 h-4 animate-spin" /> Exporting to Spotify...</>
      ) : (
        <><Music className="w-4 h-4" /> Export to Spotify</>
      )}
    </Button>
  );
}