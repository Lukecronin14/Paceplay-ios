import React, { Suspense, lazy } from 'react';
import { Loader2 } from 'lucide-react';
import { decodePolyline } from '@/lib/decodePolyline';

const StravaRouteMapInner = lazy(() => import('./StravaRouteMapInner'));

export default function StravaRouteMap({ polyline, startLatlng }) {
  const points = decodePolyline(polyline);

  if (points.length === 0) {
    return (
      <div className="bg-muted rounded-xl flex items-center justify-center text-muted-foreground text-sm" style={{ height: 340 }}>
        No route data available for this run
      </div>
    );
  }

  const center = startLatlng ? [startLatlng[0], startLatlng[1]] : points[Math.floor(points.length / 2)];

  return (
    <Suspense
      fallback={
        <div className="rounded-xl border border-border flex items-center justify-center" style={{ height: 340 }}>
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      }
    >
      <StravaRouteMapInner points={points} center={center} />
    </Suspense>
  );
}