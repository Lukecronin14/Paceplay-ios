import React from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

export default function StravaRouteMapInner({ points, center, color = '#f97316' }) {
  return (
    <div style={{ height: 340 }} className="rounded-xl overflow-hidden border border-border">
      <MapContainer center={center} zoom={14} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors, &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemap.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png"
        />
        <Polyline positions={points} pathOptions={{ color, weight: 5, opacity: 0.85 }} />
        <Marker position={points[0]}>
          <Popup>Start</Popup>
        </Marker>
        <Marker position={points[points.length - 1]}>
          <Popup>Finish</Popup>
        </Marker>
      </MapContainer>
    </div>
  );
}