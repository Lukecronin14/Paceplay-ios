import React, { useState } from 'react';
import { Share2, Copy, Check, Twitter, Facebook, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const APP_URL = 'https://pace-beat-stride.base44.app';

export default function ShareRunButton({ text }) {
  const [showOptions, setShowOptions] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    // Native share sheet on mobile — offers every installed social app
    if (navigator.share) {
      try {
        await navigator.share({ title: 'PacePlay Run', text, url: APP_URL });
        return;
      } catch (err) {
        if (err.name === 'AbortError') return; // user closed the share sheet
      }
    }
    setShowOptions(true);
  };

  const copyText = async () => {
    try {
      await navigator.clipboard.writeText(`${text} ${APP_URL}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard unavailable — leave the share options open
    }
  };

  const openShare = (url) => window.open(url, '_blank', 'noopener');

  return (
    <div className="space-y-3">
      <Button className="w-full rounded-xl font-semibold" onClick={handleShare}>
        <Share2 className="w-4 h-4 mr-1.5" /> Share your run
      </Button>
      {showOptions && (
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="icon"
            aria-label="Share on X"
            onClick={() => openShare(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(APP_URL)}`)}
          >
            <Twitter className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            aria-label="Share on Facebook"
            onClick={() => openShare(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(APP_URL)}&quote=${encodeURIComponent(text)}`)}
          >
            <Facebook className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            aria-label="Share on WhatsApp"
            onClick={() => openShare(`https://wa.me/?text=${encodeURIComponent(`${text} ${APP_URL}`)}`)}
          >
            <MessageCircle className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="icon" aria-label="Copy share text" onClick={copyText}>
            {copied ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
      )}
    </div>
  );
}