import React from 'react';
import { MapContainer, TileLayer, Circle, Popup, Polyline, Marker } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Map } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix leaflet default icon issue with bundlers
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

const GRADIENT_COLORS = {
  flat: '#22c55e',
  slight_uphill: '#f59e0b',
  uphill: '#f97316',
  steep_uphill: '#ef4444',
  slight_downhill: '#60a5fa',
  downhill: '#3b82f6',
  steep_downhill: '#6366f1',
};

const GRADIENT_LABELS = {
  flat: 'Flat',
  slight_uphill: 'Slight uphill',
  uphill: 'Uphill',
  steep_uphill: 'Steep uphill',
  slight_downhill: 'Slight downhill',
  downhill: 'Downhill',
  steep_downhill: 'Steep downhill',
};

function createKmIcon(km, color) {
  return L.divIcon({
    className: '',
    html: `<div style="
      background:${color};
      color:white;
      width:26px;height:26px;
      border-radius:50%;
      display:flex;align-items:center;justify-content:center;
      font-size:11px;font-weight:700;
      border:2px solid white;
      box-shadow:0 2px 6px rgba(0,0,0,0.3);
      font-family:sans-serif;
    ">${km}K</div>`,
    iconSize: [26, 26],
    iconAnchor: [13, 13],
  });
}

function buildRoutePoints(lat, lng, terrainSegments) {
  const points = [];
  const numPoints = 60;
  for (let i = 0; i <= numPoints; i++) {
    const angle = (i / numPoints) * 2 * Math.PI;
    const r = 0.018 + 0.005 * Math.sin(angle * 2);
    points.push([
      lat + r * Math.sin(angle),
      lng + r * Math.cos(angle),
    ]);
  }
  return points;
}

function getKmMarkers(lat, lng, terrainSegments) {
  if (!terrainSegments || terrainSegments.length === 0) return [];
  const markers = [];
  for (let k = 0; k < terrainSegments.length; k++) {
    const seg = terrainSegments[k];
    const fraction = (k + 0.5) / 5;
    const angle = fraction * 2 * Math.PI;
    const r = 0.018 + 0.005 * Math.sin(angle * 2);
    markers.push({
      km: seg.km,
      gradient: seg.gradient,
      gradientLabel: seg.gradientLabel || seg.gradient,
      lat: lat + r * Math.sin(angle),
      lng: lat + r * Math.cos(angle),
    });
  }
  return markers;
}

export default function ParkRunMapInner({ parkrunName, lat, lng, terrainSegments, eventname }) {
  const routePoints = buildRoutePoints(lat, lng, terrainSegments);
  const kmMarkers = getKmMarkers(lat, lng, terrainSegments);

  const segmentPolylines = [];
  if (terrainSegments && terrainSegments.length > 0) {
    const perKm = Math.floor(routePoints.length / 5);
    for (let k = 0; k < 5; k++) {
      const start = k * perKm;
      const end = k === 4 ? routePoints.length : (k + 1) * perKm + 1;
      const gradient = terrainSegments[k]?.gradient || terrainSegments[k]?.gradientLabel || 'flat';
      segmentPolylines.push({
        points: routePoints.slice(start, end),
        color: GRADIENT_COLORS[gradient] || '#22c55e',
        gradient,
        km: k + 1,
      });
    }
  }

  const parkrunUrl = eventname ? `https://www.parkrun.org.uk/${eventname}/` : null;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="font-heading text-lg flex items-center gap-2">
          <Map className="w-5 h-5 text-primary" />
          Route Map
          <span className="text-sm font-normal text-muted-foreground ml-1">— {parkrunName}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0 overflow-hidden rounded-b-xl">
        <div className="h-[280px] sm:h-[340px]">
          <MapContainer
            center={[lat, lng]}
            zoom={14}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom={false}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, &copy; <a href="https://carto.com/attributions">CARTO</a>'
              url="https://{s}.basemap.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png"
            />

            {segmentPolylines.length > 0 ? (
              segmentPolylines.map((seg, i) => (
                <Polyline
                  key={i}
                  positions={seg.points}
                  pathOptions={{ color: seg.color, weight: 5, opacity: 0.85 }}
                >
                  <Popup>
                    <strong>KM {seg.km}</strong><br />
                    {GRADIENT_LABELS[seg.gradient] || seg.gradient}
                  </Popup>
                </Polyline>
              ))
            ) : (
              <Circle
                center={[lat, lng]}
                radius={900}
                pathOptions={{ color: 'hsl(154,60%,42%)', weight: 4, fillOpacity: 0.08 }}
              />
            )}

            <Marker position={[lat, lng]}>
              <Popup>
                <strong>{parkrunName}</strong><br />
                Start / Finish<br />
                {parkrunUrl && (
                  <a href={parkrunUrl} target="_blank" rel="noopener noreferrer">
                    parkrun.org.uk →
                  </a>
                )}
              </Popup>
            </Marker>

            {kmMarkers.map((m, i) => (
              <Marker
                key={i}
                position={[m.lat, m.lng]}
                icon={createKmIcon(m.km, GRADIENT_COLORS[m.gradient] || GRADIENT_COLORS[m.gradientLabel] || '#22c55e')}
              >
                <Popup>
                  <strong>KM {m.km}</strong><br />
                  {GRADIENT_LABELS[m.gradient] || GRADIENT_LABELS[m.gradientLabel] || m.gradient}
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        {terrainSegments && terrainSegments.length > 0 && (
          <div className="px-4 py-3 flex flex-wrap gap-3 border-t border-border bg-muted/30">
            {terrainSegments.map((seg, i) => {
              const grad = seg.gradient || seg.gradientLabel || 'flat';
              return (
                <div key={i} className="flex items-center gap-1.5 text-xs">
                  <span
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ background: GRADIENT_COLORS[grad] || '#22c55e' }}
                  />
                  <span className="font-medium">KM {seg.km}:</span>
                  <span className="text-muted-foreground">{GRADIENT_LABELS[grad] || grad}</span>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}