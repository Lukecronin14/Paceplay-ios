import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Mountain, Timer, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';

const terrainColors = {
  flat: 'bg-primary/10 text-primary',
  undulating: 'bg-chart-4/10 text-chart-4',
  hilly: 'bg-chart-5/10 text-chart-5',
  mixed: 'bg-accent/10 text-accent',
};

const surfaceLabels = {
  trail: 'Trail',
  road: 'Road',
  grass: 'Grass',
  mixed: 'Mixed Surface',
};

export default function ParkRunCard({ parkrun, index = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
    >
      <Link to={`/parkruns/${parkrun.id}`} className="block group">
        <div
          role="button"
          tabIndex={0}
          aria-label={`View ${parkrun.name} details`}
          className="bg-card rounded-2xl border border-border p-5 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1 min-w-0">
              <h3 className="font-heading font-semibold text-base truncate group-hover:text-primary transition-colors">
                {parkrun.name}
              </h3>
              <div className="flex items-center gap-1.5 mt-1 text-muted-foreground">
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <span className="text-sm truncate">{parkrun.location}</span>
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all shrink-0 ml-3">
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="secondary" className={terrainColors[parkrun.terrain_type] || 'bg-secondary text-secondary-foreground'}>
              <Mountain className="w-3 h-3 mr-1" />
              {parkrun.terrain_type}
            </Badge>
            <Badge variant="secondary" className="bg-secondary text-secondary-foreground">
              {surfaceLabels[parkrun.surface] || parkrun.surface}
            </Badge>
            {parkrun.elevation_gain_m > 0 && (
              <Badge variant="outline" className="text-sm">
                ↑{parkrun.elevation_gain_m}m
              </Badge>
            )}
            {parkrun.average_finish_time_min && (
              <Badge variant="outline" className="text-sm">
                <Timer className="w-3 h-3 mr-1" />
                ~{parkrun.average_finish_time_min} min avg
              </Badge>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}