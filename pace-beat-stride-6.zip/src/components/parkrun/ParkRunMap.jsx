import React, { Suspense, lazy } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

const ParkRunMapInner = lazy(() => import('./ParkRunMapInner'));

export default function ParkRunMap({ parkrunName, lat, lng, terrainSegments, eventname }) {
  if (!lat || !lng) {
    return (
      <Card>
        <CardContent className="py-10 text-center text-muted-foreground text-sm">
          Map unavailable — location data not found.
        </CardContent>
      </Card>
    );
  }

  return (
    <Suspense
      fallback={
        <Card>
          <CardContent className="h-[280px] sm:h-[340px] flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </CardContent>
        </Card>
      }
    >
      <ParkRunMapInner
        parkrunName={parkrunName}
        lat={lat}
        lng={lng}
        terrainSegments={terrainSegments}
        eventname={eventname}
      />
    </Suspense>
  );
}