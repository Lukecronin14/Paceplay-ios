import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const gradientToElevation = {
  flat: 0,
  slight_uphill: 5,
  uphill: 15,
  steep_uphill: 30,
  slight_downhill: -5,
  downhill: -15,
  steep_downhill: -30,
};

export default function ElevationProfile({ segments }) {
  if (!segments || segments.length === 0) return null;

  let cumElevation = 20;
  const data = segments.map((seg) => {
    cumElevation += (gradientToElevation[seg.gradient] || 0);
    return {
      km: `${seg.km} km`,
      elevation: Math.max(0, cumElevation),
      gradient: seg.gradient?.replace(/_/g, ' '),
      description: seg.description,
    };
  });

  return (
    <div className="w-full h-48">
      <ResponsiveContainer>
        <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="elevGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
              <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis
            dataKey="km"
            tick={{ fontSize: 13, fill: 'hsl(var(--muted-foreground))' }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis hide />
          <Tooltip
            contentStyle={{
              background: 'hsl(var(--card))',
              border: '1px solid hsl(var(--border))',
              borderRadius: '12px',
              fontSize: '13px',
            }}
            formatter={(value, name) => [`${value}m`, 'Elevation']}
            labelFormatter={(label) => label}
          />
          <Area
            type="monotone"
            dataKey="elevation"
            stroke="hsl(var(--primary))"
            strokeWidth={2}
            fill="url(#elevGrad)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}