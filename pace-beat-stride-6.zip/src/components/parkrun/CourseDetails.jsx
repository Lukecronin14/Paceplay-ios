import React from 'react';
import { Mountain, Layers, TrendingUp, Repeat } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import ElevationProfile from '@/components/parkrun/ElevationProfile';
import ParkRunMap from '@/components/parkrun/ParkRunMap';

const GRADIENT_LABELS = {
  flat: 'Flat',
  slight_uphill: 'Slight uphill',
  uphill: 'Uphill',
  steep_uphill: 'Steep uphill',
  slight_downhill: 'Slight downhill',
  downhill: 'Downhill',
  steep_downhill: 'Steep downhill',
};

const prettify = (value) =>
  value ? value.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase()) : null;

// Course terrain facts, per-km elevation profile and route map for a parkrun.
// `course` is the stored ParkRun record; `geo` ({ lat, lng }) comes from the
// shared parkrun events cache.
export default function CourseDetails({ course, geo, parkrunName, eventname }) {
  const segments = course?.segments || [];
  const hasMap = !!(geo?.lat && geo?.lng);

  if (!course && !hasMap) return null;

  const facts = [
    { label: 'Terrain', value: prettify(course?.terrain_type), icon: Mountain },
    { label: 'Surface', value: prettify(course?.surface), icon: Layers },
    {
      label: 'Elevation Gain',
      value: course?.elevation_gain_m != null ? `${Math.round(course.elevation_gain_m)} m` : null,
      icon: TrendingUp,
    },
    {
      label: 'Laps',
      value: course?.laps ? `${course.laps} ${course.laps === 1 ? 'lap' : 'laps'}` : null,
      icon: Repeat,
    },
  ].filter((f) => f.value);

  return (
    <div className="space-y-4 mb-8">
      {facts.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-4">
          {facts.map(({ label, value, icon: Icon }) => (
            <div key={label} className="bg-card rounded-xl border border-border p-3 sm:p-4 text-center">
              <Icon className="w-4 h-4 text-primary mx-auto mb-1.5" />
              <p className="font-heading font-bold text-sm sm:text-base">{value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </div>
          ))}
        </div>
      )}

      {course && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="font-heading text-lg">Course Profile</CardTitle>
          </CardHeader>
          <CardContent>
            {segments.length > 0 ? (
              <>
                <ElevationProfile segments={segments} />
                <div className="mt-3">
                  {segments.map((seg) => (
                    <div
                      key={seg.km}
                      className="flex items-baseline gap-3 text-sm py-1.5 border-b border-border/60 last:border-0"
                    >
                      <span className="font-heading font-semibold text-primary shrink-0">KM {seg.km}</span>
                      <span className="text-muted-foreground">
                        {GRADIENT_LABELS[seg.gradient] || seg.gradient}
                        {seg.description ? ` — ${seg.description}` : ''}
                      </span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">No detailed segment data for this course yet.</p>
            )}
          </CardContent>
        </Card>
      )}

      {hasMap && (
        <ParkRunMap
          parkrunName={parkrunName}
          lat={geo.lat}
          lng={geo.lng}
          terrainSegments={segments}
          eventname={eventname}
        />
      )}
    </div>
  );
}