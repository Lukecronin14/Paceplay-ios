import React from 'react';
import { Badge } from '@/components/ui/badge';

export default function SegmentPaceTable({ segmentPaces, segments }) {
  if (!segmentPaces || segmentPaces.length === 0) return null;

  return (
    <>
      {/* Mobile card layout */}
      <div className="md:hidden space-y-2">
        {segmentPaces.map((sp, i) => {
          const seg = segments?.[i];
          const paceMin = Math.floor(sp.pace_min_per_km);
          const paceSec = Math.round((sp.pace_min_per_km - paceMin) * 60);
          return (
            <div key={i} className="bg-muted/30 rounded-lg p-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-3 shrink-0">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-mono font-bold text-sm text-primary">{sp.km}</span>
                </div>
                <Badge variant="outline" className="text-sm capitalize">
                  {sp.gradient?.replace(/_/g, ' ') || seg?.gradient?.replace(/_/g, ' ') || '—'}
                </Badge>
              </div>
              <div className="flex items-center gap-3 text-right">
                <div>
                  <p className="text-sm text-muted-foreground uppercase">Pace</p>
                  <p className="font-mono text-sm font-medium">{paceMin}:{paceSec.toString().padStart(2, '0')}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground uppercase">Cadence</p>
                  <p className="font-mono text-sm font-medium">{sp.cadence}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground uppercase">BPM</p>
                  <p className="font-mono text-sm font-bold text-primary">{sp.target_bpm}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Desktop table layout */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-2 px-3 font-medium text-muted-foreground">KM</th>
              <th className="text-left py-2 px-3 font-medium text-muted-foreground">Terrain</th>
              <th className="text-left py-2 px-3 font-medium text-muted-foreground">Pace</th>
              <th className="text-left py-2 px-3 font-medium text-muted-foreground">Cadence</th>
              <th className="text-left py-2 px-3 font-medium text-muted-foreground">Target BPM</th>
            </tr>
          </thead>
          <tbody>
            {segmentPaces.map((sp, i) => {
              const seg = segments?.[i];
              const paceMin = Math.floor(sp.pace_min_per_km);
              const paceSec = Math.round((sp.pace_min_per_km - paceMin) * 60);
              return (
                <tr key={i} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-2.5 px-3 font-mono font-medium">{sp.km}</td>
                  <td className="py-2.5 px-3">
                    <Badge variant="outline" className="text-sm capitalize">
                      {sp.gradient?.replace(/_/g, ' ') || seg?.gradient?.replace(/_/g, ' ') || '—'}
                    </Badge>
                  </td>
                  <td className="py-2.5 px-3 font-mono">
                    {paceMin}:{paceSec.toString().padStart(2, '0')}/km
                  </td>
                  <td className="py-2.5 px-3 font-mono">{sp.cadence} spm</td>
                  <td className="py-2.5 px-3">
                    <Badge className="bg-primary/10 text-primary text-sm font-mono">
                      {sp.target_bpm} BPM
                    </Badge>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}