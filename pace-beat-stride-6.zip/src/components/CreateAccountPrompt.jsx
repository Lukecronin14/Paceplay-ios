import React from 'react';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Headphones } from 'lucide-react';
import { motion } from 'framer-motion';

export default function CreateAccountPrompt() {
  const { navigateToLogin } = useAuth();
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/10 p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full text-center"
      >
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-6">
          <Headphones className="w-8 h-8 text-white" />
        </div>
        <h1 className="font-heading text-3xl font-bold mb-3">Welcome to PacePlay</h1>
        <p className="text-muted-foreground mb-8">
          Create an account to generate terrain-adaptive playlists, track live runs, and sync your music.
          Your runs, plans, and subscription are saved to your account.
        </p>
        <Button onClick={() => navigateToLogin()} size="lg" className="w-full rounded-xl text-base">
          Create Account or Sign In
        </Button>
        <p className="text-xs text-muted-foreground mt-4">It takes less than a minute.</p>
      </motion.div>
    </div>
  );
}