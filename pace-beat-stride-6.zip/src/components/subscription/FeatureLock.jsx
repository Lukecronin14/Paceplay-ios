import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Lock, Headphones } from 'lucide-react';
import { motion } from 'framer-motion';

export default function FeatureLock() {
  const { user, navigateToLogin } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="p-6 max-w-md mx-auto text-center pt-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-5">
          <Lock className="w-8 h-8 text-primary" />
        </div>
        <h2 className="font-heading text-2xl font-bold mb-2">Premium Feature</h2>
        <p className="text-muted-foreground mb-6">
          {user
            ? 'Subscribe to PacePlay Premium to unlock live runs, AI playlists, and your run history.'
            : 'Log in or create an account to unlock live runs, AI playlists, and your run history.'}
        </p>
        <div className="flex flex-col gap-2">
          {user ? (
            <Button size="lg" className="rounded-xl" onClick={() => navigate('/subscribe')}>
              Subscribe
            </Button>
          ) : (
            <Button size="lg" className="rounded-xl" onClick={navigateToLogin}>
              Log In or Sign Up
            </Button>
          )}
          <Button variant="ghost" onClick={() => navigate('/')}>
            Back to Home
          </Button>
        </div>
      </motion.div>
    </div>
  );
}