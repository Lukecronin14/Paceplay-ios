import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useSubscription } from '@/hooks/useSubscription';
import { useAuth } from '@/lib/AuthContext';

export default function SubscriptionGuard() {
  const { user } = useAuth();
  const { isLoading, hasAccess } = useSubscription();

  if (isLoading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-muted border-t-foreground rounded-full animate-spin"></div>
      </div>
    );
  }

  if (user?.role === 'admin' || hasAccess) {
    return <Outlet />;
  }

  return <Navigate to="/subscribe" replace />;
}