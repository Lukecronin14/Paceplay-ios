import React from 'react';
import { Activity, ArrowRight, CheckCircle2, Map as MapIcon, SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ReadyStep({ onFinish }) {
  return (
    <div className="text-center">
      <div className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-5">
        <CheckCircle2 className="w-8 h-8" />
      </div>
      <h1 className="font-heading font-bold text-2xl sm:text-3xl mb-2">You're ready to run</h1>
      <p className="text-sm text-muted-foreground mb-8 max-w-sm mx-auto">
        Start a run and PacePlay builds the playlist around your pace and the terrain. You can fine-tune your music taste any time.
      </p>
      <div className="flex flex-col gap-3 max-w-sm mx-auto">
        <Button size="lg" className="rounded-xl font-semibold" onClick={() => onFinish('/live-run')}>
          <Activity className="w-4 h-4 mr-1.5" /> Start a live run
        </Button>
        <Button variant="outline" size="lg" className="rounded-xl font-semibold" onClick={() => onFinish('/parkruns')}>
          <MapIcon className="w-4 h-4 mr-1.5" /> Browse parkrun routes
        </Button>
        <Button variant="ghost" className="rounded-xl text-sm" onClick={() => onFinish('/preferences')}>
          <SlidersHorizontal className="w-4 h-4 mr-1.5" /> Customise my music preferences <ArrowRight className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}