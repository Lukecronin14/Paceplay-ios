import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MusicServiceSection from '@/components/integrations/MusicServiceSection';

export default function ConnectMusicStep({ musicConnected, onConnectionsChange, onContinue, onSkip }) {
  return (
    <div>
      <h1 className="font-heading font-bold text-2xl sm:text-3xl mb-2">Connect your music</h1>
      <p className="text-sm text-muted-foreground mb-6">
        Pick a service, connect your account and choose the playlists that get you moving — PacePlay builds your run playlists from them.
      </p>
      <MusicServiceSection onConnectionsChange={onConnectionsChange} />
      <div className="mt-8 flex flex-col gap-2">
        <Button size="lg" className="rounded-xl font-semibold" disabled={!musicConnected} onClick={onContinue}>
          Continue <ArrowRight className="w-4 h-4 ml-1" />
        </Button>
        {!musicConnected && (
          <Button variant="ghost" className="rounded-xl text-sm" onClick={onSkip}>
            Skip — I'll connect later
          </Button>
        )}
      </div>
    </div>
  );
}