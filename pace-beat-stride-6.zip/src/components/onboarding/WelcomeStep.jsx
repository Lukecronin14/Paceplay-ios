import React from 'react';
import { Headphones, Activity, Music2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const FEATURES = [
  { icon: Music2, title: 'Playlists that match your pace', desc: 'AI picks songs at the right BPM for every kilometre — tuned to your taste.' },
  { icon: Activity, title: 'Live GPS pace tracking', desc: 'The right track switches automatically as your pace and the terrain change.' },
  { icon: Headphones, title: 'Your music, your runs', desc: 'Works with Spotify or Apple Music, plus Strava routes.' },
];

export default function WelcomeStep({ onStart }) {
  return (
    <div>
      <h1 className="font-heading font-bold text-3xl sm:text-4xl mb-3">Welcome to PacePlay</h1>
      <p className="text-lg text-muted-foreground mb-8">The running companion that turns your music into a personal pacer.</p>
      <div className="space-y-3 mb-8">
        {FEATURES.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="flex items-start gap-3 bg-card border border-border rounded-xl p-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <p className="font-medium text-sm mb-0.5">{title}</p>
              <p className="text-sm text-muted-foreground">{desc}</p>
            </div>
          </div>
        ))}
      </div>
      <Button size="lg" className="w-full rounded-xl font-semibold" onClick={onStart}>
        Get started <ArrowRight className="w-4 h-4 ml-1" />
      </Button>
    </div>
  );
}