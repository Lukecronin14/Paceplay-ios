import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, X, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SetupPromptCard({ onStart, onDismiss }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-primary/5 dark:bg-primary/10 border border-primary/20 rounded-2xl p-5 mb-6 sm:mb-8"
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center shrink-0">
          <Sparkles className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <p className="font-heading font-semibold mb-1">New here? Set up in 3 quick steps</p>
          <p className="text-sm text-muted-foreground mb-4">
            Connect your music, pick your running playlists, and start your first BPM-matched run.
          </p>
          <Button size="lg" className="rounded-xl font-semibold" onClick={onStart}>
            Start setup <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss setup guide"
          className="h-11 w-11 flex items-center justify-center rounded-lg text-muted-foreground hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </motion.div>
  );
}