import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';

// Services whose long-lived refresh tokens are stored server-side.
const SERVICES = [
  { key: 'spotify', functionName: 'spotifyIntegration', refreshMarginMs: 10 * 60 * 1000 },
  { key: 'strava', functionName: 'stravaIntegration', refreshMarginMs: 30 * 60 * 1000 },
];

// One refresh per service at a time. Providers like Strava rotate refresh tokens
// on every refresh — two concurrent refreshes can invalidate the stored token
// and disconnect the user, so every call must go through this lock.
const inFlight = new Map();

// Refresh-once-per-session markers (silent restore after a fresh install or new device).
const restored = new Set();

async function persistTokens(serviceKey, accessToken, expiresAt) {
  localStorage.setItem(`${serviceKey}_access_token`, accessToken);
  if (expiresAt) localStorage.setItem(`${serviceKey}_expires_at`, String(expiresAt));
}

// Tell same-tab listeners (Home connection checks etc.) that the token set changed.
function notifyTokenChanged(serviceKey) {
  window.dispatchEvent(new Event(`${serviceKey}-token-refreshed`));
  window.dispatchEvent(new Event('storage'));
}

async function refreshAccessToken(service) {
  const res = await base44.functions.invoke(service.functionName, { action: 'refreshAccessToken' });
  const data = res.data || {};
  if (!data.accessToken) throw new Error('no token returned');
  const expiresAt = data.expiresAt || (data.expiresIn ? Date.now() + data.expiresIn * 1000 : 0);
  persistTokens(service.key, data.accessToken, expiresAt);
  notifyTokenChanged(service.key);
  return data;
}

async function refreshToken(service) {
  const existing = inFlight.get(service.key);
  if (existing) return existing;
  const promise = (async () => {
    try {
      return await refreshAccessToken(service);
    } catch (err) {
      const msg = err?.response?.data?.error || '';
      // Drop the local token only when the server says the connection is gone;
      // transient network errors keep the current token for the next check.
      if (err?.response?.status === 401 || /reconnect/i.test(msg)) {
        localStorage.removeItem(`${service.key}_access_token`);
        localStorage.removeItem(`${service.key}_expires_at`);
        notifyTokenChanged(service.key);
      }
      return null;
    } finally {
      inFlight.delete(service.key);
    }
  })();
  inFlight.set(service.key, promise);
  return promise;
}

// The refresh token lives server-side per user, so a fresh device can silently
// re-mint an access token without any OAuth flow — the user's connections
// follow their account, not the device.
async function restoreConnection(service) {
  if (restored.has(service.key)) return;
  restored.add(service.key);
  const data = await refreshToken(service);
  if (data) {
    // Keep the user-record flags in sync so connection UIs on any device agree.
    try {
      await base44.auth.updateMe({
        [`${service.key}_connected`]: true,
        [`${service.key}_connected_at`]: new Date().toISOString(),
      });
    } catch {}
  }
}

function checkTokens() {
  for (const service of SERVICES) {
    if (!localStorage.getItem(`${service.key}_access_token`)) continue;
    const expiresAt = Number(localStorage.getItem(`${service.key}_expires_at`) || 0);
    // No stored expiry (legacy session) or expiry close — refresh now.
    if (!expiresAt || expiresAt - Date.now() < service.refreshMarginMs) {
      refreshToken(service);
    }
  }
}

// Keeps Spotify/Strava access tokens in localStorage fresh so sessions and runs
// longer than the token lifetime never hit an expired token.
export function useTokenRefresh() {
  useEffect(() => {
    checkTokens();
    // Fresh install or new device: no local token yet — silently restore each
    // connection the user already linked server-side.
    for (const service of SERVICES) {
      if (!localStorage.getItem(`${service.key}_access_token`)) {
        restoreConnection(service);
      }
    }
    const id = setInterval(checkTokens, 60 * 1000);
    return () => clearInterval(id);
  }, []);
}