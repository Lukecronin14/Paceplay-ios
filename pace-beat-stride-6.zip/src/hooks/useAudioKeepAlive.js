import { useEffect, useRef } from 'react';
import { isNativeIOS } from '@/lib/native';

// Keeps the page's audio session alive during a run by looping a short
// silent audio track. Browsers exempt pages that are playing audio from
// background throttling, so GPS tracking, the Spotify poll and automatic
// track switching keep running while the device is locked / screen off
// (Android Chrome). Built at runtime as a tiny blob — no asset needed.
export function useAudioKeepAlive(active) {
  const audioRef = useRef(null);

  useEffect(() => {
    // Native iOS keeps its own background audio/location session through the
    // RunBackgroundBridge plugin. A silent keep-alive loop there would be
    // unjustified background-audio usage under App Review, so web only.
    if (!active || isNativeIOS()) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
        audioRef.current = null;
      }
      return;
    }

    // Build a 1-second silent mono WAV
    const sampleRate = 8000;
    const samples = new Int16Array(sampleRate); // all zeros = silence
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);
    const writeStr = (offset, str) => {
      for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
    };
    writeStr(0, 'RIFF');
    view.setUint32(4, 36 + samples.length * 2, true);
    writeStr(8, 'WAVE');
    writeStr(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);  // PCM
    view.setUint16(22, 1, true);  // mono
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeStr(36, 'data');
    view.setUint32(40, samples.length * 2, true);

    const blob = new Blob([buffer], { type: 'audio/wav' });
    const audio = new Audio(URL.createObjectURL(blob));
    audio.loop = true;
    // Not muted (muted audio does not count as playing) but effectively silent
    audio.volume = 0.01;
    audio.setAttribute('playsinline', '');
    audio.play().catch(() => {});
    audioRef.current = audio;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
        audioRef.current = null;
      }
    };
  }, [active]);
}