import { useState, useRef, useEffect, useCallback } from 'react';
import { haversineDistance } from '@/lib/paceUtils';
import { RunClock } from '@/lib/runClock';

export function useRunTracker(targetDistanceKm, targetTimeMin) {
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [distanceMeters, setDistanceMeters] = useState(0);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [currentPace, setCurrentPace] = useState(0);
  const [currentPosition, setCurrentPosition] = useState(null);
  const [splits, setSplits] = useState([]);

  const positionsRef = useRef([]);
  const splitsRef = useRef([]);
  const lastKmRef = useRef(0);
  const totalDistanceRef = useRef(0);
  const watchIdRef = useRef(null);
  const timerRef = useRef(null);
  const isPausedRef = useRef(false);
  // Active-time clock: excludes every paused duration from elapsed, splits
  // and final pace (pure logic in src/lib/runClock.js).
  const clockRef = useRef(new RunClock());
  // Index into positionsRef where the current (post-resume) pace window
  // starts, so the first pace samples after a resume don't span the pause gap.
  const resumeIndexRef = useRef(0);

  const handlePosition = useCallback((pos) => {
    if (isPausedRef.current) return;
    const { latitude, longitude, accuracy } = pos.coords;
    const timestamp = pos.timestamp || Date.now();
    const newPoint = { lat: latitude, lng: longitude, timestamp };
    const positions = positionsRef.current;

    // Monotonic timestamps: a fix at or before the last recorded point is a
    // duplicate — dropping it keeps restored (checkpoint-seeded) routes
    // duplicate-free across a recovery boundary.
    if (positions.length > 0 && timestamp <= positions[positions.length - 1].timestamp) return;

    // Reject poor-accuracy fixes that introduce noise and false distance jumps
    if (accuracy && accuracy > 40) {
      if (positions.length === 0) setCurrentPosition(newPoint);
      return;
    }

    if (positions.length > 0) {
      const lastPoint = positions[positions.length - 1];
      const dist = haversineDistance(lastPoint.lat, lastPoint.lng, latitude, longitude);
      if (dist > 1) {
        totalDistanceRef.current += dist;
        positions.push(newPoint);
        setDistanceMeters(totalDistanceRef.current);
        setCurrentPosition(newPoint);

        const newKm = Math.floor(totalDistanceRef.current / 1000);
        if (newKm > lastKmRef.current) {
          const elapsedAtSplit = clockRef.current.elapsedMs(timestamp) / 1000;
          const prevSplitTime = splitsRef.current.length > 0 ? splitsRef.current[splitsRef.current.length - 1].timeSec : 0;
          splitsRef.current.push({
            km: newKm,
            timeSec: elapsedAtSplit,
            splitTimeSec: elapsedAtSplit - prevSplitTime,
            paceMinPerKm: (elapsedAtSplit - prevSplitTime) / 60,
          });
          lastKmRef.current = newKm;
          setSplits([...splitsRef.current]);
        }

        const windowStart = Math.max(resumeIndexRef.current, positions.length - 6);
        const recent = positions.slice(windowStart);
        if (recent.length >= 2) {
          let distSum = 0;
          for (let i = 1; i < recent.length; i++) {
            distSum += haversineDistance(recent[i - 1].lat, recent[i - 1].lng, recent[i].lat, recent[i].lng);
          }
          const timeDiff = (recent[recent.length - 1].timestamp - recent[0].timestamp) / 1000;
          if (timeDiff > 0 && distSum > 0) {
            const paceSecPerKm = (timeDiff / distSum) * 1000;
            setCurrentPace(paceSecPerKm / 60);
          }
        }
      }
    } else {
      positions.push(newPoint);
      setCurrentPosition(newPoint);
    }
  }, []);

  const startWatching = useCallback(() => {
    if (navigator.geolocation) {
      watchIdRef.current = navigator.geolocation.watchPosition(
        handlePosition,
        (err) => console.error('GPS error:', err.message),
        { enableHighAccuracy: true, maximumAge: 0, timeout: 15000 }
      );
    }

    timerRef.current = setInterval(() => {
      if (!isPausedRef.current && clockRef.current.started) {
        setElapsedSec(Math.floor(clockRef.current.elapsedMs(Date.now()) / 1000));
      }
    }, 1000);
  }, [handlePosition]);

  const start = useCallback(() => {
    positionsRef.current = [];
    totalDistanceRef.current = 0;
    clockRef.current.start(Date.now());
    resumeIndexRef.current = 0;
    splitsRef.current = [];
    lastKmRef.current = 0;
    setSplits([]);
    isPausedRef.current = false;
    setIsActive(true);
    setIsPaused(false);
    setDistanceMeters(0);
    setElapsedSec(0);
    setCurrentPace(0);
    setCurrentPosition(null);
    startWatching();
  }, [startWatching]);

  const pause = useCallback(() => {
    if (isPausedRef.current) return;
    clockRef.current.pause(Date.now());
    isPausedRef.current = true;
    setIsPaused(true);
  }, []);

  const resume = useCallback(() => {
    if (!isPausedRef.current) return;
    clockRef.current.resume(Date.now());
    // Pace window restarts after a pause so early samples don't span the gap.
    resumeIndexRef.current = positionsRef.current.length;
    isPausedRef.current = false;
    setIsPaused(false);
  }, []);

  const stop = useCallback(() => {
    if (clockRef.current.started) {
      setElapsedSec(Math.floor(clockRef.current.elapsedMs(Date.now()) / 1000));
    }
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setIsActive(false);
    setIsPaused(false);
  }, []);

  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const getRoute = useCallback(() => {
    const positions = positionsRef.current;
    if (positions.length < 2) return [];
    const max = 250;
    if (positions.length <= max) {
      return positions.map(p => ({ lat: p.lat, lng: p.lng, t: p.timestamp }));
    }
    const step = (positions.length - 1) / (max - 1);
    const sampled = [];
    for (let i = 0; i < max; i++) {
      const idx = Math.min(positions.length - 1, Math.round(i * step));
      const p = positions[idx];
      sampled.push({ lat: p.lat, lng: p.lng, t: p.timestamp });
    }
    return sampled;
  }, []);

  // Restore an interrupted run from a checkpoint (Stage B / R2): seeds the
  // carried distance, splits, route and the EXACT RunClock state, then
  // restarts the GPS watch. The clock is NOT restarted — the original
  // start_time and pause-excluded accounting are preserved (RunClock.fromState).
  // Returns true when the payload was usable.
  const restore = useCallback((payload) => {
    const state = payload?.clockState;
    if (!state || !Number.isFinite(state.start_time_ms) || state.start_time_ms <= 0) return false;
    positionsRef.current = (payload.route || [])
      .filter((p) => p && Number.isFinite(p.lat) && Number.isFinite(p.lng) && Number.isFinite(p.t))
      .map((p) => ({ lat: p.lat, lng: p.lng, timestamp: p.t }));
    totalDistanceRef.current = Number(payload.distanceMeters) || 0;
    splitsRef.current = (payload.splits || []).filter((s) => s && Number.isFinite(s.km));
    lastKmRef.current = splitsRef.current.length > 0 ? splitsRef.current[splitsRef.current.length - 1].km : 0;
    clockRef.current = RunClock.fromState(state);
    resumeIndexRef.current = positionsRef.current.length;
    const wasPaused = Number.isFinite(state.pause_started_at_ms);
    isPausedRef.current = wasPaused;
    setIsPaused(wasPaused);
    setIsActive(true);
    setDistanceMeters(totalDistanceRef.current);
    setSplits([...splitsRef.current]);
    setCurrentPace(0);
    setElapsedSec(Math.floor(clockRef.current.elapsedMs(Date.now()) / 1000));
    const tail = positionsRef.current[positionsRef.current.length - 1];
    setCurrentPosition(tail ? { lat: tail.lat, lng: tail.lng } : null);
    startWatching();
    return true;
  }, [startWatching]);

  // Read-only snapshot for checkpoint persistence (no state mutation).
  // Returns null before the run has started (nothing to checkpoint).
  const snapshot = useCallback(() => {
    if (!clockRef.current.started) return null;
    const positions = positionsRef.current;
    const tail = positions[positions.length - 1];
    return {
      clockState: clockRef.current.toState(),
      distanceMeters: totalDistanceRef.current,
      splits: splitsRef.current.map((s) => ({ ...s })),
      route: getRoute(),
      lastPoint: tail ? { lat: tail.lat, lng: tail.lng, t: tail.timestamp } : null,
    };
  }, [getRoute]);

  const distanceKm = distanceMeters / 1000;
  const currentKm = Math.floor(distanceKm);
  const targetPace = targetTimeMin > 0 && targetDistanceKm > 0 ? targetTimeMin / targetDistanceKm : 0;
  const paceDeviation = currentPace > 0 && targetPace > 0 ? (currentPace - targetPace) / targetPace : 0;

  return {
    isActive, isPaused, currentPosition,
    distanceKm, currentPace, currentKm, paceDeviation, elapsedSec, targetPace,
    splits,
    start, pause, resume, stop, getRoute,
    // Checkpointing (Stage B / R2): read-only snapshot for persistence and
    // restore for resuming an interrupted run on the same record.
    snapshot, restore,
    // Lets the native (Capacitor) build feed background GPS fixes into the
    // same tracking logic the web geolocation watch uses.
    ingestPosition: handlePosition,
  };
}