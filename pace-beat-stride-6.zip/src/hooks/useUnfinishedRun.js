import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { RECOVERABLE_STATUSES, isUnfinishedRun } from '@/lib/runCheckpoint';

/**
 * Single source of truth for entry-point unfinished-run detection (Batch B3).
 * Home, the Live setup page and any other entry point all call this hook, so
 * they always detect the SAME unfinished run (same query, same predicate).
 *
 * Server-side filtering, user-scoped: only the signed-in user's own started
 * (active/paused) runs match — terminal and never-started records are refused
 * by the query itself, and the shared predicate double-checks.
 */
export function useUnfinishedRun() {
  const { user } = useAuth();
  const query = useQuery({
    queryKey: ['unfinishedRun', user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const page = await base44.entities.LiveRun.filter(
        { status: { $in: RECOVERABLE_STATUSES }, created_by_id: user.id },
        { sort: '-updated_date', limit: 1 }
      );
      return (page?.items || []).find(isUnfinishedRun) || null;
    },
  });
  return { unfinishedRun: query.data || null, isLoading: query.isLoading };
}