import { useEffect, useCallback, useRef } from 'react';

// Keeps the screen awake while a run is active so GPS tracking and
// track-switching continue even when the runner doesn't tap the screen.
// Crucial for accurate distance and continuous music on mobile browsers.
export function useWakeLock(active) {
  const wakeLockRef = useRef(null);
  const supported = typeof navigator !== 'undefined' && 'wakeLock' in navigator;

  const acquire = useCallback(async () => {
    if (!supported) return;
    try {
      wakeLockRef.current = await navigator.wakeLock.request('screen');
      wakeLockRef.current.addEventListener('release', () => {
        wakeLockRef.current = null;
      });
    } catch {
      // Wake lock may be denied — fail silently, app still works with screen on.
    }
  }, [supported]);

  useEffect(() => {
    if (!active) {
      if (wakeLockRef.current) {
        wakeLockRef.current.release().catch(() => {});
        wakeLockRef.current = null;
      }
      return;
    }
    acquire();
    const onVisibility = () => {
      if (document.visibilityState === 'visible' && active && !wakeLockRef.current) {
        acquire();
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      if (wakeLockRef.current) {
        wakeLockRef.current.release().catch(() => {});
        wakeLockRef.current = null;
      }
    };
  }, [active, acquire]);

  return { supported };
}