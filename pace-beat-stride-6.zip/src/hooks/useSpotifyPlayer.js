import { useState, useEffect, useCallback, useRef } from 'react';

export function useSpotifyPlayer(accessToken) {
  const [isReady, setIsReady] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeDevice, setActiveDevice] = useState(null);
  const [devices, setDevices] = useState([]);
  const [error, setError] = useState(null);
  const pollRef = useRef(null);
  const repeatFixSentAtRef = useRef(0);

  // Keep the working token fresh: the background refresher (useTokenRefresh) can
  // replace the access token mid-session, which would otherwise break playback
  // once the original token expires (~1 hour into a long run).
  const [token, setToken] = useState(accessToken);
  useEffect(() => { setToken(accessToken); }, [accessToken]);
  useEffect(() => {
    const onTokenRefreshed = () => {
      const fresh = localStorage.getItem('spotify_access_token');
      if (fresh) setToken(fresh);
    };
    window.addEventListener('spotify-token-refreshed', onTokenRefreshed);
    return () => window.removeEventListener('spotify-token-refreshed', onTokenRefreshed);
  }, []);

  const fetchDevices = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('https://api.spotify.com/v1/me/player/devices', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) {
        if (res.status === 401) setError('Spotify session expired. Reconnect from the home page.');
        return;
      }
      const data = await res.json();
      const deviceList = data.devices || [];
      setDevices(deviceList);
      const active = deviceList.find(d => d.is_active);
      if (active) {
        setActiveDevice(active);
        setIsReady(true);
        setError(null);
      } else if (deviceList.length > 0) {
        // Devices exist but none is marked active (e.g. idle between tracks).
        // Playback can still be started on them, so stay ready.
        setActiveDevice(deviceList[0]);
        setIsReady(true);
        setError(null);
      } else {
        setActiveDevice(null);
        setIsReady(false);
        setError('No Spotify device found. Open Spotify on your phone or computer and play any song first.');
      }
    } catch (err) {
      setError('Failed to connect to Spotify');
    }
  }, [token]);

  // Initial device check + polling
  useEffect(() => {
    if (!token) return;
    fetchDevices();
    pollRef.current = setInterval(fetchDevices, 15000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [token, fetchDevices]);

  // Poll actual Spotify playback state: which track is playing and how far
  // through it is. Needed to detect when a track ends, line up the next one
  // in advance, and catch foreign playback (repeat/autoplay/user picks).
  const [playbackState, setPlaybackState] = useState(null);
  useEffect(() => {
    if (!token) return;
    const poll = async () => {
      try {
        const res = await fetch('https://api.spotify.com/v1/me/player', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.status === 204) {
          setPlaybackState({ isPlaying: false, itemUri: null, progressMs: 0, durationMs: 0 });
          setIsPlaying(false);
          return;
        }
        if (!res.ok) return;
        const data = await res.json();
        setIsPlaying(data.is_playing);
        setPlaybackState({
          isPlaying: !!data.is_playing,
          itemUri: data.item?.uri || null,
          progressMs: data.progress_ms || 0,
          durationMs: data.item?.duration_ms || 0,
        });
        // Spotify can re-enable repeat from another device (or autoplay the
        // same track) — fight it so our single-track plays never loop forever.
        if (data.repeat_state && data.repeat_state !== 'off' && Date.now() - repeatFixSentAtRef.current > 30000) {
          repeatFixSentAtRef.current = Date.now();
          fetch('https://api.spotify.com/v1/me/player/repeat?state=off', {
            method: 'PUT',
            headers: { 'Authorization': `Bearer ${token}` },
          }).catch(() => {});
        }
      } catch {
        // ignore transient polling errors
      }
    };
    poll();
    const id = setInterval(poll, 5000);
    return () => clearInterval(id);
  }, [token]);

  const playTrack = useCallback(async (spotifyUri) => {
    if (!token) return;
    const playTo = async (deviceId) => {
      const url = deviceId
        ? `https://api.spotify.com/v1/me/player/play?device_id=${deviceId}`
        : 'https://api.spotify.com/v1/me/player/play';
      return fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ uris: [spotifyUri] }),
      });
    };
    try {
      const res = await playTo(activeDevice?.id);
      if (res.status === 204) {
        setIsPlaying(true);
        setError(null);
      } else if (res.status === 404) {
        // Device went inactive (e.g. between tracks) — re-check devices and
        // start playback on the first available one instead of giving up.
        const devRes = await fetch('https://api.spotify.com/v1/me/player/devices', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (devRes.ok) {
          const devData = await devRes.json();
          const list = devData.devices || [];
          setDevices(list);
          const target = list.find(d => d.is_active) || list[0];
          if (target) {
            const retry = await playTo(target.id);
            if (retry.status === 204) {
              setActiveDevice(target);
              setIsReady(true);
              setIsPlaying(true);
              setError(null);
              return;
            }
          }
        }
        setError('No active Spotify device. Open Spotify on your phone and start playing any song.');
        fetchDevices();
      } else if (res.status === 401) {
        setError('Spotify session expired. Reconnect from the home page.');
      } else {
        const errText = await res.text();
        console.error('Spotify play error:', res.status, errText);
      }
    } catch (err) {
      console.error('Play failed:', err);
    }
  }, [token, activeDevice, fetchDevices]);

  const pause = useCallback(async () => {
    if (!token) return;
    try {
      await fetch('https://api.spotify.com/v1/me/player/pause', {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      setIsPlaying(false);
    } catch (err) {
      console.error('Pause failed:', err);
    }
  }, [token]);

  const resume = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('https://api.spotify.com/v1/me/player/play', {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      if (res.status === 204) setIsPlaying(true);
    } catch (err) {
      console.error('Resume failed:', err);
    }
  }, [token]);

  const togglePlay = useCallback(async () => {
    if (isPlaying) {
      await pause();
    } else {
      await resume();
    }
  }, [isPlaying, pause, resume]);

  // Add a track to Spotify's queue so it starts gaplessly when the current
  // song ends — works even while the device is locked.
  const queueTrack = useCallback(async (spotifyUri) => {
    if (!token) return false;
    const addToQueue = async () => {
      const base = `https://api.spotify.com/v1/me/player/queue?uri=${encodeURIComponent(spotifyUri)}`;
      const url = activeDevice?.id ? `${base}&device_id=${activeDevice.id}` : base;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      return res.ok;
    };
    try {
      // One automatic retry: a transient 4xx/5xx used to leave the queue empty
      // and force an audible playback restart at the next song boundary.
      if (await addToQueue()) return true;
      return await addToQueue();
    } catch {
      return false;
    }
  }, [token, activeDevice]);

  // Turn repeat off so Spotify doesn't loop our single-track plays.
  const setRepeatOff = useCallback(async () => {
    if (!token) return;
    try {
      await fetch('https://api.spotify.com/v1/me/player/repeat?state=off', {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` },
      });
    } catch {
      // non-fatal
    }
  }, [token]);

  const transferPlayback = useCallback(async (deviceId) => {
    if (!token || !deviceId) return;
    try {
      const res = await fetch('https://api.spotify.com/v1/me/player', {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ device_ids: [deviceId], play: true }),
      });
      if (res.ok || res.status === 204) {
        setActiveDevice(devices.find(d => d.id === deviceId));
        setIsReady(true);
        setIsPlaying(true);
        setError(null);
      }
    } catch (err) {
      console.error('Transfer failed:', err);
    }
  }, [token, devices]);

  return {
    isReady,
    isPlaying,
    deviceId: activeDevice?.id || null,
    activeDevice,
    devices,
    error,
    togglePlay,
    pause,
    resume,
    playTrack,
    transferPlayback,
    refreshDevices: fetchDevices,
    playbackState,
    queueTrack,
    setRepeatOff,
  };
}