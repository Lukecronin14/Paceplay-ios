import { useState, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { pickSubscriptionRecord, computeEntitlements } from '@/lib/subscriptionAccess';

async function fetchSubscription() {
  const list = await base44.entities.Subscription.list();
  if (!Array.isArray(list) || list.length === 0) return null;
  // Selection prefers a verified/real record over a trial; see
  // pickSubscriptionRecord in lib/subscriptionAccess.js.
  return pickSubscriptionRecord(list);
}

export function useSubscription() {
  const queryClient = useQueryClient();
  const [checkoutError, setCheckoutError] = useState(null);

  const { data: subscription, isLoading } = useQuery({
    queryKey: ['subscription'],
    queryFn: fetchSubscription,
  });

  const startCheckout = useCallback(async () => {
    setCheckoutError(null);
    try {
      const res = await base44.functions.invoke('create-checkout', { action: 'createCheckout' });
      if (res.data?.redirectUrl) {
        window.location.href = res.data.redirectUrl;
      } else {
        setCheckoutError('Failed to start checkout. Please try again.');
      }
    } catch (err) {
      setCheckoutError(err?.response?.data?.error || 'Something went wrong. Please try again.');
    }
  }, []);

  const cancelSubscription = useCallback(async () => {
    await base44.functions.invoke('create-checkout', { action: 'cancelSubscription' });
    queryClient.invalidateQueries({ queryKey: ['subscription'] });
  }, [queryClient]);

  const entitlements = computeEntitlements(subscription);

  return {
    subscription,
    isLoading,
    ...entitlements,
    startCheckout,
    cancelSubscription,
    checkoutError,
  };
}