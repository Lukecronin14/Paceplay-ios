import { useCallback, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import {
  buildCheckpoint,
  nextSeq,
  TERMINAL_STATUSES,
  CHECKPOINT_INTERVAL_MS,
} from '@/lib/runCheckpoint';

/** localStorage mirror key for one live run (best-effort crash buffer). */
export function mirrorKey(runId) {
  return `liverun_checkpoint_${runId}`;
}

const MAX_FLUSH_RETRIES = 3;
const RETRY_BACKOFF_MS = 1500;

/**
 * Checkpoint persistence for one active live run (Stage B / R2, Batch B2).
 *
 * Guarantees and design (STAGE-B-R2-DESIGN.md):
 * - Every server write is a conditional updateMany whose filter excludes
 *   terminal statuses — the data layer evaluates the filter atomically with
 *   the write (verified: concurrent same-field races always produce exactly
 *   one winner; a stale checkpoint after completion is always refused), so a
 *   checkpoint can never land on a completed/abandoned run.
 * - The localStorage mirror is best-effort and synchronous; the server
 *   checkpoint is the durable guarantee. It never blocks GPS processing:
 *   the tracker is only read through snapshot().
 * - Failures are non-blocking: retry with backoff per flush; a toast is
 *   surfaced only after repeated consecutive failures.
 */
export function useRunCheckpoint({ run, tracker, enabled, onTerminal, onError }) {
  const seqRef = useRef(0); // seq of the last CONFIRMED server checkpoint
  const lastFlushAtRef = useRef(0);
  const lastKmRef = useRef(-1);
  const failuresRef = useRef(0);
  const busyRef = useRef(false);
  const trackerRef = useRef(tracker);
  trackerRef.current = tracker;
  const onTerminalRef = useRef(onTerminal);
  onTerminalRef.current = onTerminal;
  const onErrorRef = useRef(onError);
  onErrorRef.current = onError;
  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;

  const runId = run?.id;

  const writeMirror = useCallback((cp) => {
    if (!runId) return;
    try {
      localStorage.setItem(mirrorKey(runId), JSON.stringify(cp));
    } catch {
      // Storage unavailable (private mode, quota) — the server checkpoint
      // remains the durable guarantee.
    }
  }, [runId]);

  /** Clear the local mirror (server checkpoint is cleared by the guarded write). */
  const clearMirror = useCallback(() => {
    if (!runId) return;
    try {
      localStorage.removeItem(mirrorKey(runId));
    } catch {
      // ignore — best-effort
    }
  }, [runId]);

  /** One guarded server checkpoint write. updated:0 means the run went terminal. */
  const writeServerCheckpoint = useCallback(async () => {
    if (!runId || !enabledRef.current || busyRef.current) return { updated: 0 };
    const snapshot = trackerRef.current?.snapshot?.();
    if (!snapshot || !snapshot.clockState) return { updated: 0 };
    busyRef.current = true;
    try {
      const cp = buildCheckpoint({
        seq: nextSeq({ seq: seqRef.current }),
        nowMs: Date.now(),
        clockState: snapshot.clockState,
        distanceMeters: snapshot.distanceMeters,
        splits: snapshot.splits,
        route: snapshot.route,
      });
      // Mirror first (synchronous): the crash buffer is fresh even if the
      // server write never completes.
      writeMirror(cp);
      const res = await base44.entities.LiveRun.updateMany(
        { id: runId, status: { $nin: TERMINAL_STATUSES } },
        { $set: { checkpoint: cp } }
      );
      if (res?.updated === 1) {
        seqRef.current = cp.seq;
        lastFlushAtRef.current = Date.now();
        lastKmRef.current = trackerRef.current.currentKm;
        failuresRef.current = 0;
        return { updated: 1, checkpoint: cp };
      }
      // updated: 0 — the record went terminal (or vanished). Not an error:
      // the data layer refused the write.
      onTerminalRef.current?.();
      return { updated: 0, terminal: true };
    } finally {
      busyRef.current = false;
    }
  }, [runId, writeMirror]);

  /** Flush with retry/backoff. Never throws; failures are non-blocking. */
  const flushNow = useCallback(async (reason) => {
    let lastErr = null;
    for (let attempt = 0; attempt < MAX_FLUSH_RETRIES; attempt++) {
      try {
        return await writeServerCheckpoint();
      } catch (err) {
        lastErr = err;
        console.error(`Checkpoint flush failed (${reason}, attempt ${attempt + 1}):`, err);
        if (attempt < MAX_FLUSH_RETRIES - 1) {
          await new Promise((r) => setTimeout(r, RETRY_BACKOFF_MS * (attempt + 1)));
        }
      }
    }
    failuresRef.current += 1;
    if (failuresRef.current >= 3) {
      onErrorRef.current?.();
      failuresRef.current = 0; // announce once per failure burst
    }
    return { updated: 0, error: lastErr };
  }, [writeServerCheckpoint]);

  /**
   * Guarded update of run fields (status transitions, results, discard).
   * The data layer refuses the write for completed/abandoned runs:
   * updated:0 means another instance finished/discarded the run first.
   */
  const guardedUpdate = useCallback(async (patch) => {
    if (!runId) return { updated: 0 };
    const res = await base44.entities.LiveRun.updateMany(
      { id: runId, status: { $nin: TERMINAL_STATUSES } },
      { $set: patch }
    );
    if (res?.updated === 1) return { updated: 1 };
    return { updated: 0, terminal: true };
  }, [runId]);

  /**
   * Adoption point for recovery: continue the sequence after restoring a
   * checkpoint (seq of the adopted checkpoint), or restart from 0 on start.
   */
  const setStartSeq = useCallback((seq) => {
    seqRef.current = Number.isFinite(seq) && seq >= 0 ? seq : 0;
    lastKmRef.current = trackerRef.current?.currentKm ?? -1;
    lastFlushAtRef.current = 0; // allow an immediate flush (e.g. mirror adoption)
  }, []);

  // 1s tick: refresh the local mirror between server checkpoints; flush the
  // server every CHECKPOINT_INTERVAL_MS or immediately on a km-crossing.
  useEffect(() => {
    if (!enabled || !runId) return;
    const tick = setInterval(() => {
      if (busyRef.current) return;
      const snapshot = trackerRef.current?.snapshot?.();
      if (!snapshot || !snapshot.clockState) return;
      const due = Date.now() - lastFlushAtRef.current >= CHECKPOINT_INTERVAL_MS;
      const kmCrossed = trackerRef.current.currentKm > lastKmRef.current;
      if (due || kmCrossed) {
        flushNow(kmCrossed && !due ? 'km' : 'interval').catch(() => {});
      } else {
        // Mirror refresh with a speculative seq — the confirmed seq only
        // advances on a confirmed server write.
        writeMirror(buildCheckpoint({
          seq: nextSeq({ seq: seqRef.current }),
          nowMs: Date.now(),
          clockState: snapshot.clockState,
          distanceMeters: snapshot.distanceMeters,
          splits: snapshot.splits,
          route: snapshot.route,
        }));
      }
    }, 1000);
    return () => clearInterval(tick);
  }, [enabled, runId, flushNow, writeMirror]);

  // Page hidden / closed: synchronous mirror write + best-effort server flush
  // (an async server write may not complete on a real close — the mirror is
  // the reliable layer here, the server checkpoint bounds the loss).
  useEffect(() => {
    if (!enabled) return;
    const onHide = () => { flushNow('hide').catch(() => {}); };
    const onVisibility = () => { if (document.hidden) onHide(); };
    window.addEventListener('pagehide', onHide);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('pagehide', onHide);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [enabled, flushNow]);

  // Connectivity restored (Batch B3): flush any pending offline run data
  // immediately. Idempotent — a refused write (run went terminal while
  // offline) is handled by onTerminal, and replayed checkpoint data converges
  // by seq, so a repeated flush can never duplicate or regress anything.
  useEffect(() => {
    if (!enabled) return;
    const onOnline = () => { flushNow('online').catch(() => {}); };
    window.addEventListener('online', onOnline);
    return () => window.removeEventListener('online', onOnline);
  }, [enabled, flushNow]);

  return { flushNow, guardedUpdate, setStartSeq, clearMirror };
}