import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export function useSpotifyData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const token = typeof window !== 'undefined' ? localStorage.getItem('spotify_access_token') : null;

  const fetchAll = async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      // Fetch music preferences to get selected running playlists
      const prefsList = await base44.entities.MusicPreference.list('-created_date', 1);
      const prefs = prefsList.length > 0 ? prefsList[0] : {};
      const playlistIds = (prefs.selected_running_playlists || []).map(p => p.id);

      const [profileRes, playlistRes] = await Promise.all([
        base44.functions.invoke('spotifyIntegration', { action: 'getProfile', accessToken: token }),
        base44.functions.invoke('spotifyIntegration', { action: 'getPlaylistTracks', accessToken: token, playlistIds }),
      ]);

      const profile = profileRes.data || {};
      const playlistTracks = playlistRes.data?.tracks || [];
      const selectedPlaylistTracks = playlistTracks.filter(t => t.is_selected);
      const otherPlaylistTracks = playlistTracks.filter(t => !t.is_selected);

      const allTracks = [
        ...selectedPlaylistTracks.map(t => ({ title: t.title, artist: t.artist, source: 'selected_playlist', uri: t.uri })),
        ...otherPlaylistTracks.map(t => ({ title: t.title, artist: t.artist, source: 'playlist', uri: t.uri })),
        ...(profile.topTracks || []).map(t => ({ title: t.name, artist: t.artist, source: 'top_track' })),
        ...(profile.recentTracks || []).map(t => ({ title: t.name, artist: t.artist, source: 'recent' })),
      ];

      const allArtists = [
        ...(profile.topArtists || []).map(a => a.name),
        ...(profile.recentTracks || []).map(t => t.artist),
        ...playlistTracks.map(t => t.artist),
      ].filter(Boolean);

      const uniqueArtists = [...new Set(allArtists)];

      setData({
        profile,
        playlistTracks,
        allTracks,
        uniqueArtists,
        playlistCount: playlistRes.data?.playlistCount || 0,
      });
    } catch (err) {
      setError('Failed to fetch Spotify data');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) fetchAll();
  }, [token]);

  return { data, loading, error, refetch: fetchAll };
}