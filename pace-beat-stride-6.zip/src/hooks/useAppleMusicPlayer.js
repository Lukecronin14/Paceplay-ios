import { useCallback, useEffect, useRef, useState } from 'react';
import { getMusicKitInstance } from '@/lib/appleMusicData';

// Apple Music playback via MusicKit JS — the counterpart of useSpotifyPlayer.
// Plays in-page, so no device selection is needed; an active Apple Music
// subscription is required for full-track playback. The next pace-matched
// track can be pre-queued so MusicKit advances gaplessly on song end (and
// keeps playing on a locked screen) instead of the app restarting playback
// after noticing the silence on a poll.
export function useAppleMusicPlayer(enabled) {
  const [isReady, setIsReady] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [error, setError] = useState(null);
  const [nowPlayingItemId, setNowPlayingItemId] = useState(null);
  const [playbackTime, setPlaybackTime] = useState({ progressMs: 0, durationMs: 0 });
  const musicRef = useRef(null);

  useEffect(() => {
    if (!enabled) return undefined;
    let cancelled = false;
    let stateHandler = null;
    let timeHandler = null;

    getMusicKitInstance().then((music) => {
      if (cancelled) return;
      musicRef.current = music;
      const readState = () => {
        const item = music.player?.nowPlayingItem;
        setNowPlayingItemId(item?.id ?? item?.container?.id ?? null);
        const state = music.playbackState;
        setIsPlaying(state === 'playing' || state === 2);
      };
      stateHandler = readState;
      timeHandler = () => {
        const p = music.player;
        if (!p) return;
        const progress = Math.round(p.currentTime || 0) * 1000;
        const duration = Math.round(p.nowPlayingItem?.playbackDuration || 0);
        setPlaybackTime((prev) =>
          prev.progressMs === progress && prev.durationMs === duration
            ? prev
            : { progressMs: progress, durationMs: duration }
        );
      };
      music.addEventListener('playbackStateDidChange', stateHandler);
      music.addEventListener('playbackTimeDidChange', timeHandler);
      music.addEventListener('nowPlayingItemDidChange', readState);
      readState();
      timeHandler();
      setIsReady(true);
      setError(null);
    }).catch(() => {
      if (!cancelled) setError('Could not start Apple Music playback. Reconnect Apple Music from the home page.');
    });

    return () => {
      cancelled = true;
      if (musicRef.current) {
        if (stateHandler) musicRef.current.removeEventListener('playbackStateDidChange', stateHandler);
        if (timeHandler) musicRef.current.removeEventListener('playbackTimeDidChange', timeHandler);
      }
    };
  }, [enabled]);

  // Plays the given catalog track, optionally pre-queueing the next one so
  // MusicKit advances natively when the song ends (gapless, lock-screen safe).
  const playTrack = useCallback(async (catalogTrackId, nextCatalogId) => {
    const music = musicRef.current;
    if (!music || !catalogTrackId) return;
    try {
      const items = [{ type: 'songs', id: catalogTrackId }];
      if (nextCatalogId) items.push({ type: 'songs', id: nextCatalogId });
      await music.setQueue({ items });
      await music.play();
    } catch (err) {
      console.error('Apple Music play failed:', err);
      setError('Playback failed. Full playback requires an active Apple Music subscription.');
    }
  }, []);

  // Appends a track to the playback queue for the next gapless transition.
  const queueNext = useCallback(async (catalogTrackId) => {
    const music = musicRef.current;
    if (!music || !catalogTrackId) return false;
    try {
      await music.player.queue.append({ items: [{ type: 'songs', id: catalogTrackId }] });
      return true;
    } catch {
      return false;
    }
  }, []);

  const pause = useCallback(async () => {
    try {
      await musicRef.current?.pause();
    } catch (err) {
      console.error('Apple Music pause failed:', err);
    }
  }, []);

  const resume = useCallback(async () => {
    try {
      await musicRef.current?.play();
    } catch (err) {
      console.error('Apple Music resume failed:', err);
    }
  }, []);

  const togglePlay = useCallback(() => {
    if (isPlaying) {
      pause();
    } else {
      resume();
    }
  }, [isPlaying, pause, resume]);

  return {
    isReady,
    isPlaying,
    error,
    togglePlay,
    pause,
    resume,
    playTrack,
    queueNext,
    nowPlayingItemId,
    playbackTime,
  };
}