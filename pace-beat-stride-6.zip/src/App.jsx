import React, { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AppLayout from '@/components/layout/AppLayout';
import ErrorBoundary from '@/components/common/ErrorBoundary';
import { useThemeSync } from '@/hooks/useThemeSync';

const Home = lazy(() => import('@/pages/Home'));
const Onboarding = lazy(() => import('@/pages/Onboarding'));
const ParkRuns = lazy(() => import('@/pages/ParkRuns'));
const ParkRunDetail = lazy(() => import('@/pages/ParkRunDetail'));
const MyPlans = lazy(() => import('@/pages/MyPlans'));
const PlanDetail = lazy(() => import('@/pages/PlanDetail'));
const RunHistory = lazy(() => import('@/pages/RunHistory'));
const MusicPreferences = lazy(() => import('@/pages/MusicPreferences'));
const SpotifyCallback = lazy(() => import('@/pages/SpotifyCallback'));
const StravaCallback = lazy(() => import('@/pages/StravaCallback'));
const StravaRuns = lazy(() => import('@/pages/StravaRuns'));
const StravaRunDetail = lazy(() => import('@/pages/StravaRunDetail'));
const LiveRunSetup = lazy(() => import('@/pages/LiveRunSetup'));
const LiveRunActive = lazy(() => import('@/pages/LiveRunActive'));
const Subscribe = lazy(() => import('@/pages/Subscribe'));
const ThankYou = lazy(() => import('@/pages/ThankYou'));
const Privacy = lazy(() => import('@/pages/Privacy'));
const Terms = lazy(() => import('@/pages/Terms'));
const AdminUsers = lazy(() => import('@/pages/AdminUsers'));
const Account = lazy(() => import('@/pages/Account'));
const RoutesHub = lazy(() => import('@/pages/RoutesHub'));

function RouteLoader() {
  return (
    <div className="fixed inset-0 flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
    </div>
  );
}

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return <RouteLoader />;
  }

  if (authError?.type === 'user_not_registered') {
    return <UserNotRegisteredError />;
  }

  return (
    <Suspense fallback={<RouteLoader />}>
      <Routes>
        <Route path="/spotify-callback" element={<SpotifyCallback />} />
        <Route path="/strava-callback" element={<StravaCallback />} />
        <Route path="/subscribe" element={<Subscribe />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/onboarding/welcome" element={<Onboarding />} />
        <Route path="/onboarding/music" element={<Onboarding />} />
        <Route path="/onboarding/ready" element={<Onboarding />} />
        <Route path="/thank-you" element={<ThankYou />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/terms" element={<Terms />} />
        <Route element={<AppLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/routes" element={<RoutesHub />} />
          <Route path="/parkruns" element={<ParkRuns />} />
          <Route path="/parkruns/:id" element={<ParkRunDetail />} />
          <Route path="/my-plans" element={<MyPlans />} />
          <Route path="/my-plans/:id" element={<PlanDetail />} />
          <Route path="/run-history" element={<RunHistory />} />
          <Route path="/strava-runs" element={<StravaRuns />} />
          <Route path="/strava-runs/:id" element={<StravaRunDetail />} />
          <Route path="/preferences" element={<MusicPreferences />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/account" element={<Account />} />
          <Route path="/live-run" element={<LiveRunSetup />} />
          <Route path="/live-run/:id" element={<LiveRunActive />} />
        </Route>
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </Suspense>
  );
};

function App() {
  useThemeSync();
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ErrorBoundary>
            <AuthenticatedApp />
          </ErrorBoundary>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App