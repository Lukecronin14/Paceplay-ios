import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Timer, Music, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import PlaylistItem from '@/components/playlist/PlaylistItem';
import SegmentPaceTable from '@/components/parkrun/SegmentPaceTable';
import PullToRefresh from '@/components/common/PullToRefresh';
import PageHeader from '@/components/common/PageHeader';
import SpotifySection from '@/components/integrations/SpotifySection';
import ExportToSpotify from '@/components/plan/ExportToSpotify';
import ExportToAppleMusic from '@/components/plan/ExportToAppleMusic';
import { getPreferredMusicService } from '@/lib/musicService';
import ParkRunMap from '@/components/parkrun/ParkRunMap';

export default function PlanDetail() {
  const { id: planId } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ['runPlans'],
    queryFn: () => base44.entities.RunPlan.list('-created_date', 100),
    initialData: [],
  });

  const { data: parkruns = [] } = useQuery({
    queryKey: ['parkruns'],
    queryFn: () => base44.entities.ParkRun.list('name', 500),
    initialData: [],
  });

  const plan = plans.find(p => p.id === planId);
  const parkrun = plan ? parkruns.find(pr => pr.id === plan.parkrun_id) : null;

  // Fetch live parkrun coordinates for the map
  const [parkrunGeo, setParkrunGeo] = useState(null);
  useEffect(() => {
    if (!plan) return;
    import('@/lib/parkrunData').then(m => m.fetchUKParkRuns()).then(events => {
      const found = events.find(e => e.eventname === plan.parkrun_id || e.name === plan.parkrun_name);
      if (found) setParkrunGeo(found);
    }).catch(() => {});
  }, [plan?.id]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!plan) {
    return (
      <div className="p-6 md:p-10 text-center">
        <p className="text-muted-foreground">Plan not found</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate('/my-plans')}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Plans
        </Button>
      </div>
    );
  }

  const totalDuration = (plan.playlist || []).reduce((s, t) => s + (t.duration_sec || 0), 0);
  const totalMin = Math.floor(totalDuration / 60);
  const totalSec = totalDuration % 60;

  return (
    <PullToRefresh onRefresh={() => queryClient.invalidateQueries({ queryKey: ['runPlans'] })}>
    <div className="p-4 sm:p-6 md:p-10 max-w-4xl mx-auto">
      <PageHeader onBack={() => navigate('/my-plans')} />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        {/* Header */}
        <div className="mb-8">
          <h1 className="font-heading font-bold text-2xl md:text-3xl mb-2">{plan.parkrun_name}</h1>
          <div className="flex items-center gap-3 flex-wrap">
            <Badge variant="secondary" className="text-sm">
              <Timer className="w-3.5 h-3.5 mr-1" />
              {plan.target_time_min} min target
            </Badge>
            <Badge className="bg-primary/10 text-primary text-sm">
              {(plan.target_time_min / 5).toFixed(1)} min/km pace
            </Badge>
            <Badge variant="outline" className="text-sm">
              <Music className="w-3.5 h-3.5 mr-1" />
              {plan.playlist?.length || 0} tracks • {totalMin}:{totalSec.toString().padStart(2, '0')}
            </Badge>
          </div>
        </div>

        {/* Pace strategy */}
        {plan.segment_paces && plan.segment_paces.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="font-heading text-lg flex items-center gap-2">
                <Zap className="w-5 h-5 text-primary" />
                Pace Strategy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <SegmentPaceTable
                segmentPaces={plan.segment_paces}
                segments={parkrun?.segments || []}
              />
            </CardContent>
          </Card>
        )}

        {/* Route map */}
        <div className="mb-6">
          <ParkRunMap
            parkrunName={plan.parkrun_name}
            lat={parkrunGeo?.lat}
            lng={parkrunGeo?.lng}
            eventname={parkrunGeo?.eventname}
            terrainSegments={plan.segment_paces?.map(sp => ({
              km: sp.km,
              gradient: sp.gradient,
            }))}
          />
        </div>

        {/* Spotify integration */}
        <div className="mb-6">
          <SpotifySection />
        </div>

        {/* Export to preferred music service */}
        <div className="mb-4">
          {getPreferredMusicService() === 'apple_music' ? (
            <ExportToAppleMusic plan={plan} />
          ) : (
            <ExportToSpotify plan={plan} />
          )}
        </div>

        {/* Playlist */}
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-lg flex items-center gap-2">
              <Music className="w-5 h-5 text-accent" />
              Your Playlist
            </CardTitle>
          </CardHeader>
          <CardContent className="p-2">
            {plan.playlist && plan.playlist.length > 0 ? (
              <div className="divide-y divide-border/50">
                {plan.playlist.map((track, i) => (
                  <PlaylistItem key={i} track={track} index={i} />
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">No tracks in this playlist</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
    </PullToRefresh>
  );
}