import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { fetchUKParkRuns } from '@/lib/parkrunData';
import { Search, Map, ExternalLink, ArrowRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import PageHeader from '@/components/common/PageHeader';
import PullToRefresh from '@/components/common/PullToRefresh';

export default function ParkRuns() {
  const [search, setSearch] = useState('');
  const { pathname } = useLocation();
  const queryClient = useQueryClient();

  const { data: parkruns = [], isLoading, error } = useQuery({
    queryKey: ['liveParkruns'],
    queryFn: fetchUKParkRuns,
    staleTime: 1000 * 60 * 60, // cache 1 hour
  });

  const filtered = useMemo(() => {
    if (!search.trim()) return parkruns;
    const q = search.toLowerCase();
    return parkruns.filter(p =>
      p.name?.toLowerCase().includes(q) ||
      p.location?.toLowerCase().includes(q) ||
      p.shortName?.toLowerCase().includes(q)
    );
  }, [parkruns, search]);

  return (
    <PullToRefresh enabled={pathname === '/parkruns'} onRefresh={() => queryClient.invalidateQueries({ queryKey: ['liveParkruns'] })}>
    <div className="p-4 sm:p-6 md:p-10 max-w-4xl mx-auto">
      <PageHeader title="UK Parkruns" />
      <div className="mb-6">
        <p className="text-muted-foreground text-sm">
          {isLoading ? 'Loading...' : `${parkruns.length.toLocaleString()} events across the UK`}
        </p>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or location..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10 rounded-xl"
        />
      </div>

      {error && (
        <div className="text-center py-12 text-muted-foreground">
          <p>Failed to load parkrun data. Please try again.</p>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-3">
          {Array(12).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <Map className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-muted-foreground">No parkruns found matching "{search}"</p>
        </div>
      ) : (
        <div className="space-y-2">
          {search && (
            <p className="text-sm text-muted-foreground mb-3">{filtered.length} result{filtered.length !== 1 ? 's' : ''}</p>
          )}
          {filtered.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.015, 0.3), duration: 0.2 }}
            >
              <Link to={`/parkruns/${p.id}?name=${encodeURIComponent(p.name)}&location=${encodeURIComponent(p.location)}&eventname=${encodeURIComponent(p.eventname)}`}>
                <div className="bg-card rounded-xl border border-border px-4 py-3 hover:border-primary/30 hover:shadow-md hover:shadow-primary/5 transition-all group flex items-center justify-between">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-sm group-hover:text-primary transition-colors truncate">
                      {p.name}
                    </p>
                    <p className="text-sm text-muted-foreground truncate mt-0.5">{p.location}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0 ml-3" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
    </PullToRefresh>
  );
}