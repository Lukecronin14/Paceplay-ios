import React from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Activity, AlertCircle, Clock, TrendingUp, Footprints } from 'lucide-react';
import { motion } from 'framer-motion';
import PageHeader from '@/components/common/PageHeader';
import { Badge } from '@/components/ui/badge';
import { formatPace, formatTime, formatDistance } from '@/lib/paceUtils';
import SendToStrava from '@/components/runs/SendToStrava';
import { Button } from '@/components/ui/button';
import PullToRefresh from '@/components/common/PullToRefresh';

const formatDate = (d) => d
  ? new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
  : '';

export default function RunHistory() {
  const { pathname } = useLocation();
  const queryClient = useQueryClient();
  const { data: runs = [], isLoading, isError } = useQuery({
    queryKey: ['liveRuns'],
    // Summary endpoint strips GPS routes and track pools so the list loads fast
    queryFn: async () => {
      const res = await base44.functions.invoke('run-summaries');
      return res.data?.runs || [];
    },
    initialData: [],
  });

  return (
    <PullToRefresh
      enabled={pathname === '/run-history'}
      onRefresh={() => queryClient.invalidateQueries({ queryKey: ['liveRuns'] })}
    >
    <div className="p-4 sm:p-6 md:p-10 max-w-4xl mx-auto">
      <PageHeader title="Run History" />
      <div className="mb-8">
        <p className="text-muted-foreground">Every run you've tracked with PacePlay — export any route to Strava.</p>
      </div>

      {isError ? (
        <div className="text-center py-20">
          <AlertCircle className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-muted-foreground mb-1">Couldn't load your run history.</p>
          <p className="text-sm text-muted-foreground">Check your connection and pull down to try again.</p>
        </div>
      ) : isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
        </div>
      ) : runs.length === 0 ? (
        <div className="text-center py-20">
          <Activity className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-muted-foreground mb-1">No runs tracked yet.</p>
          <p className="text-sm text-muted-foreground mb-4">Start a live run and PacePlay will match the music to your pace.</p>
          <Link to="/live-run">
            <Button className="rounded-xl">Start a live run</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {runs.map((run, i) => {
            const completed = run.status === 'completed';
            const abandoned = run.status === 'abandoned';
            const dist = completed ? run.actual_distance_km : run.target_distance_km;
            const timeMin = completed ? run.actual_time_min : run.target_time_min;
            const pace = completed && dist > 0 ? timeMin / dist : run.target_pace_per_km;
            return (
              <motion.div key={run.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                <div className={`bg-card rounded-2xl border border-border p-4 sm:p-5 transition-all ${abandoned ? 'opacity-60' : 'hover:border-primary/30'}`}>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div>
                      <h3 className="font-heading font-semibold text-base sm:text-lg">
                        {completed ? `${formatDistance(dist)} km` : `${formatDistance(run.target_distance_km)} km target`}
                      </h3>
                      <p className="text-xs text-muted-foreground">{formatDate(run.created_date)}</p>
                    </div>
                    <Badge
                      variant={abandoned ? 'outline' : completed ? 'default' : 'secondary'}
                      className={`capitalize text-xs ${abandoned ? 'text-muted-foreground' : ''}`}
                    >
                      {abandoned ? 'discarded' : run.status}
                    </Badge>
                  </div>
                  {abandoned ? (
                    <p className="text-sm text-muted-foreground mb-4">
                      Discarded without results — kept in your history, cannot be resumed.
                    </p>
                  ) : (
                    <>
                      <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm mb-4">
                        <div className="flex items-center gap-1.5">
                          <Footprints className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span className="font-medium">{formatDistance(dist)} km</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span className="font-medium">{formatTime(Math.round((timeMin || 0) * 60))}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <TrendingUp className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span className="font-medium">{formatPace(pace)} /km</span>
                        </div>
                      </div>
                      {completed && <SendToStrava run={run} />}
                    </>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
    </PullToRefresh>
  );
}