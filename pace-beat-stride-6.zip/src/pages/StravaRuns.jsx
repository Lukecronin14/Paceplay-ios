import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Activity, Clock, MapPin, TrendingUp, Loader2, Mountain, Repeat } from 'lucide-react';
import { motion } from 'framer-motion';
import PullToRefresh from '@/components/common/PullToRefresh';
import PageHeader from '@/components/common/PageHeader';

function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function formatPace(speedMs) {
  if (!speedMs || speedMs <= 0) return '—';
  const paceSecPerKm = 1000 / speedMs;
  const min = Math.floor(paceSecPerKm / 60);
  const sec = Math.floor(paceSecPerKm % 60);
  return `${min}:${sec.toString().padStart(2, '0')}`;
}

function formatDate(dateStr) {
  return new Date(dateStr).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function StravaRuns() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [runs, setRuns] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadRuns = useCallback(async () => {
    const token = localStorage.getItem('strava_access_token');
    if (!token) {
      setError('Not connected to Strava');
      setLoading(false);
      return;
    }
    try {
      const res = await base44.functions.invoke('stravaIntegration', {
        action: 'getActivities',
        accessToken: token,
      });
      // The function refreshes the access token when it expired — persist it so
      // the next page load doesn't send a stale token again.
      if (res.data?.accessToken) {
        localStorage.setItem('strava_access_token', res.data.accessToken);
        if (res.data.expiresAt) localStorage.setItem('strava_expires_at', String(res.data.expiresAt));
      }
      setRuns(res.data?.runs || []);
      setError(null);
    } catch {
      setError('Failed to load activities. Try reconnecting Strava.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadRuns();
  }, [loadRuns]);

  if (loading) {
    return (
      <div className="p-4 sm:p-6 md:p-10 max-w-4xl mx-auto">
        <div className="flex items-center justify-center min-h-[40vh]">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
        </div>
      </div>
    );
  }

  return (
    <PullToRefresh enabled={pathname === '/strava-runs'} onRefresh={loadRuns}>
    <div className="p-4 sm:p-6 md:p-10 max-w-4xl mx-auto">
      <PageHeader onBack={() => navigate(-1)} />

      <div className="mb-8">
        <h1 className="font-heading font-bold text-2xl md:text-3xl mb-2">My Strava Runs</h1>
        <p className="text-muted-foreground">See your completed runs and plan a playlist for any route.</p>
      </div>

      {error && (
        <Card>
          <CardContent className="py-10 text-center text-muted-foreground">
            <Activity className="w-10 h-10 mx-auto mb-3 text-orange-300" />
            {error === 'Not connected to Strava' ? (
              <>
                <p className="mb-1 font-medium text-foreground">Connect Strava to see your runs</p>
                <p className="text-sm">Link your Strava account and your runs appear here, ready for new playlists.</p>
                <Link to="/">
                  <Button className="mt-4 bg-orange-600 hover:bg-orange-700 rounded-xl">Connect Strava</Button>
                </Link>
              </>
            ) : (
              <>
                <p>{error}</p>
                <Button variant="outline" className="mt-4" onClick={loadRuns}>Try again</Button>
              </>
            )}
          </CardContent>
        </Card>
      )}

      {runs && runs.length === 0 && (
        <Card>
          <CardContent className="py-10 text-center text-muted-foreground">
            <Activity className="w-10 h-10 mx-auto mb-3 text-orange-300" />
            <p className="mb-1">No runs in your Strava account yet.</p>
            <p className="text-sm">Record a run with Strava and it'll show up here, ready for a fresh playlist.</p>
          </CardContent>
        </Card>
      )}

      {runs && runs.length > 0 && (
        <div className="space-y-3">
          {runs.map((run, i) => (
            <motion.div key={run.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="hover:border-orange-300 dark:hover:border-orange-700 transition-all">
                <CardContent className="p-4 sm:p-5">
                  <h3 className="font-heading font-semibold text-base sm:text-lg truncate">{run.name}</h3>
                  <p className="text-xs text-muted-foreground mb-3">{formatDate(run.startDate)}</p>
                  <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm mb-4">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                      <span className="font-medium">{(run.distance / 1000).toFixed(2)} km</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                      <span className="font-medium">{formatDuration(run.movingTime)}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <TrendingUp className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                      <span className="font-medium">{formatPace(run.averageSpeed)} /km</span>
                    </div>
                    {run.totalElevationGain > 0 && (
                      <div className="flex items-center gap-1.5">
                        <Mountain className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                        <span className="font-medium">{Math.round(run.totalElevationGain)}m</span>
                      </div>
                    )}
                  </div>
                  <Link to={`/strava-runs/${run.id}`}>
                    <Button className="bg-orange-600 hover:bg-orange-700 rounded-xl w-full sm:w-auto">
                      <Repeat className="w-3.5 h-3.5 mr-1.5" />
                      Run Again
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
    </PullToRefresh>
  );
}