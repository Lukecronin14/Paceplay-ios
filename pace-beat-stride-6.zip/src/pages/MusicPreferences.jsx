import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Music, Plus, X, Save, Loader2, Headphones, CheckCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import ResponsiveSelect from '@/components/common/ResponsiveSelect';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import PageHeader from '@/components/common/PageHeader';
import PullToRefresh from '@/components/common/PullToRefresh';
import DeleteAccountPanel from '@/components/account/DeleteAccountPanel';
import { APPLE_MUSIC_PROFILE_CACHE_KEY } from '@/lib/appleMusicData';

const GENRE_OPTIONS = [
  'Pop', 'Rock', 'Electronic', 'Hip-Hop', 'R&B', 'Dance', 'Indie',
  'Metal', 'Punk', 'Drum & Bass', 'House', 'Techno', 'Reggaeton',
  'Country', 'Latin', 'Classical', 'Jazz', 'Soul', 'Funk', 'Disco'
];

export default function MusicPreferences() {
  const queryClient = useQueryClient();
  const { pathname } = useLocation();
  const [genres, setGenres] = useState([]);
  const [excludeGenres, setExcludeGenres] = useState([]);
  const [artists, setArtists] = useState([]);
  const [artistInput, setArtistInput] = useState('');
  const [energy, setEnergy] = useState('high');
  const [bpmRange, setBpmRange] = useState([140, 180]);
  const [existingId, setExistingId] = useState(null);

  const spotifyProfile = (() => {
    try {
      const cached = localStorage.getItem('spotify_profile_cache');
      return cached ? JSON.parse(cached) : null;
    } catch { return null; }
  })();

  const appleProfile = (() => {
    try {
      return JSON.parse(localStorage.getItem(APPLE_MUSIC_PROFILE_CACHE_KEY) || 'null');
    } catch { return null; }
  })();
  const appleArtists = appleProfile?.topArtists || [];

  const spotifyArtists = spotifyProfile?.topArtists?.map(a => a.name) || [];
  const spotifyGenres = [...new Set(spotifyProfile?.topArtists?.flatMap(a => a.genres || []) || [])].slice(0, 6);

  const { data: prefs = [], isLoading } = useQuery({
    queryKey: ['musicPrefs'],
    queryFn: () => base44.entities.MusicPreference.list('-created_date', 1),
    initialData: [],
  });

  useEffect(() => {
    if (prefs.length > 0) {
      const p = prefs[0];
      setExistingId(p.id);
      setGenres(p.favorite_genres || []);
      setExcludeGenres(p.exclude_genres || []);
      setArtists(p.favorite_artists || []);
      setEnergy(p.energy_preference || 'high');
      setBpmRange([p.bpm_range_min || 140, p.bpm_range_max || 180]);
    }
  }, [prefs]);

  const [refreshing, setRefreshing] = useState(false);
  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await queryClient.invalidateQueries({ queryKey: ['musicPrefs'] });
      toast.success('Preferences reloaded');
    } finally {
      setRefreshing(false);
    }
  };

  const saveMutation = useMutation({
    mutationFn: (data) => {
      if (existingId) {
        return base44.entities.MusicPreference.update(existingId, data);
      }
      return base44.entities.MusicPreference.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['musicPrefs'] });
      toast.success('Music preferences saved!');
    },
  });

  const handleSave = () => {
    saveMutation.mutate({
      favorite_genres: genres,
      favorite_artists: artists,
      energy_preference: energy,
      bpm_range_min: bpmRange[0],
      bpm_range_max: bpmRange[1],
      exclude_genres: excludeGenres,
    });
  };

  const addArtist = () => {
    if (artistInput.trim() && !artists.includes(artistInput.trim())) {
      setArtists([...artists, artistInput.trim()]);
      setArtistInput('');
    }
  };

  const toggleGenre = (genre, list, setList) => {
    if (list.includes(genre)) {
      setList(list.filter(g => g !== genre));
    } else {
      setList([...list, genre]);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh
      enabled={pathname === '/preferences'}
      onRefresh={() => queryClient.invalidateQueries({ queryKey: ['musicPrefs'] })}
    >
    <div className="p-4 sm:p-6 md:p-10 max-w-3xl mx-auto">
      <PageHeader title="Music Preferences" />
      <div className="mb-8 flex items-center justify-between gap-3">
        <p className="text-muted-foreground">Tell us what you love and we'll match songs to your runs</p>
        <Button
          variant="ghost"
          size="icon"
          onClick={handleRefresh}
          disabled={refreshing}
          aria-label="Refresh preferences"
          title="Refresh preferences"
        >
          <RefreshCw className={refreshing ? 'animate-spin' : ''} />
        </Button>
      </div>

      {spotifyProfile && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 rounded-xl border border-[#1DB954]/30 bg-[#1DB954]/5 p-4 flex flex-col sm:flex-row sm:items-start gap-3"
        >
          <div className="flex items-start gap-3 w-full">
            <div className="w-8 h-8 rounded-full bg-[#1DB954] flex items-center justify-center shrink-0 mt-0.5">
              <CheckCircle className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-[#1DB954]">Spotify Connected — {spotifyProfile.name}</p>
              <p className="text-sm text-muted-foreground mt-0.5">
                Your listening data is already being used when generating playlists.
                {spotifyArtists.length > 0 && ' You can also import your top artists below.'}
              </p>
              {(spotifyArtists.length > 0 || spotifyGenres.length > 0) && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {spotifyGenres.map(g => (
                    <span key={g} className="text-xs bg-[#1DB954]/10 text-[#1DB954] px-2 py-0.5 rounded-full capitalize">{g}</span>
                  ))}
                </div>
              )}
            </div>
          </div>
          {spotifyArtists.length > 0 && (
            <Button
              size="sm"
              variant="outline"
              className="shrink-0 border-[#1DB954]/30 text-[#1DB954] hover:bg-[#1DB954]/10 text-sm w-full sm:w-auto mt-1"
              onClick={() => {
                const toAdd = spotifyArtists.filter(a => !artists.includes(a));
                if (toAdd.length > 0) {
                  setArtists([...artists, ...toAdd]);
                  toast.success(`Imported ${toAdd.length} artists from Spotify`);
                } else {
                  toast.info('All your Spotify artists are already added');
                }
              }}
            >
              Import Artists
            </Button>
          )}
        </motion.div>
      )}

      {appleProfile && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/50 p-4 flex flex-col sm:flex-row sm:items-start gap-3"
        >
          <div className="flex items-start gap-3 w-full">
            <div className="w-8 h-8 rounded-full bg-rose-600 flex items-center justify-center shrink-0 mt-0.5">
              <CheckCircle className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-rose-700 dark:text-rose-300">Apple Music Connected</p>
              <p className="text-sm text-muted-foreground mt-0.5">
                Your Apple Music listening data is used when generating playlists.
                {appleArtists.length > 0 && ' You can also import your top artists below.'}
              </p>
            </div>
          </div>
          {appleArtists.length > 0 && (
            <Button
              size="sm"
              variant="outline"
              className="shrink-0 border-rose-300 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900 text-sm w-full sm:w-auto mt-1"
              onClick={() => {
                const toAdd = appleArtists.filter(a => !artists.includes(a));
                if (toAdd.length > 0) {
                  setArtists([...artists, ...toAdd]);
                  toast.success(`Imported ${toAdd.length} artists from Apple Music`);
                } else {
                  toast.info('All your Apple Music artists are already added');
                }
              }}
            >
              Import Artists
            </Button>
          )}
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        {/* Favorite Genres */}
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-lg flex items-center gap-2">
              <Music className="w-5 h-5 text-primary" />
              Favorite Genres
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {GENRE_OPTIONS.map(genre => (
                <button
                  key={genre}
                  onClick={() => toggleGenre(genre, genres, setGenres)}
                  className={`px-3 py-2.5 min-h-11 min-w-11 rounded-full text-sm font-medium transition-all border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring
                    ${genres.includes(genre)
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'bg-card text-muted-foreground border-border hover:border-primary/30'
                    }`}
                >
                  {genre}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Exclude Genres */}
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-lg text-destructive">Genres to Exclude</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {GENRE_OPTIONS.filter(g => !genres.includes(g)).map(genre => (
                <button
                  key={genre}
                  onClick={() => toggleGenre(genre, excludeGenres, setExcludeGenres)}
                  className={`px-3 py-2.5 min-h-11 min-w-11 rounded-full text-sm font-medium transition-all border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring
                    ${excludeGenres.includes(genre)
                      ? 'bg-destructive text-destructive-foreground border-destructive'
                      : 'bg-card text-muted-foreground border-border hover:border-destructive/30'
                    }`}
                >
                  {genre}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Favorite Artists */}
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-lg flex items-center gap-2">
              <Headphones className="w-5 h-5 text-accent" />
              Favorite Artists
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 mb-3">
              <Input
                value={artistInput}
                onChange={(e) => setArtistInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addArtist()}
                placeholder="Add an artist..."
                className="rounded-xl"
              />
              <Button onClick={addArtist} variant="outline" className="rounded-xl shrink-0">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {artists.map(artist => (
                <Badge key={artist} variant="secondary" className="px-3 py-1.5 text-sm">
                  {artist}
                  <button onClick={() => setArtists(artists.filter(a => a !== artist))} className="ml-2 inline-flex items-center justify-center min-h-11 min-w-11 rounded-full hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                    <X className="w-5 h-5" />
                  </button>
                </Badge>
              ))}
              {artists.length === 0 && (
                <p className="text-sm text-muted-foreground">No artists added yet</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Energy & BPM */}
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-lg">Energy & BPM Range</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="text-sm font-medium mb-3 block">Running Energy Level</Label>
              <ResponsiveSelect
                value={energy}
                onChange={setEnergy}
                placeholder="Select energy level"
                title="Running Energy Level"
                className="rounded-xl w-full sm:w-48"
                options={[
                  { value: 'low', label: 'Low — Chill runs' },
                  { value: 'medium', label: 'Medium — Steady' },
                  { value: 'high', label: 'High — Push it' },
                  { value: 'very_high', label: 'Very High — Beast mode' },
                ]}
              />
            </div>
            <div>
              <Label className="text-sm font-medium mb-3 block">
                BPM Range: <span className="font-mono text-primary">{bpmRange[0]} – {bpmRange[1]}</span>
              </Label>
              <Slider
                value={bpmRange}
                onValueChange={setBpmRange}
                min={100}
                max={210}
                step={5}
                className="mt-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>100 BPM (Walking)</span>
                <span>210 BPM (Sprint)</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Button
          size="lg"
          onClick={handleSave}
          disabled={saveMutation.isPending}
          className="w-full rounded-xl font-semibold"
        >
          {saveMutation.isPending ? (
            <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
          ) : (
            <><Save className="w-4 h-4 mr-2" /> Save Preferences</>
          )}
        </Button>
      </motion.div>

      <div className="mt-8">
        <DeleteAccountPanel />
      </div>
    </div>
    </PullToRefresh>
  );
}