import React from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useSubscription } from '@/hooks/useSubscription';
import PageHeader from '@/components/common/PageHeader';
import { History, ListMusic, Music, ChevronRight, LogOut, User as UserIcon, Crown } from 'lucide-react';

const links = [
  { to: '/run-history', icon: History, label: 'Run History', desc: 'All your past runs and plans' },
  { to: '/my-plans', icon: ListMusic, label: 'My Plans', desc: 'Playlists generated for your parkruns' },
  { to: '/preferences', icon: Music, label: 'Music Preferences', desc: 'Playlists, artists and BPM range' },
];

export default function Account() {
  const { user } = useAuth();
  const { subscription, hasAccess, isLoading: subLoading } = useSubscription();

  const statusLabel = hasAccess
    ? subscription?.status === 'active' ? 'Active'
      : subscription?.status === 'pending' ? 'Pending'
        : subscription?.status === 'free' ? 'Free plan'
          : 'Trial'
    : 'No subscription';

  const signOut = () => base44.auth.logout('/');

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 md:px-10">
      <PageHeader title="My Account" logo />

      {/* Profile */}
      <div className="flex items-center gap-4 mt-6">
        <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
          <UserIcon className="w-6 h-6 text-primary" />
        </div>
        <div className="min-w-0">
          <p className="font-heading font-bold text-lg truncate">{user?.full_name || 'Runner'}</p>
          <p className="text-sm text-muted-foreground truncate">{user?.email}</p>
        </div>
      </div>

      {/* Subscription */}
      <Link
        to="/subscribe"
        className="mt-6 flex items-center gap-3 rounded-xl border bg-card p-4 hover:bg-muted/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
          <Crown className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold">Subscription</p>
          <p className="text-xs text-muted-foreground">
            {subLoading ? 'Checking…' : `${statusLabel} · tap to manage`}
          </p>
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
      </Link>

      {/* Sections */}
      <div className="mt-6 rounded-xl border bg-card divide-y divide-border">
        {links.map(({ to, icon: Icon, label, desc }) => (
          <Link
            key={to}
            to={to}
            className="flex items-center gap-3 p-4 min-h-11 hover:bg-muted/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring"
          >
            <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
              <Icon className="w-4 h-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{label}</p>
              <p className="text-xs text-muted-foreground truncate">{desc}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
          </Link>
        ))}
      </div>

      {/* Sign out */}
      <button
        type="button"
        onClick={signOut}
        className="mt-6 w-full flex items-center justify-center gap-2 h-11 rounded-xl border border-destructive/30 text-destructive text-sm font-medium hover:bg-destructive/5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <LogOut className="w-4 h-4" /> Sign out
      </button>
    </div>
  );
}