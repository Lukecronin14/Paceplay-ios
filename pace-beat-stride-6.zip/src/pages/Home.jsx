import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Map, ArrowRight, Activity, Headphones, CheckCircle2, AlertCircle, Users, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import PageHeader from '@/components/common/PageHeader';
import PullToRefresh from '@/components/common/PullToRefresh';
import MusicServiceSection from '@/components/integrations/MusicServiceSection';
import SetupPromptCard from '@/components/onboarding/SetupPromptCard';
import StravaConnect from '@/components/integrations/StravaConnect';
import { isAnyMusicConnected } from '@/lib/musicService';
import { useAuth } from '@/lib/AuthContext';
import { useSubscription } from '@/hooks/useSubscription';
import { useUnfinishedRun } from '@/hooks/useUnfinishedRun';
import UnfinishedRunPrompt from '@/components/live/UnfinishedRunPrompt';

export default function Home() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const queryClient = useQueryClient();
  const { user, checkUserAuth } = useAuth();
  const { hasAccess, isLoading: subLoading } = useSubscription();
  // Batch B3: shared unfinished-run detection (same query as Live setup).
  const { unfinishedRun } = useUnfinishedRun();
  const [musicConnected, setMusicConnected] = useState(() => isAnyMusicConnected());
  const [stravaConnected, setStravaConnected] = useState(() => !!localStorage.getItem('strava_access_token'));

  const bothConnected = musicConnected && stravaConnected;
  const [setupDismissed, setSetupDismissed] = useState(false);
  const showSetupPrompt = !setupDismissed && !user?.onboarding_completed_at;

  const [refreshing, setRefreshing] = useState(false);
  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await queryClient.invalidateQueries({ queryKey: ['runPlans'] });
      toast.success('Plans up to date');
    } finally {
      setRefreshing(false);
    }
  };

  const dismissSetup = async () => {
    setSetupDismissed(true);
    try {
      await base44.auth.updateMe({ onboarding_completed_at: new Date().toISOString() });
      // Refresh the in-session user so the prompt stays dismissed this session
      await checkUserAuth();
    } catch (err) {
      console.error('Failed to save setup dismissal:', err);
    }
  };

  const { data: plans = [] } = useQuery({
    queryKey: ['runPlans'],
    queryFn: () => base44.entities.RunPlan.list('-created_date', 5),
    initialData: [],
  });

  // Listen for storage changes (e.g. after OAuth callback closes popup)
  useEffect(() => {
    const checkConnections = () => {
      setMusicConnected(isAnyMusicConnected());
      setStravaConnected(!!localStorage.getItem('strava_access_token'));
    };
    window.addEventListener('storage', checkConnections);
    return () => window.removeEventListener('storage', checkConnections);
  }, []);

  // Push users without an active subscription to the subscribe page (once per
  // session) — admins skip this.
  useEffect(() => {
    if (!user || user.role === 'admin' || subLoading || hasAccess) return;
    if (sessionStorage.getItem('paceplay_subscribe_shown')) return;
    sessionStorage.setItem('paceplay_subscribe_shown', '1');
    navigate('/subscribe');
  }, [user, subLoading, hasAccess, navigate]);

  const choices = [
    {
      title: 'Parkrun Routes',
      desc: 'Browse UK parkrun courses with terrain profiles. Set your target time and get a BPM-matched playlist for every kilometre.',
      icon: Map,
      color: 'primary',
      route: '/parkruns',
      cta: 'Browse Parkruns',
      requires: 'none',
    },
    {
      title: 'Strava Routes',
      desc: 'Replay your previous Strava runs with a fresh, terrain-adaptive playlist. AI matches songs to your actual splits and elevation data.',
      icon: Activity,
      color: 'orange',
      route: '/strava-runs',
      cta: 'View My Strava Runs',
      requires: 'strava',
      locked: !stravaConnected,
    },
    {
      title: 'Live Run',
      desc: 'Free-form run with real-time GPS pace tracking. AI generates a track pool and the right song plays automatically based on your pace.',
      icon: Headphones,
      color: 'accent',
      route: '/live-run',
      cta: 'Start Live Run',
      requires: 'none',
    },

  ];

  return (
    <PullToRefresh
      enabled={pathname === '/'}
      onRefresh={() => queryClient.invalidateQueries({ queryKey: ['runPlans'] })}
    >
    <div className="p-4 sm:p-6 md:p-10 max-w-4xl mx-auto">
      <PageHeader title="PacePlay" logo />
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-accent p-6 sm:p-8 md:p-12 text-white mb-6 sm:mb-8"
      >
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=1200&q=80')] bg-cover bg-center opacity-15" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-4">
            <Headphones className="w-5 h-5" />
            <span className="text-sm font-medium opacity-90">AI-Powered Running Playlists</span>
          </div>
          <h1 className="font-heading text-3xl md:text-5xl font-bold mb-3 leading-tight">
            Run to Your<br />Rhythm
          </h1>
          <p className="text-lg opacity-90 mb-6 max-w-md">
            Connect your music and run data, then pick a route — we'll build a BPM-matched playlist that adapts to every kilometre.
          </p>
          {bothConnected && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white/15 backdrop-blur-sm rounded-full text-sm font-medium"
            >
              <CheckCircle2 className="w-4 h-4" />
              All set — choose your route below
            </motion.div>
          )}
        </div>
      </motion.div>

      {showSetupPrompt && (
        <SetupPromptCard onStart={() => navigate('/onboarding')} onDismiss={dismissSetup} />
      )}

      {/* Batch B3: entry-point detection of an unfinished run — shared hook, so
          Home and Live setup always surface the same run. */}
      {unfinishedRun && (
        <UnfinishedRunPrompt
          run={unfinishedRun}
          onResolved={() => queryClient.invalidateQueries({ queryKey: ['unfinishedRun'] })}
        />
      )}

      {user?.role === 'admin' && (
        <Link to="/admin/users" className="block mb-6 sm:mb-8">
          <div className="bg-primary/10 border border-primary/20 rounded-xl p-4 flex items-center gap-3 hover:bg-primary/15 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-sm">Manage Users</p>
              <p className="text-sm text-muted-foreground">Invite runners and manage access</p>
            </div>
            <ArrowRight className="w-4 h-4 text-primary" />
          </div>
        </Link>
      )}

      {/* Integration step */}
      <div className="mb-6 sm:mb-8">
        <div className="flex items-center gap-2 mb-4">
          <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground font-heading font-bold text-sm flex items-center justify-center">1</span>
          <h2 className="font-heading font-bold text-lg sm:text-xl">Connect Your Accounts</h2>
        </div>

        {!bothConnected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-start gap-3 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-xl p-4 mb-4"
          >
            <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="text-sm text-amber-800 dark:text-amber-300">
              <p className="font-medium mb-0.5">Get the most out of PacePlay</p>
              <p className="text-amber-700 dark:text-amber-400">Connect a music service (Spotify or Apple Music) and Strava for fully personalised, terrain-aware playlists. Your music brings your taste; Strava brings your run history and terrain data.</p>
            </div>
          </motion.div>
        )}

        <div className="space-y-4">
          <MusicServiceSection onConnectionsChange={setMusicConnected} />
          <StravaConnect />
        </div>
      </div>

      {/* Three choices */}
      <div className="mb-6 sm:mb-8">
        <div className="flex items-center gap-2 mb-4">
          <span className={`w-7 h-7 rounded-full font-heading font-bold text-sm flex items-center justify-center transition-colors ${bothConnected ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>2</span>
          <h2 className="font-heading font-bold text-lg sm:text-xl">Choose Your Route</h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {choices.map((choice, i) => {
            const Icon = choice.icon;
            const isLocked = choice.locked;
            return (
              <motion.div
                key={choice.title}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.08 }}
              >
                <Card
                  className={`h-full border-border group hover:shadow-lg hover:shadow-primary/5 transition-all cursor-pointer relative overflow-hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${isLocked ? 'opacity-60' : 'hover:border-primary/30'}`}
                  role="button"
                  tabIndex={isLocked ? -1 : 0}
                  aria-label={choice.title}
                  onClick={() => !isLocked && navigate(choice.route)}
                  onKeyDown={(e) => {
                    if (isLocked) return;
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      navigate(choice.route);
                    }
                  }}
                >
                  <CardContent className="p-5 sm:p-6 flex flex-col h-full">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${
                      choice.color === 'primary' ? 'bg-primary/10 text-primary' :
                      choice.color === 'accent' ? 'bg-accent/10 text-accent' :
                      'bg-orange-100 text-orange-600 dark:bg-orange-900 dark:text-orange-400'
                    }`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-heading font-semibold mb-2">{choice.title}</h3>
                    <p className="text-sm text-muted-foreground flex-1 mb-4">{choice.desc}</p>
                    <div className="flex items-center justify-between">
                      {isLocked ? (
                        <span className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                          <AlertCircle className="w-3.5 h-3.5" />
                          Connect Strava first
                        </span>
                      ) : (
                        <span className="text-sm font-medium text-primary flex items-center gap-1 group-hover:gap-2 transition-all">
                          {choice.cta} <ArrowRight className="w-3.5 h-3.5" />
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Recent plans */}
      {plans.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-heading font-bold text-xl">Recent Plans</h2>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleRefresh}
                disabled={refreshing}
                aria-label="Refresh plans"
                title="Refresh plans"
              >
                <RefreshCw className={refreshing ? 'animate-spin' : ''} />
              </Button>
              <Link to="/my-plans" className="text-sm text-primary flex items-center gap-1 hover:underline h-11 px-2">
                View all <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
          <div className="space-y-3">
            {plans.slice(0, 3).map((plan) => (
              <Link key={plan.id} to={`/my-plans/${plan.id}`} className="block">
                <div className="bg-card rounded-xl border border-border p-4 hover:border-primary/30 transition-all flex items-center justify-between">
                  <div>
                    <p className="font-medium">{plan.parkrun_name}</p>
                    <p className="text-sm text-muted-foreground">Target: {plan.target_time_min} min • {plan.playlist?.length || 0} tracks</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      <p className="text-center text-xs text-muted-foreground mt-8 space-x-2">
        <Link to="/privacy" className="underline">Privacy Policy</Link>
        <span>·</span>
        <Link to="/terms" className="underline">Terms of Service</Link>
      </p>
    </div>
    </PullToRefresh>
  );
}