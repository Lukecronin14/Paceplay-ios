import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link, useLocation } from 'react-router-dom';
import { ListMusic, Music, ArrowRight, Timer, Trash2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import PageHeader from '@/components/common/PageHeader';
import PullToRefresh from '@/components/common/PullToRefresh';

export default function MyPlans() {
  const queryClient = useQueryClient();
  const { pathname } = useLocation();

  const { data: plans = [], isLoading, isError } = useQuery({
    queryKey: ['runPlans'],
    queryFn: () => base44.entities.RunPlan.list('-created_date', 50),
    initialData: [],
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RunPlan.delete(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ['runPlans'] });
      const previous = queryClient.getQueryData(['runPlans']);
      queryClient.setQueryData(['runPlans'], (old) => (old || []).filter((p) => p.id !== id));
      return { previous };
    },
    onError: (_err, _id, context) => {
      if (context?.previous) queryClient.setQueryData(['runPlans'], context.previous);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['runPlans'] }),
  });

  return (
    <PullToRefresh
      enabled={pathname === '/my-plans'}
      onRefresh={() => queryClient.invalidateQueries({ queryKey: ['runPlans'] })}
    >
    <div className="p-4 sm:p-6 md:p-10 max-w-4xl mx-auto">
      <PageHeader title="My Run Plans" />
      <div className="mb-8">
        <p className="text-muted-foreground">Your generated playlists and pace strategies</p>
      </div>

      {isError ? (
        <div className="text-center py-20">
          <AlertCircle className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-muted-foreground mb-1">Couldn't load your plans.</p>
          <p className="text-sm text-muted-foreground">Check your connection and pull down to try again.</p>
        </div>
      ) : isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
        </div>
      ) : plans.length === 0 ? (
        <div className="text-center py-20">
          <ListMusic className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-muted-foreground mb-4">No plans yet. Pick a parkrun to get started!</p>
          <Link to="/parkruns">
            <Button className="rounded-xl">Browse Parkruns</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <div className="bg-card rounded-2xl border border-border p-4 sm:p-5 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all group">
                <div className="flex items-center justify-between gap-2">
                  <Link to={`/my-plans/${plan.id}`} className="flex-1 min-w-0">
                    <h3 className="font-heading font-semibold group-hover:text-primary transition-colors">
                      {plan.parkrun_name}
                    </h3>
                    <div className="flex items-center gap-3 mt-2 flex-wrap">
                      <Badge variant="outline" className="text-xs">
                        <Timer className="w-3 h-3 mr-1" />
                        {plan.target_time_min} min target
                      </Badge>
                      <Badge className="bg-primary/10 text-primary text-xs">
                        <Music className="w-3 h-3 mr-1" />
                        {plan.playlist?.length || 0} tracks
                      </Badge>
                      <Badge variant="secondary" className="text-xs capitalize">
                        {plan.status}
                      </Badge>
                    </div>
                  </Link>
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      aria-label="Delete run plan"
                      className="text-muted-foreground hover:text-destructive"
                      onClick={() => deleteMutation.mutate(plan.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <Link to={`/my-plans/${plan.id}`}>
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </Link>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
    </PullToRefresh>
  );
}