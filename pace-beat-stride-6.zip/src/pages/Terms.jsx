import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Terms() {
  const navigate = useNavigate();

  useEffect(() => {
    document.title = 'Terms of Service | TempoRun';
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur px-4 sm:px-6 py-3 border-b border-border" style={{ top: 'env(safe-area-inset-top)' }}>
        <button
          type="button"
          onClick={() => navigate(-1)}
          aria-label="Go back"
          className="w-11 h-11 flex items-center justify-center rounded-lg hover:bg-muted/60 active:scale-95 transition-colors"
        >
          ←
        </button>
      </div>
      <article className="max-w-2xl mx-auto px-4 sm:px-6 py-8 prose select-text">
        <h1 className="font-heading font-bold text-2xl mb-6">Terms of Service</h1>
        <p className="text-sm text-muted-foreground">Last updated: 13 October 2026</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">1. The service</h2>
        <p className="text-sm">TempoRun maps UK parkrun courses and generates cadence-matched running playlists from your music history and run data. The core app is subscription-based; promo trials may be available from time to time.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">2. Subscription and billing</h2>
        <p className="text-sm">The subscription is billed at £2.00 per month and renews automatically until cancelled. Payments are processed through our secure checkout provider; we do not store your card details. You can cancel at any time; access continues until the end of the period you have paid for. If you subscribed through the website in a browser, billing is managed there and your premium access applies to this app automatically on your account.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">3. Health and safety</h2>
        <p className="text-sm">This app is a fitness aid, not medical advice. Consult a doctor before starting any exercise programme. Always run safely, follow local laws, and stay aware of your surroundings while tracking a run or listening to music.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">4. Connected accounts</h2>
        <p className="text-sm">Features that use Spotify, Apple Music or Strava require you to connect the corresponding account. You grant only the permissions shown when connecting, and you can disconnect at any time. Your use of those services remains subject to their own terms.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">5. Your content and data</h2>
        <p className="text-sm">You keep ownership of your playlists, preferences, routes and run history. You grant us the limited licence needed to store and process this data to provide the service, as described in our <a href="/privacy" className="underline">Privacy Policy</a>.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">6. Account termination</h2>
        <p className="text-sm">You may delete your account from within the app, which removes your account and associated data. We may suspend accounts that abuse the service or violate these terms.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">7. Changes</h2>
        <p className="text-sm">We may update these terms; continued use of the app after an update means you accept the revised terms. Material changes to billing will be communicated before they take effect.</p>

        <p className="text-xs text-muted-foreground mt-10">
          <a href="/privacy" className="underline">Privacy Policy</a>
        </p>
      </article>
    </div>
  );
}