import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, Activity, CheckCircle } from 'lucide-react';
import { saveStravaIntegration } from '@/lib/integrationStorage';

export default function StravaCallback() {
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const error = params.get('error');

    const finish = (delay = 1500) => {
      setTimeout(() => {
        if (!window.opener) {
          window.location.href = '/';
        } else {
          window.close();
        }
      }, delay);
    };

    if (error || !code) {
      setStatus('error');
      finish(2000);
      return;
    }

    base44.functions.invoke('stravaIntegration', {
      action: 'exchangeToken',
      code,
      redirectUri: `${window.location.origin}/strava-callback`,
    }).then(async res => {
      if (res.data?.accessToken) {
        localStorage.setItem('strava_access_token', res.data.accessToken);
        localStorage.removeItem('strava_refresh_token'); // kept server-side only
        if (res.data.expiresAt) localStorage.setItem('strava_expires_at', String(res.data.expiresAt));
        try { await saveStravaIntegration(res.data.accessToken); } catch {}
        setStatus('success');
      } else {
        setStatus('error');
      }
      finish(1500);
    }).catch(() => {
      setStatus('error');
      finish(2000);
    });
  }, []);

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-background">
      <div className="text-center">
        {status === 'loading' && (
          <>
            <Loader2 className="w-8 h-8 animate-spin text-orange-500 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Connecting to Strava...</p>
          </>
        )}
        {status === 'success' && (
          <>
            <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Connected! Closing...</p>
          </>
        )}
        {status === 'error' && (
          <>
            <Activity className="w-8 h-8 text-red-500 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Failed to connect. Closing...</p>
          </>
        )}
      </div>
    </div>
  );
}