import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Music } from 'lucide-react';
import { saveSpotifyIntegration } from '@/lib/integrationStorage';

export default function SpotifyCallback() {
  const [status, setStatus] = useState('Processing...');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const error = params.get('error');

    const finish = (delay = 1500) => {
      setTimeout(() => {
        if (!window.opener) {
          window.location.href = '/';
        } else {
          window.close();
        }
      }, delay);
    };

    if (error) {
      setStatus('Spotify login was cancelled or failed.');
      finish(2000);
      return;
    }

    if (!code) {
      setStatus('No authorisation code received.');
      finish(2000);
      return;
    }

    const exchangeToken = async () => {
      try {
        setStatus('Connecting to Spotify...');
        const response = await base44.functions.invoke('spotifyIntegration', {
          action: 'getAccessToken',
          code,
          redirectUri: `${window.location.origin}/spotify-callback`
        });

        localStorage.setItem('spotify_access_token', response.data.accessToken);
        localStorage.setItem('spotify_expires_at', String(Date.now() + (response.data.expiresIn || 3600) * 1000));
        setStatus('Fetching your profile...');

        try {
          const profileRes = await base44.functions.invoke('spotifyIntegration', {
            action: 'getProfile',
            accessToken: response.data.accessToken,
          });
          const profile = profileRes.data || null;
          if (profile) {
            localStorage.setItem('spotify_profile_cache', JSON.stringify(profile));
          }
          await saveSpotifyIntegration(response.data.accessToken, profile);
        } catch {}

        setStatus('Connected! Closing...');
        finish(1000);
      } catch (err) {
        setStatus('Failed to connect. Please try again.');
        finish(2000);
      }
    };

    exchangeToken();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-4">
        <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto">
          <Music className="w-6 h-6 text-green-600 dark:text-green-400" />
        </div>
        <p className="text-lg font-medium">{status}</p>
      </div>
    </div>
  );
}