import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Privacy() {
  const navigate = useNavigate();

  useEffect(() => {
    document.title = 'Privacy Policy | TempoRun';
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur px-4 sm:px-6 py-3 border-b border-border" style={{ top: 'env(safe-area-inset-top)' }}>
        <button
          type="button"
          onClick={() => navigate(-1)}
          aria-label="Go back"
          className="w-11 h-11 flex items-center justify-center rounded-lg hover:bg-muted/60 active:scale-95 transition-colors"
        >
          ←
        </button>
      </div>
      <article className="max-w-2xl mx-auto px-4 sm:px-6 py-8 prose select-text">
        <h1 className="font-heading font-bold text-2xl mb-6">Privacy Policy</h1>
        <p className="text-sm text-muted-foreground">Last updated: 13 October 2026</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">What we collect</h2>
        <ul className="list-disc pl-5 space-y-2 text-sm">
          <li><strong>Account details:</strong> your name and email address when you register or accept an invite.</li>
          <li><strong>Location data:</strong> your GPS position is recorded only while you start a live run and give location permission. It is stored with your run record so you can review your route.</li>
          <li><strong>Health and fitness data:</strong> workouts, heart rate, cadence and routes from Strava are imported only after you explicitly connect the service and grant permission. Fitness data is stored only in connection with your imported workouts.</li>
          <li><strong>Music data:</strong> your music preferences and, when you connect Spotify or Apple Music, your playlists and listening history used to generate running playlists.</li>
          <li><strong>Connected service tokens:</strong> OAuth access tokens are kept in your browser for the session only; long-lived refresh tokens are stored securely on our servers and are never sent back to your browser.</li>
        </ul>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">How we use your data</h2>
        <p className="text-sm">Your data is used to operate the app: mapping parkrun courses, generating playlists matched to your pace and terrain, tracking live runs, and showing your run history. We do not sell your data, use it for advertising, or share it with third parties other than the services you connect (Spotify, Strava, Apple Music).</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">Health data</h2>
        <p className="text-sm">Health and fitness data is never used for advertising, sold, or shared with third parties. Apple Health access is strictly read-only: PacePlay reads your workouts (distance, pace, heart rate, route) and never writes to Apple Health. Any imported workouts remain stored privately in your account and are included when you delete your account and associated data.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">Location</h2>
        <p className="text-sm">Location is accessed only while a run is active. You can revoke location permission at any time in your device settings; live-run tracking requires it, but all other features work without it.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">Payments</h2>
        <p className="text-sm">Subscription payments are processed by our payment provider. We do not receive or store your full payment card details.</p>

        <h2 className="font-heading font-semibold text-lg mt-8 mb-2">Your choices</h2>
        <ul className="list-disc pl-5 space-y-2 text-sm">
          <li>You can disconnect any linked service (Spotify, Apple Music, Strava) from within the app.</li>
          <li>You can delete your account and all associated data from within the app, or by contacting support.</li>
        </ul>

        <p className="text-sm text-muted-foreground mt-10">If you have questions about this policy, contact support.</p>
        <p className="text-xs text-muted-foreground mt-6">
          <a href="/terms" className="underline">Terms of Service</a>
        </p>
      </article>
    </div>
  );
}