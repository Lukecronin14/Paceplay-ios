import React from 'react';
import { Link } from 'react-router-dom';
import { Map, Activity, ChevronRight } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';

const routeTypes = [
  {
    to: '/parkruns',
    icon: Map,
    label: 'Parkrun Routes',
    desc: 'Browse UK parkrun courses with terrain and elevation profiles',
  },
  {
    to: '/strava-runs',
    icon: Activity,
    label: 'Strava Routes',
    desc: 'Routes from your recorded Strava activities',
  },
];

export default function RoutesHub() {
  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 md:px-10">
      <PageHeader title="Routes" logo />

      <div className="mt-6 grid gap-3">
        {routeTypes.map(({ to, icon: Icon, label, desc }) => (
          <Link
            key={to}
            to={to}
            className="flex items-center gap-4 rounded-xl border bg-card p-5 hover:bg-muted/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Icon className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-heading font-semibold">{label}</p>
              <p className="text-sm text-muted-foreground">{desc}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
          </Link>
        ))}
      </div>
    </div>
  );
}