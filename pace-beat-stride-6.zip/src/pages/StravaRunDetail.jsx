import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Clock, MapPin, TrendingUp, Mountain, Loader2, Play, Music, Radio } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import StravaRouteMap from '@/components/strava/StravaRouteMap';
import PullToRefresh from '@/components/common/PullToRefresh';
import PageHeader from '@/components/common/PageHeader';
import GeneratingPlaylistProgress from '@/components/common/GeneratingPlaylistProgress';
import { getMusicTasteContext } from '@/lib/musicTaste';

function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function formatPace(speedMs) {
  if (!speedMs || speedMs <= 0) return '—';
  const paceSecPerKm = 1000 / speedMs;
  const min = Math.floor(paceSecPerKm / 60);
  const sec = Math.floor(paceSecPerKm % 60);
  return `${min}:${sec.toString().padStart(2, '0')}`;
}

export default function StravaRunDetail() {
  const navigate = useNavigate();
  const { id: activityId } = useParams();
  const [activity, setActivity] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [targetTime, setTargetTime] = useState(25);
  const [generating, setGenerating] = useState(false);

  const loadActivity = useCallback(async () => {
    const token = localStorage.getItem('strava_access_token');
    if (!token) {
      setError('Not connected to Strava');
      setLoading(false);
      return;
    }
    try {
      const res = await base44.functions.invoke('stravaIntegration', {
        action: 'getActivity',
        accessToken: token,
        activityId,
      });
      if (res.data?.id) {
        setActivity(res.data);
        setTargetTime(Math.max(5, Math.round(res.data.movingTime / 60)));
      } else {
        setError('Activity not found');
      }
    } catch {
      setError('Failed to load activity');
    } finally {
      setLoading(false);
    }
  }, [activityId]);

  useEffect(() => {
    loadActivity();
  }, [loadActivity]);

  const generatePlaylist = async () => {
    if (!activity) return;
    setGenerating(true);

    // Music taste from the user's preferred service (Spotify or Apple Music)
    const taste = await getMusicTasteContext();
    const prefs = taste.prefs;

    const distanceKm = activity.distance / 1000;
    const basePace = targetTime / distanceKm;

    let splitsContext = '';
    if (activity.splits && activity.splits.length > 0) {
      splitsContext = `
ACTUAL PER-KM SPLITS FROM PREVIOUS RUN:
${activity.splits.map((s, i) => {
  const grad = s.averageGrade || 0;
  let gradLabel = 'flat';
  if (grad > 3) gradLabel = 'steep uphill';
  else if (grad > 1) gradLabel = 'uphill';
  else if (grad > 0.3) gradLabel = 'slight uphill';
  else if (grad < -3) gradLabel = 'steep downhill';
  else if (grad < -1) gradLabel = 'downhill';
  else if (grad < -0.3) gradLabel = 'slight downhill';
  return `  - KM ${i + 1}: ${formatPace(s.averageSpeed)} /km, ${gradLabel} (${grad.toFixed(1)}% grade, ${s.elevationDifference > 0 ? '+' : ''}${Math.round(s.elevationDifference)}m elev)`;
}).join('\n')}

TERRAIN RULES:
- Uphill segments: Higher BPM (+5-10), heavy driving beats, high energy.
- Downhill segments: Lower BPM (-5), flowing/melodic tracks.
- Flat segments: Match base cadence BPM. Steady, rhythmic.`;
    }

    const prompt = `You are a running coach and music expert. Generate a terrain-adaptive, BPM-matched running playlist for this route that the runner wants to complete again.

Route: ${activity.name}
Distance: ${distanceKm.toFixed(2)} km
Previous time: ${formatDuration(activity.movingTime)}
Previous pace: ${formatPace(activity.averageSpeed)} /km
Total elevation gain: ${Math.round(activity.totalElevationGain || 0)}m
${splitsContext}

Target time for this attempt: ${targetTime} minutes
Base pace: ${basePace.toFixed(1)} min/km

User music preferences:
- Favorite genres: ${prefs.favorite_genres?.join(', ') || 'pop, rock, electronic, hip-hop'}
- Favorite artists: ${prefs.favorite_artists?.join(', ') || 'any popular artists'}
- Energy preference: ${prefs.energy_preference || 'high'}
- BPM range: ${prefs.bpm_range_min || 140}-${prefs.bpm_range_max || 180}
- Exclude: ${prefs.exclude_genres?.join(', ') || 'none'}
${taste.listeningContext}
${taste.runningPlaylistContext}

Generate a playlist covering the full ${distanceKm.toFixed(1)}km run. Use REAL, well-known songs.

CRITICAL DURATION REQUIREMENT: Total duration of ALL tracks MUST be between ${targetTime * 60} and ${(targetTime + 5) * 60} seconds (${targetTime} to ${targetTime + 5} minutes). Add extra tracks if needed. Make sure each track's duration_sec is realistic (180-240 seconds).`;

    const result = await base44.functions.invoke('generate-track-pool', {
      prompt,
      distance_km: distanceKm,
      response_json_schema: {
        type: "object",
        properties: {
          segment_paces: {
            type: "array",
            items: {
              type: "object",
              properties: {
                km: { type: "number" },
                pace_min_per_km: { type: "number" },
                target_bpm: { type: "number" },
                cadence: { type: "number" },
                gradient: { type: "string" }
              }
            }
          },
          playlist: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                artist: { type: "string" },
                bpm: { type: "number" },
                duration_sec: { type: "number" },
                segment_km: { type: "number" },
                energy: { type: "string" },
                genre: { type: "string" },
                terrain_reason: { type: "string" }
              }
            }
          }
        }
      }
    });

    const plan = await base44.entities.RunPlan.create({
      parkrun_id: `strava_${activity.id}`,
      parkrun_name: `${activity.name} (Strava)`,
      target_time_min: targetTime,
      target_pace_per_km: basePace,
      playlist: result.data?.playlist || [],
      segment_paces: result.data?.segment_paces || [],
      status: 'ready',
    });

    setGenerating(false);
    navigate(`/my-plans/${plan.id}`);
  };

  if (loading) {
    return (
      <div className="p-4 sm:p-6 md:p-10 max-w-3xl mx-auto">
        <div className="flex items-center justify-center min-h-[40vh]" >
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
        </div>
      </div>
    );
  }

  if (error || !activity) {
    return (
      <div className="p-4 sm:p-6 md:p-10 max-w-3xl mx-auto text-center">
        <p className="text-muted-foreground">{error || 'Activity not found'}</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate('/strava-runs')}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Runs
        </Button>
      </div>
    );
  }

  const distanceKm = activity.distance / 1000;
  const actualTimeMin = Math.round(activity.movingTime / 60);
  const timePresets = [
    Math.max(5, actualTimeMin - 5),
    Math.max(5, actualTimeMin - 2),
    actualTimeMin,
    actualTimeMin + 2,
    actualTimeMin + 5,
  ];

  return (
    <PullToRefresh onRefresh={loadActivity}>
    <div className="p-4 sm:p-6 md:p-10 max-w-3xl mx-auto">
      <PageHeader onBack={() => navigate('/strava-runs')} />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        {/* Header */}
        <div className="mb-6">
          <h1 className="font-heading font-bold text-2xl md:text-3xl mb-3">{activity.name}</h1>
          <div className="flex items-center gap-3 flex-wrap">
            <Badge variant="secondary" className="text-sm">
              <MapPin className="w-3.5 h-3.5 mr-1" />
              {distanceKm.toFixed(2)} km
            </Badge>
            <Badge variant="secondary" className="text-sm">
              <Clock className="w-3.5 h-3.5 mr-1" />
              {formatDuration(activity.movingTime)}
            </Badge>
            <Badge className="bg-orange-100 dark:bg-orange-900/60 text-orange-700 dark:text-orange-300 text-sm">
              <TrendingUp className="w-3.5 h-3.5 mr-1" />
              {formatPace(activity.averageSpeed)} /km
            </Badge>
            {activity.totalElevationGain > 0 && (
              <Badge variant="outline" className="text-sm">
                <Mountain className="w-3.5 h-3.5 mr-1" />
                {Math.round(activity.totalElevationGain)}m gain
              </Badge>
            )}
          </div>
        </div>

        {/* Route map */}
        <div className="mb-6">
          <StravaRouteMap polyline={activity.polyline} startLatlng={activity.startLatlng} />
        </div>

        {/* Per-km splits */}
        {activity.splits && activity.splits.length > 0 && (
          <Card className="mb-6">
            <CardHeader className="pb-3">
              <CardTitle className="font-heading text-lg">Per-Km Splits</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 text-muted-foreground">
                    <tr>
                      <th className="text-left px-4 py-2 font-medium">KM</th>
                      <th className="text-left px-4 py-2 font-medium">Pace</th>
                      <th className="text-left px-4 py-2 font-medium">Elevation</th>
                      <th className="text-left px-4 py-2 font-medium">Grade</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {activity.splits.map((s, i) => (
                      <tr key={i} className="hover:bg-muted/30">
                        <td className="px-4 py-2.5 font-medium">{i + 1}</td>
                        <td className="px-4 py-2.5 font-mono">{formatPace(s.averageSpeed)} /km</td>
                        <td className="px-4 py-2.5">{s.elevationDifference > 0 ? '+' : ''}{Math.round(s.elevationDifference)}m</td>
                        <td className="px-4 py-2.5">{(s.averageGrade || 0).toFixed(1)}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Plan playlist card */}
        <Card className="border-orange-200 dark:border-orange-800 bg-gradient-to-br from-card to-orange-5">
          <CardHeader>
            <CardTitle className="font-heading text-lg flex items-center gap-2">
              <Music className="w-5 h-5 text-orange-600 dark:text-orange-400" />
              Plan a Playlist for This Route
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <Label className="text-sm font-medium mb-2 block">Target Finish Time (minutes)</Label>
              <div className="flex items-center gap-4">
                <Input
                  type="number"
                  value={targetTime}
                  onChange={(e) => setTargetTime(Number(e.target.value))}
                  min={5}
                  max={240}
                  className="w-28 rounded-xl font-mono text-lg font-bold"
                />
                <div className="text-sm text-muted-foreground">
                  <span className="font-mono font-medium text-foreground">{(targetTime / distanceKm).toFixed(1)}</span> min/km pace
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {timePresets.map(t => (
                <button
                  key={t}
                  onClick={() => setTargetTime(t)}
                  className={`px-3 py-2.5 min-h-11 rounded-lg text-sm font-medium border transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring
                    ${targetTime === t
                      ? 'bg-orange-600 text-white border-orange-600'
                      : 'border-border text-muted-foreground hover:border-orange-300 dark:hover:border-orange-700'
                    }`}
                >
                  {t} min
                </button>
              ))}
            </div>

            <Button
              size="lg"
              onClick={generatePlaylist}
              disabled={generating}
              className="rounded-xl font-semibold w-full bg-orange-600 hover:bg-orange-700"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Building your playlist...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Generate BPM-Matched Playlist
                </>
              )}
            </Button>
            {generating && (
              <div className="mt-4">
                <GeneratingPlaylistProgress />
              </div>
            )}
            <p className="text-sm text-muted-foreground">
              AI matches real songs to your actual splits and terrain for each kilometre of this route
            </p>

            <div className="pt-3 border-t border-border">
              <p className="text-xs text-muted-foreground mb-3">
                Want real-time pace-adaptive music during your run? Track this route live with GPS.
              </p>
              <Button
                variant="outline"
                size="lg"
                onClick={() => navigate(`/live-run?distance=${distanceKm.toFixed(1)}&targetTime=${targetTime}&source=strava&name=${encodeURIComponent(activity.name)}`)}
                className="rounded-xl font-semibold w-full border-orange-300 dark:border-orange-700 text-orange-700 dark:text-orange-400 hover:bg-orange-50 dark:hover:bg-orange-950"
              >
                <Radio className="w-4 h-4 mr-2" />
                Track This Run Live
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
    </PullToRefresh>
  );
}