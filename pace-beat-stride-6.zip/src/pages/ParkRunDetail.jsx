import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate, useParams } from 'react-router-dom';
import { MapPin, Play, Loader2, Music, ExternalLink, Radio } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { Skeleton } from '@/components/ui/skeleton';
import PullToRefresh from '@/components/common/PullToRefresh';
import { fetchUKParkRuns } from '@/lib/parkrunData';
import { getMusicTasteContext } from '@/lib/musicTaste';
import CourseDetails from '@/components/parkrun/CourseDetails';
import PageHeader from '@/components/common/PageHeader';
import GeneratingPlaylistProgress from '@/components/common/GeneratingPlaylistProgress';

export default function ParkRunDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [targetTime, setTargetTime] = useState(25);
  const [generating, setGenerating] = useState(false);

  // Parse parkrun info from URL params
  const { id: parkrunId } = useParams();
  const urlParams = new URLSearchParams(window.location.search);
  const parkrunName = urlParams.get('name') || 'Unknown Parkrun';
  const parkrunLocation = urlParams.get('location') || '';
  const eventname = urlParams.get('eventname') || '';
  const parkrunUrl = `https://www.parkrun.org.uk/${eventname}/`;

  // Stored course data: terrain, surface, elevation, per-km segments
  const { data: course, isLoading: courseLoading } = useQuery({
    queryKey: ['parkrunCourse', parkrunName],
    queryFn: async () => {
      const matches = await base44.entities.ParkRun.filter({ name: parkrunName });
      return matches[0] || null;
    },
    staleTime: 1000 * 60 * 60,
  });

  // Shared cache with the Parkruns list — provides the course coordinates
  const { data: allParkruns } = useQuery({
    queryKey: ['liveParkruns'],
    queryFn: fetchUKParkRuns,
    staleTime: 1000 * 60 * 60,
  });

  const geo = (allParkruns || []).find(
    (p) => (eventname && p.eventname === eventname) || p.name === parkrunName
  );

  // Fetch elevation profile from Open-Elevation API for route points around the parkrun
  const fetchTerrainProfile = async (lat, lng) => {
    try {
      // Generate 12 points simulating a 5km loop around the parkrun's centre
      // We use a small bounding variation (±0.02 degrees ≈ 2km) to get realistic elevation variance
      const points = [];
      for (let i = 0; i < 12; i++) {
        const angle = (i / 12) * 2 * Math.PI;
        const r = 0.018 + 0.006 * Math.sin(angle * 2); // slight ellipse
        points.push({
          latitude: lat + r * Math.sin(angle),
          longitude: lng + r * Math.cos(angle),
        });
      }
      const res = await fetch('https://api.open-elevation.com/api/v1/lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ locations: points }),
      });
      if (!res.ok) return null;
      const data = await res.json();
      const elevations = data.results.map(r => r.elevation);

      // Derive per-km gradient from the 12 elevation points mapped across 5km
      const segments = [];
      const kms = [0, 1, 2, 3, 4];
      for (let k = 0; k < 5; k++) {
        const startIdx = Math.floor((k / 5) * 11);
        const endIdx = Math.floor(((k + 1) / 5) * 11);
        const elevGain = elevations[endIdx] - elevations[startIdx];
        const gradientPct = elevGain / 1000 * 100; // per 1km
        let gradientLabel;
        if (gradientPct > 3) gradientLabel = 'steep_uphill';
        else if (gradientPct > 1) gradientLabel = 'uphill';
        else if (gradientPct > 0.3) gradientLabel = 'slight_uphill';
        else if (gradientPct < -3) gradientLabel = 'steep_downhill';
        else if (gradientPct < -1) gradientLabel = 'downhill';
        else if (gradientPct < -0.3) gradientLabel = 'slight_downhill';
        else gradientLabel = 'flat';
        segments.push({ km: k + 1, elevGain: Math.round(elevGain), gradientPct: gradientPct.toFixed(1), gradientLabel });
      }
      return segments;
    } catch {
      return null;
    }
  };

  const generatePlaylist = async () => {
    setGenerating(true);

    // Fetch parkrun lat/lng and terrain in parallel with music prefs
    const [taste, allParkruns] = await Promise.all([
      getMusicTasteContext(),
      import('@/lib/parkrunData').then(m => m.fetchUKParkRuns()),
    ]);

    const prefs = taste.prefs;

    // Find this parkrun's coordinates
    const parkrunData = allParkruns.find(p => p.eventname === eventname || p.name === parkrunName);
    let terrainProfile = null;
    if (parkrunData?.lat && parkrunData?.lng) {
      terrainProfile = await fetchTerrainProfile(parkrunData.lat, parkrunData.lng);
    }

    // Build terrain context string for the AI
    let terrainContext = '';
    if (terrainProfile) {
      const kmDescriptions = terrainProfile.map(seg => {
        const paceAdj = seg.gradientLabel.includes('uphill')
          ? `+${seg.gradientLabel === 'steep_uphill' ? 20 : 10} sec/km effort`
          : seg.gradientLabel.includes('downhill')
          ? `${seg.gradientLabel === 'steep_downhill' ? '-15' : '-8'} sec/km (recovery)`
          : 'flat effort';
        return `  - KM ${seg.km}: ${seg.gradientLabel.replace(/_/g, ' ')} (${seg.gradientPct}% grade, ${seg.elevGain > 0 ? '+' : ''}${seg.elevGain}m elevation, ${paceAdj})`;
      }).join('\n');
      terrainContext = `
ACTUAL COURSE TERRAIN PROFILE (derived from elevation data):
${kmDescriptions}

CRITICAL TERRAIN RULES for music selection:
- Uphill segments: Choose songs with HIGHER BPM (+5-10 BPM above base), heavy driving beats, high energy — to push the runner through the climb. Hard rock, drum & bass, intense electronic work well.
- Steep uphills: Maximum energy, fastest BPM in the range, most intense/aggressive tracks.
- Downhill segments: Slightly LOWER BPM (−5 BPM), flowing/melodic tracks that let the runner open up their stride naturally.
- Flat segments: Match the base cadence BPM precisely. Steady, rhythmic tracks.
- Each song's BPM and energy level must be deliberately chosen for THAT specific km's terrain, not just a generic cadence guide.`;
    }

    // Music taste context (preferred service: Spotify or Apple Music) is
    // built by the shared helper in taste.listeningContext / taste.runningPlaylistContext.

    const basePace = targetTime / 5;

    const prompt = `You are a running coach and music expert specialising in parkrun. Generate a terrain-adaptive, BPM-matched running playlist for this specific 5K parkrun course.

Course: ${parkrunName}
Location: ${parkrunLocation}
Target finish time: ${targetTime} minutes
Base pace: ${basePace.toFixed(1)} min/km
${terrainContext}

User music preferences:
- Favorite genres: ${prefs.favorite_genres?.join(', ') || 'pop, rock, electronic, hip-hop'}
- Favorite artists: ${prefs.favorite_artists?.join(', ') || 'any popular artists'}
- Energy preference: ${prefs.energy_preference || 'high'}
- BPM preference range: ${prefs.bpm_range_min || 140}-${prefs.bpm_range_max || 180}
- Exclude genres: ${prefs.exclude_genres?.join(', ') || 'none'}
${taste.listeningContext}
${taste.runningPlaylistContext}

Generate a playlist of tracks covering the full 5K run. One or more tracks per km phase, with the terrain dictating the BPM and energy.
Each track must include a "terrain_reason" field explaining WHY this song's BPM/energy fits that specific km's terrain.

For each track use REAL, well-known songs that actually exist on Spotify.

CRITICAL DURATION REQUIREMENT: The total duration of ALL tracks combined MUST be between ${targetTime * 60} and ${(targetTime + 5) * 60} seconds (${targetTime} to ${targetTime + 5} minutes). This is non-negotiable — the playlist must cover the entire run with a small buffer. Add extra tracks if needed to hit this duration. Make sure each track's duration_sec is realistic (typical songs are 180-240 seconds).`;

    const result = await base44.functions.invoke('generate-track-pool', {
      prompt,
      distance_km: 5,
      response_json_schema: {
        type: "object",
        properties: {
          segment_paces: {
            type: "array",
            items: {
              type: "object",
              properties: {
                km: { type: "number" },
                pace_min_per_km: { type: "number" },
                target_bpm: { type: "number" },
                cadence: { type: "number" },
                gradient: { type: "string" }
              }
            }
          },
          playlist: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                artist: { type: "string" },
                bpm: { type: "number" },
                duration_sec: { type: "number" },
                segment_km: { type: "number" },
                energy: { type: "string" },
                genre: { type: "string" },
                terrain_reason: { type: "string" }
              }
            }
          }
        }
      }
    });

    const plan = await base44.entities.RunPlan.create({
      parkrun_id: parkrunId,
      parkrun_name: parkrunName,
      target_time_min: targetTime,
      target_pace_per_km: basePace,
      playlist: result.data?.playlist || [],
      segment_paces: result.data?.segment_paces || [],
      status: 'ready',
    });

    queryClient.invalidateQueries({ queryKey: ['runPlans'] });
    setGenerating(false);
    navigate(`/my-plans/${plan.id}`);
  };

  return (
    <PullToRefresh
      onRefresh={() => Promise.all([
        queryClient.invalidateQueries({ queryKey: ['parkrunCourse'] }),
        queryClient.invalidateQueries({ queryKey: ['liveParkruns'] }),
      ])}
    >
    <div className="p-4 sm:p-6 md:p-10 max-w-3xl mx-auto">
      <PageHeader onBack={() => navigate('/parkruns')} />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="font-heading font-bold text-2xl md:text-3xl mb-2">{parkrunName}</h1>
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <MapPin className="w-4 h-4 shrink-0" />
                <span>{parkrunLocation}</span>
              </div>
            </div>
            {eventname && (
              <a
                href={parkrunUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="shrink-0"
              >
                <Button variant="outline" size="sm" className="rounded-xl">
                  <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
                  parkrun.org.uk
                </Button>
              </a>
            )}
          </div>
        </div>

        {/* Info card */}
        <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-8">
          {[
            { label: 'Distance', value: '5.0 km' },
            { label: 'Day', value: 'Saturday' },
            { label: 'Start Time', value: '9:00 AM' },
          ].map(item => (
            <div key={item.label} className="bg-card rounded-xl border border-border p-3 sm:p-4 text-center">
              <p className="font-heading font-bold text-base sm:text-lg">{item.value}</p>
              <p className="text-sm text-muted-foreground mt-0.5">{item.label}</p>
            </div>
          ))}
        </div>

        {/* Course terrain & route */}
        {courseLoading ? (
          <div className="mb-8">
            <Skeleton className="h-44 rounded-xl" />
          </div>
        ) : (
          <CourseDetails course={course} geo={geo} parkrunName={parkrunName} eventname={eventname} />
        )}

        {/* Plan creator */}
        <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5">
          <CardHeader>
            <CardTitle className="font-heading text-lg flex items-center gap-2">
              <Music className="w-5 h-5 text-primary" />
              Generate Your Playlist
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <Label className="text-sm font-medium mb-2 block">Target Finish Time (minutes)</Label>
              <div className="flex items-center gap-4">
                <Input
                  type="number"
                  value={targetTime}
                  onChange={(e) => setTargetTime(Number(e.target.value))}
                  min={15}
                  max={90}
                  className="w-28 rounded-xl font-mono text-lg font-bold"
                />
                <div className="text-sm text-muted-foreground">
                  <span className="font-mono font-medium text-foreground">{(targetTime / 5).toFixed(1)}</span> min/km pace
                </div>
              </div>
            </div>

            {/* Time presets */}
            <div className="flex flex-wrap gap-2">
              {[20, 25, 30, 35, 40].map(t => (
                <button
                  key={t}
                  onClick={() => setTargetTime(t)}
                  className={`px-3 py-2.5 min-h-11 rounded-lg text-sm font-medium border transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring
                    ${targetTime === t
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'border-border text-muted-foreground hover:border-primary/30'
                    }`}
                >
                  {t} min
                </button>
              ))}
            </div>

            <Button
              size="lg"
              onClick={generatePlaylist}
              disabled={generating}
              className="rounded-xl font-semibold w-full"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Building your perfect playlist...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Generate BPM-Matched Playlist
                </>
              )}
            </Button>
            {generating && (
              <div className="mt-4">
                <GeneratingPlaylistProgress />
              </div>
            )}
            <p className="text-sm text-muted-foreground">
              AI matches real songs to your cadence and music taste for each phase of the run
            </p>

            <div className="pt-3 border-t border-border">
              <p className="text-sm text-muted-foreground mb-3">
                Want real-time pace-adaptive music during your run? Track it live with GPS.
              </p>
              <Button
                variant="outline"
                size="lg"
                onClick={() => navigate(`/live-run?distance=5&targetTime=${targetTime}&source=parkrun&name=${encodeURIComponent(parkrunName)}`)}
                className="rounded-xl font-semibold w-full border-primary/30 text-primary hover:bg-primary/5"
              >
                <Radio className="w-4 h-4 mr-2" />
                Track This Run Live
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
    </PullToRefresh>
  );
}