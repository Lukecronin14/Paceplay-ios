import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Activity, Loader2, Music, Sparkles } from 'lucide-react';
import {
  getPreferredUnits,
  setPreferredUnits,
  kmToDisplay,
  displayToKm,
  formatDisplayPace,
  displayUnit,
} from '@/lib/units';
import RoutePrediction from '@/components/live/RoutePrediction';
import PresetSelector from '@/components/live/PresetSelector';
import PageHeader from '@/components/common/PageHeader';
import PullToRefresh from '@/components/common/PullToRefresh';
import GeneratingPlaylistProgress from '@/components/common/GeneratingPlaylistProgress';
import { getMusicTasteContext } from '@/lib/musicTaste';
import { getPreferredMusicService } from '@/lib/musicService';
import UnfinishedRunPrompt from '@/components/live/UnfinishedRunPrompt';
import { useUnfinishedRun } from '@/hooks/useUnfinishedRun';

export default function LiveRunSetup() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const queryClient = useQueryClient();
  const params = new URLSearchParams(window.location.search);
  const initialDistance = parseFloat(params.get('distance')) || 10;
  const initialTargetTime = parseFloat(params.get('targetTime')) || 55;
  const sourceName = params.get('name') || '';
  const sourceType = params.get('source') || '';

  const [distance, setDistance] = useState(initialDistance);
  const [targetTime, setTargetTime] = useState(initialTargetTime);
  const [units, setUnits] = useState(getPreferredUnits());
  const [generating, setGenerating] = useState(false);
  const [terrainPrediction, setTerrainPrediction] = useState(null);
  const [terrainSummary, setTerrainSummary] = useState(null);

  const { data: prefs = {} } = useQuery({
    queryKey: ['musicPrefs'],
    queryFn: async () => {
      const list = await base44.entities.MusicPreference.list();
      return list[0] || {};
    },
  });

  const musicService = getPreferredMusicService();
  const unit = displayUnit();

  // Batch B3: same unfinished-run detection as Home (shared hook) — a new run
  // is blocked until the unfinished one is resumed or discarded, so entry
  // points can never create duplicates.
  const { unfinishedRun } = useUnfinishedRun();

  const targetPace = distance > 0 && targetTime > 0 ? targetTime / distance : 0;

  const presets = [
    { label: '5K', dist: 5, time: 25 },
    { label: '10K', dist: 10, time: 55 },
    { label: 'Half', dist: 21.1, time: 120 },
    { label: 'Full', dist: 42.2, time: 240 },
  ];

  const handleGenerate = async () => {
    if (generating) return; // double-submission guard: one run per generate
    setGenerating(true);
    try {
      const terrainSection = terrainPrediction && terrainPrediction.length > 0
        ? `PREDICTED TERRAIN PROFILE (from Strava history):
${terrainPrediction.map(seg => `- KM ${seg.km}: ${seg.gradient.replace(/_/g, ' ')} (${seg.avg_grade > 0 ? '+' : ''}${seg.avg_grade}% grade, pace adjustment: ${seg.pace_adjustment_min_per_km > 0 ? '+' : ''}${seg.pace_adjustment_min_per_km} min/km)`).join('\n')}

Terrain type: ${terrainSummary?.terrain_type || 'mixed'} · ~${terrainSummary?.elevation_gain_m || 0}m elevation gain

ADAPT TRACKS TO TERRAIN:
- Uphill kms: higher BPM push tracks, motivational energy, higher base BPM for the "on_pace" option
- Downhill kms: slightly lower BPM, use momentum, the "ahead_pace" option is most relevant
- Flat kms: standard BPM matching target pace
- Factor in the pace adjustment when setting target BPM for each km`
        : '';

      // Music taste from the user's preferred service (Spotify or Apple Music)
      const taste = await getMusicTasteContext();

      const prompt = `You are a running DJ AI. Generate a music track pool for a runner.

RUN DETAILS:
- Distance: ${distance} km
- Target time: ${targetTime} minutes
- Target pace: ${targetPace.toFixed(2)} min/km

MUSIC PREFERENCES:
- Favorite genres: ${prefs.favorite_genres?.join(', ') || 'any'}
- Favorite artists: ${prefs.favorite_artists?.join(', ') || 'any'}
- Energy preference: ${prefs.energy_preference || 'high'}
- BPM range: ${prefs.bpm_range_min || 140}-${prefs.bpm_range_max || 180}
- Exclude genres: ${prefs.exclude_genres?.join(', ') || 'none'}

${taste.listeningContext}

${taste.runningPlaylistContext}

${terrainSection}

TASK:
For each kilometre (1 through ${Math.ceil(distance)}), provide exactly 3 track options:
1. "on_pace" — BPM matching the target pace${terrainPrediction ? ' adjusted for terrain' : ''}, for when the runner is on target
2. "behind_pace" — 10-15 BPM higher to push the runner when falling behind
3. "ahead_pace" — 5-10 BPM lower to help settle when going too fast

Use real, well-known tracks. Be accurate with BPM. Early kms should build energy, middle kms peak, final kms maximum motivation.${terrainPrediction ? ' Match track energy and BPM to the predicted terrain for each km.' : ''}${(taste.listeningContext || taste.runningPlaylistContext) ? ' Draw broadly from the user\'s listening history and designated running playlists, prioritising their curated running tracks, plus well-known tracks by their favourite artists. Do NOT restrict to a single playlist.' : ''}`;

      const response = await base44.functions.invoke('generate-track-pool', {
        prompt,
        distance_km: distance,
        response_json_schema: {
          type: 'object',
          properties: {
            segments: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  km: { type: 'number' },
                  gradient: { type: 'string' },
                  target_pace_min_per_km: { type: 'number' },
                  target_bpm: { type: 'number' },
                  tracks: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        title: { type: 'string' },
                        artist: { type: 'string' },
                        bpm: { type: 'number' },
                        energy: { type: 'string' },
                        duration_sec: { type: 'number' },
                        scenario: { type: 'string' },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      });

      const liveRun = await base44.entities.LiveRun.create({
        target_distance_km: distance,
        target_time_min: targetTime,
        target_pace_per_km: targetPace,
        status: 'ready',
        track_pool: response.data?.segments || [],
      });

      navigate(`/live-run/${liveRun.id}`);
    } catch (err) {
      console.error('Generation failed:', err);
      alert('Failed to generate track pool. Please try again.');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <PullToRefresh
      enabled={pathname === '/live-run'}
      onRefresh={() => queryClient.invalidateQueries({ queryKey: ['musicPrefs'] })}
    >
    <div className="p-4 sm:p-6 md:p-10 max-w-2xl mx-auto">
      <PageHeader title="Live Run" />
      <div className="mb-6 sm:mb-8">
        <div className="flex items-center gap-2 mb-2">
          <Activity className="w-5 h-5 text-primary" />
          <span className="text-sm font-medium text-primary">Live Run Mode</span>
        </div>
        <h1 className="font-heading text-2xl sm:text-3xl font-bold mb-2">
          {sourceName ? `Track: ${sourceName}` : 'Adaptive Music Selector'}
        </h1>
        <p className="text-sm text-muted-foreground">
          {sourceType === 'parkrun' || sourceType === 'strava'
            ? 'Your route details are pre-filled. Generate a track pool and GPS will adapt the music to your pace in real-time.'
            : 'AI generates a pool of tracks for every kilometre. GPS monitors your pace in real-time and selects the right song to keep you on target.'}
        </p>
      </div>

      {unfinishedRun && (
        <UnfinishedRunPrompt
          run={unfinishedRun}
          onResolved={() => queryClient.invalidateQueries({ queryKey: ['unfinishedRun'] })}
        />
      )}

      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-between">
          <Label>Distance ({unit})</Label>
          <div className="flex gap-1 bg-muted rounded-lg p-1">
            {[['metric', 'km'], ['imperial', 'mi']].map(([value, label]) => (
              <button
                key={value}
                onClick={() => { setUnits(value); setPreferredUnits(value); }}
                className={`px-3 h-8 rounded-md text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring ${
                  units === value ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        <Input
          type="number"
          min="0.3"
          step="0.5"
          value={distance > 0 ? +kmToDisplay(distance).toFixed(2) : ''}
          onChange={(e) => setDistance(displayToKm(parseFloat(e.target.value) || 0))}
          className="text-lg font-heading"
        />
        <PresetSelector
          presets={presets}
          distance={distance}
          unitLabel={unit}
          onSelect={(p) => { setDistance(p.dist); setTargetTime(p.time); }}
        />
      </div>

      <div className="space-y-3 mb-6">
        <Label>Target Time (minutes)</Label>
        <Input
          type="number"
          min="1"
          step="1"
          value={targetTime}
          onChange={(e) => setTargetTime(parseFloat(e.target.value) || 0)}
          className="text-lg font-heading"
        />
        <div className="bg-muted/50 rounded-lg px-4 py-3 flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Target pace</span>
          <span className="font-heading font-bold text-lg text-primary">{formatDisplayPace(targetPace)} /{unit}</span>
        </div>
      </div>

      <div className="mb-6">
        <RoutePrediction
          targetDistance={distance}
          onTerrainReady={(pred, summary) => {
            setTerrainPrediction(pred);
            setTerrainSummary(summary);
          }}
        />
      </div>

      <div className="bg-card border border-border rounded-xl p-4 mb-6">
        <div className="flex items-start gap-3">
          <Music className="w-5 h-5 text-accent shrink-0 mt-0.5" />
          <div className="text-sm flex-1">
            <p className="font-medium mb-1">Music Sources</p>
            {prefs.favorite_genres?.length > 0 && (
              <p className="text-muted-foreground text-sm mb-0.5">Genres: {prefs.favorite_genres.join(', ')}</p>
            )}
            {musicService === 'spotify' && (
              <p className="text-muted-foreground text-sm mb-0.5">
                Spotify: your listening history and running playlists feed the track pool
              </p>
            )}
            {musicService === 'apple_music' && (
              <p className="text-muted-foreground text-sm mb-0.5">
                Apple Music: your listening history and running playlists feed the track pool
              </p>
            )}
            {!musicService && (
              <p className="text-muted-foreground text-sm">
                Connect Spotify or Apple Music on the home page for personalised tracks
              </p>
            )}
          </div>
        </div>
      </div>

      <Button
        onClick={handleGenerate}
        disabled={generating || !distance || !targetTime || !!unfinishedRun}
        size="lg"
        className="w-full text-base font-semibold rounded-xl"
      >
        {generating ? (
          <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating track pool...</>
        ) : (
          <><Sparkles className="w-4 h-4 mr-2" /> Generate Track Pool</>
        )}
      </Button>

      {unfinishedRun && !generating && (
        <p className="text-xs text-muted-foreground text-center mt-3">
          Finish or discard your unfinished run above before starting a new one.
        </p>
      )}

      {generating && (
        <div className="mt-6">
          <GeneratingPlaylistProgress segments={Math.min(Math.ceil(distance) || 3, 5)} />
        </div>
      )}

      <div className="mt-8 space-y-3">
        <h2 className="font-heading font-semibold text-sm">How it works</h2>
        {[
          { n: '1', t: 'AI generates 3 tracks per km', d: terrainPrediction ? 'Terrain-aware: BPM matched to predicted gradients' : 'On-pace, push (behind), and settle (ahead) options' },
          { n: '2', t: 'GPS tracks your pace live', d: 'Smoothed over recent points for accuracy' },
          { n: '3', t: 'Music adapts automatically', d: 'The right track is selected based on your real-time pace' },
        ].map(step => (
          <div key={step.n} className="flex gap-3">
            <div className="w-7 h-7 rounded-full bg-primary/10 text-primary font-heading font-bold text-sm flex items-center justify-center shrink-0">
              {step.n}
            </div>
            <div>
              <p className="text-sm font-medium">{step.t}</p>
              <p className="text-sm text-muted-foreground">{step.d}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
    </PullToRefresh>
  );
}