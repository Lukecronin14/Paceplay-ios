import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { useRunTracker } from '@/hooks/useRunTracker';
import PaceDashboard from '@/components/live/PaceDashboard';
import NowPlaying from '@/components/live/NowPlaying';
import { Play, Pause, Square, Activity, ChevronRight, Loader2 } from 'lucide-react';
import { pickNextTrack } from '@/lib/paceUtils';
import { formatDisplayPace, formatDisplayDistance, displayUnit } from '@/lib/units';
import { useSpotifyPlayer } from '@/hooks/useSpotifyPlayer';
import { useWakeLock } from '@/hooks/useWakeLock';
import { useAudioKeepAlive } from '@/hooks/useAudioKeepAlive';
import SpotifyPlayer from '@/components/live/SpotifyPlayer';
import { useAppleMusicPlayer } from '@/hooks/useAppleMusicPlayer';
import AppleMusicPlayer from '@/components/live/AppleMusicPlayer';
import { getPreferredMusicService, isAppleMusicConnected } from '@/lib/musicService';
import { searchAppleMusicCatalogTracks } from '@/lib/appleMusicData';
import PostRunSummary from '@/components/live/PostRunSummary';
import { useToast } from '@/components/ui/use-toast';
import PageHeader from '@/components/common/PageHeader';
import { runBackgroundBridge } from '@/lib/runBackground';
import RecoveryPrompt from '@/components/live/RecoveryPrompt';
import { useRunCheckpoint, mirrorKey } from '@/hooks/useRunCheckpoint';
import { RECOVERABLE_STATUSES, TERMINAL_STATUSES, planRecovery, resumeFromCheckpoint } from '@/lib/runCheckpoint';

export default function LiveRunActive() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [run, setRun] = useState(null);
  const [loading, setLoading] = useState(true);
  const [runStatus, setRunStatus] = useState('ready');
  const [showPool, setShowPool] = useState(false);
  const [saving, setSaving] = useState(false);
  const [recovery, setRecovery] = useState(null);

  useEffect(() => {
    base44.entities.LiveRun.get(id).then(data => {
      setRun(data);
      setRunStatus(data.status || 'ready');
      // Unfinished run left by a crash / force-close / navigation: plan
      // recovery from the server checkpoint vs the best-effort local mirror.
      if (data && RECOVERABLE_STATUSES.includes(data.status)) {
        const plan = planRecovery(data, localStorage.getItem(mirrorKey(id)));
        setRecovery(plan);
        // Batch B3, app reopen: when the local mirror holds progress the
        // server has not confirmed (it was written offline), converge it to
        // the server immediately. Idempotent (same shape, converges by seq)
        // and terminal-guarded — refused outright if the run finished while
        // the app was closed.
        if (plan?.adoptedMirror && plan.checkpoint) {
          base44.entities.LiveRun.updateMany(
            { id, status: { $nin: TERMINAL_STATUSES } },
            { $set: { checkpoint: plan.checkpoint } }
          ).catch(() => {});
        }
      }
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [id]);

  const tracker = useRunTracker(
    run?.target_distance_km || 1,
    run?.target_time_min || 1
  );

  // Checkpoint persistence + guarded run writes (Stage B / R2). All writes go
  // through a conditional updateMany whose filter excludes terminal statuses,
  // so a stale checkpoint/status write can never overwrite a completed or
  // abandoned run — the data layer refuses the match.
  const checkpoint = useRunCheckpoint({
    run,
    tracker,
    enabled: runStatus === 'active' || runStatus === 'paused',
    onTerminal: () => {
      // The run finished (or was discarded) elsewhere: follow the server record.
      base44.entities.LiveRun.get(id).then(server => {
        if (server) {
          setRun(server);
          setRunStatus(server.status);
        } else {
          navigate('/live-run');
        }
      }).catch(() => {});
    },
    onError: () => toast({
      title: 'Checkpoints not syncing',
      description: 'Progress is saved on this device and will sync when the connection returns.',
      variant: 'destructive',
    }),
  });

  const spotifyToken = localStorage.getItem('spotify_access_token');
  const musicService = getPreferredMusicService();
  const isAppleMusic = musicService === 'apple_music';
  const applePlayer = useAppleMusicPlayer(isAppleMusic && isAppleMusicConnected());
  const spotifyPlayer = useSpotifyPlayer(isAppleMusic ? null : spotifyToken);
  const player = isAppleMusic ? applePlayer : spotifyPlayer;
  const [trackUris, setTrackUris] = useState({});
  const [searchingTracks, setSearchingTracks] = useState(false);
  const [currentTrackUri, setCurrentTrackUri] = useState(null);
  const [currentTrack, setCurrentTrack] = useState(null);
  const [upNext, setUpNext] = useState(null);
  const lastPlayStartRef = useRef(0);
  const lastPlayedSegRef = useRef(-1);
  const playedUrisRef = useRef(new Set());
  const queuedUriRef = useRef(null);
  const queuedTrackRef = useRef(null);
  const queuedNextRef = useRef(null);

  useWakeLock(runStatus === 'active');
  useAudioKeepAlive(runStatus === 'active');

  // Warn before a reload/close while a run is in progress. Recovery remains
  // available (checkpoint + mirror) if the user proceeds — nothing is lost
  // beyond the documented checkpoint window.
  useEffect(() => {
    if (runStatus !== 'active' && runStatus !== 'paused') return;
    const onBeforeUnload = (e) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, [runStatus]);

  // Native (Capacitor) iOS build: background location + background audio
  // session keep tracking and music control running while the device is
  // locked. Web builds rely on wake lock + keep-alive audio instead.
  useEffect(() => {
    if (runStatus !== 'active' || !run || !runBackgroundBridge) return;
    let handle = null;
    runBackgroundBridge.enable().catch(() => {});
    runBackgroundBridge.addLocationListener((point) => tracker.ingestPosition(point))
      .then((h) => { handle = h; })
      .catch(() => {});
    return () => {
      handle?.remove?.();
      runBackgroundBridge.disable().catch(() => {});
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runStatus, run?.id]);

  const searchTracksForPool = async (pool) => {
    if (!pool?.length || !(isAppleMusic ? isAppleMusicConnected() : spotifyToken)) return;
    setSearchingTracks(true);
    try {
      const allTracks = [];
      const seen = new Set();
      pool.forEach(seg => {
        seg.tracks?.forEach(t => {
          const key = `${t.title}|${t.artist}`;
          if (!seen.has(key)) {
            seen.add(key);
            allTracks.push({ title: t.title, artist: t.artist });
          }
        });
      });

      const idMap = {};
      if (isAppleMusic) {
        const results = await searchAppleMusicCatalogTracks(allTracks);
        results.forEach(r => { idMap[`${r.title}|${r.artist}`] = r.id; });
      } else {
        const res = await base44.functions.invoke('spotifyIntegration', {
          action: 'searchTracks',
          accessToken: spotifyToken,
          tracks: allTracks,
        });
        (res.data?.results || []).forEach(r => {
          if (r.uri) {
            idMap[`${r.title}|${r.artist}`] = r.uri;
          }
        });
      }
      setTrackUris(idMap);
    } catch (err) {
      console.error('Track search failed:', err);
    } finally {
      setSearchingTracks(false);
    }
  };

  // Apple Music: in-page playback — keep the simpler end-of-song switching.
  useEffect(() => {
    if (!isAppleMusic) return;
    if (!run || runStatus !== 'active' || !player.isReady || Object.keys(trackUris).length === 0) return;

    const pool = run.track_pool || [];
    if (!pool.length) return;

    const started = currentTrackUri !== null;

    // A song is playing (or just started — playback state settles for a few
    // seconds): let it finish, no switching.
    if (started && player.isPlaying) return;
    if (started && Date.now() - lastPlayStartRef.current < 15000) return;

    const segIndex = started
      ? Math.min(lastPlayedSegRef.current + 1, pool.length - 1)
      : Math.min(tracker.currentKm, pool.length - 1);

    const segment = pool[segIndex];
    if (!segment) return;
    const playable = segment.tracks.find(t => trackUris[`${t.title}|${t.artist}`]);
    if (!playable) return;
    const uri = trackUris[`${playable.title}|${playable.artist}`];
    if (uri && uri !== currentTrackUri) {
      playedUrisRef.current.add(uri);
      lastPlayedSegRef.current = segIndex;
      lastPlayStartRef.current = Date.now();
      setCurrentTrackUri(uri);
      setCurrentTrack(playable);
      // Pre-queue the next pace-matched song so MusicKit advances gaplessly
      // when this one ends (and keeps playing on a locked screen).
      const next = pickNextTrack(pool, tracker.currentKm, tracker.paceDeviation, playedUrisRef.current, trackUris);
      if (next && next.uri && next.uri !== uri) {
        queuedNextRef.current = { id: next.uri, track: next.track, segIndex: next.segIndex };
        setUpNext(next.track);
        player.playTrack(uri, next.uri);
      } else {
        queuedNextRef.current = null;
        player.playTrack(uri);
      }
    }
  }, [run, tracker.currentKm, player.isPlaying, runStatus, player.isReady, trackUris, currentTrackUri, isAppleMusic]);

  // Apple Music native queue adoption: when MusicKit advances to the track we
  // pre-queued (song ended gaplessly, even on a locked screen), adopt it and
  // pre-queue the following pace-matched track.
  useEffect(() => {
    if (!isAppleMusic || runStatus !== 'active' || !player.isReady) return;
    const queued = queuedNextRef.current;
    if (!queued || !player.nowPlayingItemId || player.nowPlayingItemId !== queued.id) return;
    playedUrisRef.current.add(queued.id);
    setCurrentTrackUri(queued.id);
    setCurrentTrack(queued.track);
    lastPlayedSegRef.current = queued.segIndex;
    lastPlayStartRef.current = Date.now();
    setUpNext(null);
    queuedNextRef.current = null;
    const nextPool = run?.track_pool || [];
    const next = pickNextTrack(nextPool, tracker.currentKm, tracker.paceDeviation, playedUrisRef.current, trackUris);
    if (next && next.uri && next.uri !== queued.id) {
      queuedNextRef.current = { id: next.uri, track: next.track, segIndex: next.segIndex };
      setUpNext(next.track);
      player.queueNext(next.uri);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAppleMusic, runStatus, player.isReady, player.nowPlayingItemId]);

  // Spotify Connect playback controller: the app leads the Spotify app.
  // - Tracks exactly which item is playing and how far through it is.
  // - Queues the next pace-matched song ~20s before the current one ends
  //   (gapless, survives a locked screen).
  // - Takes playback back if Spotify plays anything the app didn't choose
  //   (repeat, autoplay, a stray skip in the Spotify app).
  // - Respects a pause made inside Spotify instead of fighting it.
  useEffect(() => {
    if (isAppleMusic) return;
    if (!run || runStatus !== 'active' || !spotifyPlayer.isReady) return;
    const pool = run.track_pool || [];
    if (!pool.length || Object.keys(trackUris).length === 0) return;

    const st = spotifyPlayer.playbackState;
    const choose = () => pickNextTrack(pool, tracker.currentKm, tracker.paceDeviation, playedUrisRef.current, trackUris);
    const adopt = (pick) => {
      setCurrentTrackUri(pick.uri);
      setCurrentTrack(pick.track);
      lastPlayedSegRef.current = pick.segIndex;
      lastPlayStartRef.current = Date.now();
    };

    // Run just started: pick the current km's pace-matched song. If Spotify is
    // already playing something of its own, the app takes over immediately.
    if (!currentTrackUri) {
      if (!st) return; // playback state not fetched yet
      const pick = choose();
      if (pick) {
        playedUrisRef.current.add(pick.uri);
        adopt(pick);
        spotifyPlayer.playTrack(pick.uri);
      }
      return;
    }

    // Our song is playing: line up the next one shortly before it ends.
    if (st?.isPlaying && st.itemUri === currentTrackUri) {
      const remainingMs = st.durationMs - st.progressMs;
      if (st.durationMs > 0 && remainingMs <= 20000 && !queuedUriRef.current) {
        const pick = choose();
        if (pick) {
          playedUrisRef.current.add(pick.uri);
          queuedUriRef.current = pick.uri;
          queuedTrackRef.current = pick.track;
          lastPlayedSegRef.current = pick.segIndex;
          setUpNext(pick.track);
          spotifyPlayer.queueTrack(pick.uri).then((ok) => {
            if (!ok) {
              // Queueing failed (even after the hook's retry) — drop the
              // queued marker so the controller falls back to a direct play.
              queuedUriRef.current = null;
              queuedTrackRef.current = null;
              setUpNext(null);
            }
          });
        }
      }
      return;
    }

    // Paused inside Spotify (song not ended) — respect the user's pause.
    if (st && !st.isPlaying && st.itemUri === currentTrackUri && st.durationMs > 0 && st.progressMs < st.durationMs) return;

    // Settle window right after the app starts/adopts a track: the poll can
    // briefly still report the previous item.
    if (Date.now() - lastPlayStartRef.current < 8000) return;

    // Our queued track started (song ended gaplessly): adopt it.
    if (st?.isPlaying && st.itemUri && st.itemUri === queuedUriRef.current) {
      setCurrentTrackUri(queuedUriRef.current);
      setCurrentTrack(queuedTrackRef.current);
      lastPlayStartRef.current = Date.now();
      queuedUriRef.current = null;
      queuedTrackRef.current = null;
      setUpNext(null);
      return;
    }

    // Foreign playback (Spotify autoplay/repeat/user pick) or the song ended
    // without a queue: take back control with a pace-matched pick.
    const pick = choose();
    if (pick) {
      playedUrisRef.current.add(pick.uri);
      queuedUriRef.current = null;
      queuedTrackRef.current = null;
      setUpNext(null);
      adopt(pick);
      spotifyPlayer.playTrack(pick.uri);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [run, runStatus, isAppleMusic, spotifyPlayer.isReady, spotifyPlayer.playbackState, tracker.currentKm, tracker.paceDeviation, trackUris, currentTrackUri]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!run) {
    return (
      <div className="p-6 text-center">
        <p className="text-muted-foreground mb-4">Run not found.</p>
        <Link to="/live-run"><Button>Back to Setup</Button></Link>
      </div>
    );
  }

  const totalKm = Math.ceil(run.target_distance_km);

  const handleStart = async () => {
    navigator.vibrate?.(10);
    const prevStatus = runStatus;
    setRunStatus('active');
    if (run.track_pool?.length && (isAppleMusic ? isAppleMusicConnected() : spotifyToken)) {
      await searchTracksForPool(run.track_pool);
    }
    lastPlayedSegRef.current = -1;
    setCurrentTrackUri(null);
    setCurrentTrack(null);
    setUpNext(null);
    playedUrisRef.current = new Set();
    queuedUriRef.current = null;
    queuedTrackRef.current = null;
    queuedNextRef.current = null;
    if (!isAppleMusic) spotifyPlayer.setRepeatOff();
    tracker.start();
    checkpoint.setStartSeq(0);
    setSaving(true);
    try {
      const res = await checkpoint.guardedUpdate({
        status: 'active',
        start_time: new Date().toISOString(),
      });
      if (res.updated === 0) throw new Error('run already finished');
      // First durable checkpoint (seq 1) with the freshly started clock.
      checkpoint.flushNow('start').catch(() => {});
    } catch (err) {
      console.error('Update failed:', err);
      tracker.stop();
      setRunStatus(prevStatus);
      toast({ title: 'Could not save run status', description: 'Check your connection and try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handlePause = async () => {
    navigator.vibrate?.(10);
    const prevStatus = runStatus;
    setRunStatus('paused');
    tracker.pause();
    if (player.isReady) player.pause();
    setSaving(true);
    try {
      const res = await checkpoint.guardedUpdate({ status: 'paused' });
      if (res.updated === 0) throw new Error('run already finished');
      // Checkpoint captures the pause in progress (pause_started_at_ms).
      checkpoint.flushNow('pause').catch(() => {});
    } catch (err) {
      console.error('Update failed:', err);
      tracker.resume();
      setRunStatus(prevStatus);
      toast({ title: 'Could not save run status', description: 'Check your connection and try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleResume = async () => {
    navigator.vibrate?.(10);
    const prevStatus = runStatus;
    setRunStatus('active');
    tracker.resume();
    if (player.isReady) player.resume();
    setSaving(true);
    try {
      const res = await checkpoint.guardedUpdate({ status: 'active' });
      if (res.updated === 0) throw new Error('run already finished');
      // Checkpoint folds the completed pause into paused_ms.
      checkpoint.flushNow('resume').catch(() => {});
    } catch (err) {
      console.error('Update failed:', err);
      tracker.pause();
      setRunStatus(prevStatus);
      toast({ title: 'Could not save run status', description: 'Check your connection and try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleStop = async () => {
    navigator.vibrate?.(10);
    const finalDistance = tracker.distanceKm;
    const finalElapsed = tracker.elapsedSec;
    const prevStatus = runStatus;
    setRunStatus('completed');
    tracker.stop();
    if (player.isReady) player.pause();
    const actualPace = finalDistance > 0 ? finalElapsed / 60 / finalDistance : 0;
    setSaving(true);
    try {
      const route = tracker.getRoute();
      const res = await checkpoint.guardedUpdate({
        status: 'completed',
        end_time: new Date().toISOString(),
        actual_distance_km: finalDistance,
        actual_time_min: finalElapsed / 60,
        actual_pace_per_km: actualPace,
        route,
        checkpoint: null,
      });
      if (res.updated === 0) {
        // Lost the finish race (another instance finished first): adopt the
        // server record — the first confirmed result wins, nothing overwritten.
        const server = await base44.entities.LiveRun.get(run.id);
        if (server && server.status === 'completed') {
          setRun(server);
          checkpoint.clearMirror();
        } else {
          setRunStatus(prevStatus);
          toast({ title: 'Could not save run status', description: 'Check your connection and try again.', variant: 'destructive' });
        }
      } else {
        checkpoint.clearMirror();
      }
    } catch (err) {
      console.error('Update failed:', err);
      setRunStatus(prevStatus);
      toast({ title: 'Could not save run status', description: 'Check your connection and try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleSkip = () => {
    navigator.vibrate?.(10);
    const skipPool = run.track_pool || [];
    if (!skipPool.length || Object.keys(trackUris).length === 0 || !player.isReady) return;
    if (currentTrackUri) playedUrisRef.current.add(currentTrackUri);
    const pick = pickNextTrack(skipPool, tracker.currentKm, tracker.paceDeviation, playedUrisRef.current, trackUris);
    if (!pick) return;
    playedUrisRef.current.add(pick.uri);
    queuedUriRef.current = null;
    queuedTrackRef.current = null;
    queuedNextRef.current = null;
    setUpNext(null);
    lastPlayedSegRef.current = pick.segIndex;
    lastPlayStartRef.current = Date.now();
    setCurrentTrackUri(pick.uri);
    setCurrentTrack(pick.track);
    player.playTrack(pick.uri);
  };

  // ---- Recovery (Stage B / R2) ----

  const handleRecoveryResume = () => {
    navigator.vibrate?.(10);
    const payload = recovery.mode === 'checkpoint'
      ? resumeFromCheckpoint(recovery.checkpoint)
      : {
          // Legacy approximate restore: original start_time, zero pause
          // accounting (disclosed in the recovery screen).
          clockState: { start_time_ms: Date.parse(run.start_time), paused_ms: 0, pause_started_at_ms: null },
          distanceMeters: 0,
          splits: [],
          route: [],
          lastPoint: null,
        };
    if (!payload || !tracker.restore(payload)) return;
    checkpoint.setStartSeq(recovery.mode === 'checkpoint' ? recovery.checkpoint.seq : 0);
    // A newer local mirror won reconciliation: flush it so server and local converge.
    if (recovery.adoptedMirror) checkpoint.flushNow('reconcile').catch(() => {});
    setRecovery(null);
    setRunStatus(payload.clockState.pause_started_at_ms ? 'paused' : 'active');
    if (run.track_pool?.length && (isAppleMusic ? isAppleMusicConnected() : spotifyToken)) {
      searchTracksForPool(run.track_pool).catch(() => {});
    }
  };

  const handleRecoveryDiscard = async () => {
    navigator.vibrate?.(10);
    try {
      const res = await checkpoint.guardedUpdate({ status: 'abandoned', checkpoint: null });
      checkpoint.clearMirror();
      if (res.updated === 1) {
        setRecovery(null);
        navigate('/live-run');
      } else {
        // Terminal elsewhere — follow the server record.
        const server = await base44.entities.LiveRun.get(run.id);
        if (server) {
          setRun(server);
          setRunStatus(server.status);
          setRecovery(null);
        } else {
          navigate('/live-run');
        }
      }
    } catch (err) {
      console.error('Discard failed:', err);
      toast({ title: 'Could not discard run', description: 'Check your connection and try again.', variant: 'destructive' });
      // Recovery stays on screen — the run is never silently discarded.
    }
  };

  // Recovery view: an unfinished run was detected on open.
  if (recovery) {
    return (
      <RecoveryPrompt
        run={run}
        plan={recovery}
        onResume={handleRecoveryResume}
        onDiscard={handleRecoveryDiscard}
      />
    );
  }

  // Ready view
  if (runStatus === 'ready') {
    return (
      <div className="p-4 sm:p-6 md:p-10 max-w-2xl mx-auto">
        <PageHeader onBack={() => navigate('/live-run')} />
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-5 h-5 text-primary" />
            <span className="text-sm font-medium text-primary">Ready to Run</span>
          </div>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold mb-2">
            {formatDisplayDistance(run.target_distance_km, 1)} {displayUnit()} · {run.target_time_min} min
          </h1>
          <p className="text-sm text-muted-foreground">Target pace: {formatDisplayPace(run.target_pace_per_km)} /{displayUnit()}</p>
        </div>

        <div className="bg-card rounded-2xl border border-border mb-6 overflow-hidden">
          <button
            onClick={() => setShowPool(!showPool)}
            aria-label={showPool ? 'Hide track pool' : 'Show track pool'}
            aria-expanded={showPool}
            className="w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
          >
            <span className="font-medium text-sm">Track Pool · {run.track_pool?.length || 0} segments</span>
            <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${showPool ? 'rotate-90' : ''}`} />
          </button>
          {showPool && (
            <div className="border-t border-border divide-y divide-border max-h-80 overflow-y-auto">
              {run.track_pool?.map((seg, i) => (
                <div key={i} className="p-3">
                  <p className="text-sm font-medium text-muted-foreground mb-2">
                    KM {seg.km} · {seg.target_bpm} BPM target
                  </p>
                  <div className="space-y-1.5">
                    {seg.tracks?.map((t, j) => (
                      <div key={j} className="flex items-center gap-2 text-sm">
                        <span className={`w-2 h-2 rounded-full shrink-0 ${t.scenario === 'on_pace' ? 'bg-primary' : t.scenario === 'behind_pace' ? 'bg-chart-3' : 'bg-chart-4'}`} />
                        <span className="font-medium truncate flex-1">{t.title}</span>
                        <span className="text-xs text-muted-foreground hidden sm:inline">{t.artist}</span>
                        <span className="text-sm font-medium text-primary">{t.bpm}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="mb-4">
          {isAppleMusic ? (
            <AppleMusicPlayer player={applePlayer} connected={isAppleMusicConnected()} />
          ) : (
            <SpotifyPlayer player={spotifyPlayer} spotifyToken={spotifyToken} />
          )}
        </div>

        <Button onClick={handleStart} disabled={searchingTracks || saving} size="lg" className="w-full text-base font-semibold rounded-xl">
          {searchingTracks ? (
            <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Searching tracks...</>
          ) : (
            <><Play className="w-5 h-5 mr-2" /> Start Live Run</>
          )}
        </Button>

        <p className="text-sm text-muted-foreground text-center mt-3">
          Make sure location permissions are enabled for accurate GPS tracking.
        </p>
      </div>
    );
  }

  // Completed view
  if (runStatus === 'completed') {
    return <PostRunSummary run={run} tracker={tracker} />;
  }

  // Discarded elsewhere (never silently): short terminal notice.
  if (runStatus === 'abandoned') {
    return (
      <div className="p-6 text-center">
        <p className="text-muted-foreground mb-4">This run was discarded.</p>
        <Link to="/live-run"><Button>Back to Setup</Button></Link>
      </div>
    );
  }

  // Active / Paused view
  return (
    <div className="p-4 sm:p-6 md:p-10 max-w-2xl mx-auto min-h-screen flex flex-col pb-safe">
      <PageHeader onBack={() => navigate('/live-run')} />
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">
          {formatDisplayDistance(run.target_distance_km, 1)} {displayUnit()} target · {formatDisplayPace(run.target_pace_per_km)} /{displayUnit()}
        </p>
        {runStatus === 'paused' && (
          <span className="text-xs font-medium text-chart-3 bg-chart-3/10 px-2 py-1 rounded-md">PAUSED</span>
        )}
      </div>

      <PaceDashboard
        tracker={tracker}
        targetDistanceKm={run.target_distance_km}
        targetTimeMin={run.target_time_min}
      />

      <div className="mt-4">
        <NowPlaying
          trackPool={run.track_pool}
          currentKm={tracker.currentKm}
          paceDeviation={tracker.paceDeviation}
          totalKm={totalKm}
          actualTrack={currentTrack}
          upNext={upNext}
          onSkip={handleSkip}
        />
      </div>

      {(spotifyToken || isAppleMusic) && (
        <div className="mt-4">
          {isAppleMusic ? (
            <AppleMusicPlayer player={applePlayer} connected={isAppleMusicConnected()} />
          ) : (
            <SpotifyPlayer player={spotifyPlayer} spotifyToken={spotifyToken} />
          )}
        </div>
      )}

      <div className="mt-auto pt-6 pb-safe">
        {saving && (
          <div className="flex justify-center mb-2 animate-pulse" aria-live="polite">
            <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
          </div>
        )}
        {runStatus === 'active' ? (
          <div className="flex gap-3">
            <Button onClick={handlePause} disabled={saving} variant="outline" size="lg" className="flex-1 rounded-xl">
              <Pause className="w-5 h-5 mr-2" /> Pause
            </Button>
            <Button onClick={handleStop} disabled={saving} variant="destructive" size="lg" className="flex-1 rounded-xl">
              <Square className="w-5 h-5 mr-2" /> End Run
            </Button>
          </div>
        ) : (
          <div className="!flex !gap-3">
            <Button onClick={handleResume} disabled={saving} size="lg" className="flex-1 rounded-xl">
              <Play className="w-5 h-5 mr-2" /> Resume
            </Button>
            <Button onClick={handleStop} disabled={saving} variant="destructive" size="lg" className="flex-1 rounded-xl">
              <Square className="w-5 h-5 mr-2" /> End Run
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}