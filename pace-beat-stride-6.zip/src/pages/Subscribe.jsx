import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSubscription } from '@/hooks/useSubscription';
import { useAuth } from '@/lib/AuthContext';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { MapPin, Activity, Headphones, Music, Check, Loader2, AlertCircle, LogIn, Gift, Smartphone } from 'lucide-react';
import { isNativeIOS } from '@/lib/native';

const FEATURES = [
  { icon: MapPin, title: "Terrain-Adaptive Playlists", desc: "Music matched to your route's elevation and pace" },
  { icon: Activity, title: "Live Run Tracking", desc: "Real-time pace sync with BPM-matched music" },
  { icon: Headphones, title: "Spotify Export", desc: "Send playlists directly to your Spotify library" },
  { icon: Music, title: "AI-Generated Music", desc: "Personalised tracks based on your taste" },
];

export default function Subscribe() {
  const { subscription, isLoading, isSubscribed, isPending, startCheckout, checkoutError } = useSubscription();
  const { user, navigateToLogin } = useAuth();
  const [checkingOut, setCheckingOut] = useState(false);

  const isAuthError = /authentication required|unauthorized|expired/i.test(checkoutError || '');
  // Apple guideline 3.1.1: digital-feature subscriptions inside the iOS build
  // must use Apple In-App Purchase. Until an IAP product is set up, the native
  // build shows a notice instead of taking a non-Apple payment in-app.
  const nativeIOS = isNativeIOS();

  const handleSubscribe = async () => {
    if (!user) { navigateToLogin(); return; }
    setCheckingOut(true);
    await startCheckout();
    setCheckingOut(false);
  };

  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [promoCode, setPromoCode] = useState('');
  const [redeeming, setRedeeming] = useState(false);
  const [promoError, setPromoError] = useState(null);
  const [promoSuccess, setPromoSuccess] = useState(false);
  const [promoGrant, setPromoGrant] = useState(null);

  const handleRedeem = async () => {
    setPromoError(null);
    setPromoSuccess(false);
    if (!user) { navigateToLogin(); return; }
    if (!promoCode.trim()) return;
    setRedeeming(true);
    try {
      const res = await base44.functions.invoke('redeem-promo', { code: promoCode.trim() });
      setPromoGrant(res.data?.grant || 'free');
      setPromoSuccess(true);
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      setTimeout(() => navigate('/'), 1200);
    } catch (err) {
      setPromoError(err?.response?.data?.error || 'Failed to redeem promo code.');
    } finally {
      setRedeeming(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-green-950 dark:via-emerald-950 dark:to-teal-950 p-4 flex items-center justify-center" style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-lg"
      >
        <Card className="border-green-200 dark:border-green-800 shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-8 text-center text-white">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring' }}
              className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4"
            >
              <Music className="w-8 h-8" />
            </motion.div>
            <h1 className="text-3xl font-heading font-bold">RunSync Premium</h1>
            <p className="text-green-100 mt-1">Your runs, perfectly scored</p>
          </div>

          <CardContent className="p-8 space-y-6">
            {/* Status banner */}
            {isPending && (
              <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg p-4 flex items-center gap-3">
                <Loader2 className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 animate-spin" />
                <div>
                  <p className="text-sm font-medium text-amber-900 dark:text-amber-200">Payment confirming...</p>
                  <p className="text-sm text-amber-700 dark:text-amber-400">Your subscription is being activated</p>
                </div>
              </div>
            )}
            {isSubscribed && (
              <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4 flex items-center gap-3">
                <Check className="w-5 h-5 text-green-600 dark:text-green-400 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-green-900 dark:text-green-200">You're subscribed!</p>
                  <p className="text-sm text-green-700 dark:text-green-400">You have full access to RunSync</p>
                </div>
              </div>
            )}

            {/* Features */}
            <div className="space-y-3">
              {FEATURES.map((feature, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 * (i + 1) }}
                  className="flex items-start gap-3"
                >
                  <div className="w-9 h-9 rounded-lg bg-green-100 dark:bg-green-900 flex items-center justify-center shrink-0">
                    <feature.icon className="w-4.5 h-4.5 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{feature.title}</p>
                    <p className="text-sm text-muted-foreground">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Price */}
            <div className="text-center py-4 border-y border-border">
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-4xl font-heading font-bold">£2.00</span>
                <span className="text-muted-foreground">/month</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Cancel anytime</p>
            </div>

            {/* Error */}
            {checkoutError && (
              <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-3 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-red-700 dark:text-red-400">{isAuthError ? 'Your session has expired. Please log in to subscribe.' : checkoutError}</p>
                  {isAuthError && (
                    <Button size="sm" onClick={navigateToLogin} className="mt-2 h-8 text-sm bg-green-600 hover:bg-green-700">
                      <LogIn className="w-3.5 h-3.5 mr-1" /> Log in
                    </Button>
                  )}
                </div>
              </div>
            )}

            {/* CTA */}
            {!isSubscribed && nativeIOS && (
              <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg p-4 text-center">
                <Smartphone className="w-5 h-5 text-amber-600 dark:text-amber-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-amber-900 dark:text-amber-200">Subscribe on the web</p>
                <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                  To comply with Apple's App Store rules, subscriptions are purchased in your browser.
                  Visit pace-beat-stride.base44.app, sign in with the same account, and your premium
                  access unlocks here automatically.
                </p>
              </div>
            )}
            {!isSubscribed && !nativeIOS && (
              <Button
                onClick={handleSubscribe}
                disabled={checkingOut}
                className="w-full bg-green-600 hover:bg-green-700 text-white h-12 text-base font-medium"
              >
                {checkingOut ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Redirecting to checkout...
                  </>
                ) : !user ? (
                  <>
                    <LogIn className="w-4 h-4 mr-2" /> Log in to Subscribe
                  </>
                ) : (
                  'Subscribe Now'
                )}
              </Button>
            )}

            {isSubscribed && (
              <Link to="/">
                <Button className="w-full bg-green-600 hover:bg-green-700 text-white h-12">
                  Go to Dashboard
                </Button>
              </Link>
            )}

            {/* Promo code */}
            <div className="pt-4 border-t border-border">
              <div className="flex items-center gap-2 mb-2">
                <Gift className="w-4 h-4 text-primary" />
                <p className="text-sm font-medium">Have a promo code?</p>
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter promo code"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={handleRedeem} disabled={redeeming || !promoCode.trim()} variant="secondary" className="shrink-0">
                  {redeeming ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Redeem'}
                </Button>
              </div>
              {promoError && <p className="text-sm text-red-600 dark:text-red-400 mt-2">{promoError}</p>}
              {promoSuccess && (
                <p className="text-sm text-green-600 dark:text-green-400 mt-2">
                  {promoGrant === 'trial'
                    ? 'Promo applied — enjoy one free month of premium!'
                    : 'Promo applied — you have free access!'}
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-muted-foreground mt-4">
          By subscribing, you agree to be charged £2.00/month until cancelled.
        </p>
        <p className="text-center text-xs text-muted-foreground mt-2">
          <Link to="/privacy" className="underline">Privacy Policy</Link>
          {' · '}
          <Link to="/terms" className="underline">Terms of Service</Link>
        </p>
      </motion.div>
    </div>
  );
}