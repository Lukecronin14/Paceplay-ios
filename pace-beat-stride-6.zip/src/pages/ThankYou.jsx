import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Loader2, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ThankYou() {
  const navigate = useNavigate();

  const { data: subscription } = useQuery({
    queryKey: ['subscription'],
    queryFn: async () => {
      const list = await base44.entities.Subscription.list();
      return list[0] || null;
    },
    refetchInterval: (query) => {
      if (query.state.data?.status === 'active') return false;
      return 2000;
    },
  });

  const isActive = subscription?.status === 'active';

  useEffect(() => {
    if (isActive) {
      const timer = setTimeout(() => navigate('/'), 2000);
      return () => clearTimeout(timer);
    }
  }, [isActive, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-100 dark:from-green-950 dark:to-emerald-950 p-4" style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center space-y-4"
      >
        {isActive ? (
          <>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', delay: 0.1 }}
            >
              <CheckCircle2 className="w-16 h-16 text-green-600 dark:text-green-400 mx-auto" />
            </motion.div>
            <h1 className="text-2xl font-heading font-bold text-green-900 dark:text-green-200">Subscription Active!</h1>
            <p className="text-green-700 dark:text-green-400">Redirecting you to your dashboard...</p>
          </>
        ) : (
          <>
            <Loader2 className="w-16 h-16 text-green-600 dark:text-green-400 mx-auto animate-spin" />
            <h1 className="text-2xl font-heading font-bold text-green-900 dark:text-green-200">Confirming your payment...</h1>
            <p className="text-green-700 dark:text-green-400">This will only take a moment. Don't close this page.</p>
          </>
        )}
      </motion.div>
    </div>
  );
}