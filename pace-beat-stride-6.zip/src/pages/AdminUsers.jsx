import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import ResponsiveSelect from '@/components/common/ResponsiveSelect';
import { UserPlus, Users, Loader2, Mail, Shield, Gift } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminUsers() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('user');
  const [inviting, setInviting] = useState(false);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: subscriptions = [] } = useQuery({
    queryKey: ['subscriptions'],
    queryFn: () => base44.entities.Subscription.list(),
    initialData: [],
  });

  const subByUser = {};
  subscriptions.forEach((s) => {
    if (s.created_by_id) subByUser[s.created_by_id] = s;
  });

  const accessMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Subscription.update(id, { status }),
    onSuccess: (_data, vars) => {
      queryClient.invalidateQueries({ queryKey: ['subscriptions'] });
      toast.success(vars.status === 'free' ? 'Free access granted' : 'Free access revoked');
    },
    onError: (err) => toast.error(err?.message || 'Failed to update access'),
  });

  if (user && user.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  const handleInvite = async (e) => {
    e.preventDefault();
    if (!email) return;
    setInviting(true);
    try {
      await base44.users.inviteUser(email.trim(), role);
      toast.success(`Invitation sent to ${email.trim()}`);
      setEmail('');
      queryClient.invalidateQueries({ queryKey: ['users'] });
    } catch (err) {
      toast.error(err?.message || 'Failed to send invitation');
    } finally {
      setInviting(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-10 max-w-3xl mx-auto">
      <div className="flex items-center gap-2 mb-2">
        <Users className="w-5 h-5 text-primary" />
        <h1 className="font-heading text-2xl sm:text-3xl font-bold">Manage Users</h1>
      </div>
      <p className="text-sm text-muted-foreground mb-6">
        Invite new users to PacePlay. They'll receive an email to create their account. You can also grant free access to testers, friends, or family from the list below.
      </p>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <UserPlus className="w-4 h-4" /> Invite a User
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleInvite} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="invite-email">Email address</Label>
              <Input
                id="invite-email"
                type="email"
                placeholder="runner@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="rounded-xl"
              />
            </div>
            <div className="space-y-2">
              <Label>Role</Label>
              <ResponsiveSelect
                value={role}
                onChange={setRole}
                title="Role"
                options={[
                  { value: 'user', label: 'User — Standard access' },
                  { value: 'admin', label: 'Admin — Manage users' },
                ]}
              />
            </div>
            <Button type="submit" disabled={inviting || !email} className="w-full rounded-xl">
              {inviting ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending invite...</>
              ) : (
                <><Mail className="w-4 h-4 mr-2" /> Send Invitation</>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      <div>
        <h2 className="font-heading font-bold text-lg mb-3">All Users ({users.length})</h2>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-2">
            {users.map((u) => {
              const sub = subByUser[u.id];
              const isFree = sub?.status === 'free';
              const isPaid = sub?.status === 'active';
              return (
                <div key={u.id} className="bg-card border border-border rounded-xl p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-medium truncate">{u.full_name || u.email}</p>
                      {u.full_name && <p className="text-xs text-muted-foreground truncate">{u.email}</p>}
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {u.role === 'admin' && <Shield className="w-4 h-4 text-primary" />}
                      <Badge variant={u.role === 'admin' ? 'default' : 'secondary'}>
                        {u.role || 'user'}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                    <span className="text-sm text-muted-foreground">
                      {sub ? `Subscription: ${sub.status}` : 'No subscription yet'}
                    </span>
                    {sub && !isPaid && (
                      <Button
                        size="sm"
                        variant={isFree ? 'outline' : 'secondary'}
                        className="h-7 text-sm rounded-lg"
                        disabled={accessMutation.isPending}
                        onClick={() => accessMutation.mutate({ id: sub.id, status: isFree ? 'expired' : 'free' })}
                      >
                        <Gift className="w-3 h-3 mr-1" />
                        {isFree ? 'Revoke free access' : 'Grant free access'}
                      </Button>
                    )}
                    {isPaid && <Badge variant="default" className="text-xs">Paying</Badge>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}