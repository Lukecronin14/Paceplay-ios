import React, { useEffect, useState } from 'react';
import { useNavigate, useParams, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Footprints } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { isAnyMusicConnected } from '@/lib/musicService';
import { useAuth } from '@/lib/AuthContext';
import WelcomeStep from '@/components/onboarding/WelcomeStep';
import ConnectMusicStep from '@/components/onboarding/ConnectMusicStep';
import ReadyStep from '@/components/onboarding/ReadyStep';

const STEPS = ['Welcome', 'Music', 'Ready'];
// URL-synced wizard steps: the browser/hardware back button steps backward
// through the wizard instead of exiting the app.
const STEP_PATHS = ['welcome', 'music', 'ready'];

export default function Onboarding() {
  const navigate = useNavigate();
  const { step: stepParam } = useParams();
  const { user, isLoadingAuth, checkUserAuth } = useAuth();
  const [musicConnected, setMusicConnected] = useState(() => isAnyMusicConnected());
  const [finishing, setFinishing] = useState(false);

  const step = STEP_PATHS.indexOf(stepParam ?? 'welcome');

  const goToStep = (index) => navigate(`/onboarding/${STEP_PATHS[index]}`);

  // The wizard needs a signed-in account (connecting services) — otherwise go to
  // the login page instead of silently bouncing back to Home
  useEffect(() => {
    if (!isLoadingAuth && !user) base44.auth.redirectToLogin();
  }, [isLoadingAuth, user]);

  const finish = async (destination = '/') => {
    if (finishing) return;
    setFinishing(true);
    try {
      await base44.auth.updateMe({ onboarding_completed_at: new Date().toISOString() });
      // Refresh the in-session user so Home's setup prompt doesn't reappear
      await checkUserAuth();
    } catch (err) {
      console.error('Failed to save onboarding completion:', err);
    }
    navigate(destination);
  };

  if (step === -1) {
    return <Navigate to="/onboarding/welcome" replace />;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header
        className="px-4 sm:px-6 flex items-center justify-between w-full max-w-xl mx-auto"
        style={{ paddingTop: 'calc(env(safe-area-inset-top) + 1rem)' }}
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center">
            <Footprints className="w-4 h-4" />
          </div>
          <span className="font-heading font-bold">PacePlay</span>
        </div>
        <button
          type="button"
          onClick={() => finish('/')}
          className="h-11 px-3 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Skip setup
        </button>
      </header>

      <div className="px-4 sm:px-6 w-full max-w-xl mx-auto mt-4">
        <div className="flex items-center gap-2">
          {STEPS.map((label, i) => (
            <div key={label} className="flex-1">
              <div className={`h-1.5 rounded-full transition-colors ${i <= step ? 'bg-primary' : 'bg-muted'}`} aria-label={label} />
            </div>
          ))}
        </div>
      </div>

      <main className="flex-1 flex items-center justify-center px-4 sm:px-6 py-8 w-full max-w-xl mx-auto">
        <div className="w-full">
          <AnimatePresence mode="wait">
            {step === 0 && (
              <motion.div key="welcome" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
                <WelcomeStep onStart={() => goToStep(1)} />
              </motion.div>
            )}
            {step === 1 && (
              <motion.div key="music" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
                <ConnectMusicStep
                  musicConnected={musicConnected}
                  onConnectionsChange={setMusicConnected}
                  onContinue={() => goToStep(2)}
                  onSkip={() => goToStep(2)}
                />
              </motion.div>
            )}
            {step === 2 && (
              <motion.div key="ready" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
                <ReadyStep onFinish={finish} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}