/**
 * Pure MusicKit developer-token minting (ES256 / .p8).
 *
 * No secrets are read here — the apple-music-token backend function supplies
 * key material from the platform secrets and never logs or returns it. Pure
 * so it can be unit-tested in vitest without secrets or network access.
 */

export function normalizeP8Key(raw) {
  return String(raw || '')
    .replace(/\\n/g, '\n')
    .replace(/-----BEGIN[^-]*-----/g, '')
    .replace(/-----END[^-]*-----/g, '')
    .replace(/\s+/g, '')
    .replace(/^["']+|["']+$/g, '');
}

function isPlausibleP8Body(body) {
  return /^[A-Za-z0-9+/]+={0,2}$/.test(body) && body.length >= 100;
}

function base64Url(bytes) {
  let binary = '';
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/**
 * Mints a MusicKit developer token. Returns { token, iat, exp, expiresIn }.
 * Throws Error('INVALID_KEY') for unusable key material.
 */
export async function mintDeveloperToken({ privateKeyPem, keyId, teamId }, nowMs = Date.now()) {
  const pemBody = normalizeP8Key(privateKeyPem);
  if (!pemBody || !isPlausibleP8Body(pemBody)) {
    throw new Error('INVALID_KEY');
  }

  const der = Uint8Array.from(atob(pemBody), (c) => c.charCodeAt(0));

  let key;
  try {
    key = await crypto.subtle.importKey(
      'pkcs8',
      der,
      { name: 'ECDSA', namedCurve: 'P-256' },
      false,
      ['sign']
    );
  } catch {
    throw new Error('INVALID_KEY');
  }

  const iat = Math.floor(nowMs / 1000);
  const exp = iat + 60 * 60 * 24 * 30; // 30 days

  const header = base64Url(new TextEncoder().encode(JSON.stringify({ alg: 'ES256', kid: keyId })));
  const payload = base64Url(new TextEncoder().encode(JSON.stringify({ iss: teamId, iat, exp })));
  const signingInput = `${header}.${payload}`;

  const signature = await crypto.subtle.sign(
    { name: 'ECDSA', hash: 'SHA-256' },
    key,
    new TextEncoder().encode(signingInput)
  );

  return {
    token: `${signingInput}.${base64Url(new Uint8Array(signature))}`,
    iat,
    exp,
    expiresIn: exp - iat,
  };
}