/**
 * Server-side premium entitlement check — single source of truth for backend
 * functions. Mirrors the client rules in src/lib/subscriptionAccess.js
 * (same statuses, same trial-expiry semantics) so the UI and the server agree.
 *
 * Premium access comes ONLY from:
 *  - "active" (set exclusively by the JWT-verified payments webhook)
 *  - "free" (a granted free entitlement)
 *  - "trial" with a future trial_end_date
 *  - admins (consistent with the UI's authorizedForPath)
 * "pending" / "canceled" / "expired" / no record grant nothing.
 */

/**
 * Pick the authoritative subscription record when a user has more than one
 * (paid outranks trial; among trials, the latest-ending wins). Mirrors the
 * client copy exactly.
 */
export function pickSubscriptionRecord(records) {
  if (!Array.isArray(records) || records.length === 0) return null;
  const active = records.find((r) => r?.status === 'active');
  if (active) return active;
  const nonTrial = records.find((r) => r?.status && r.status !== 'trial');
  if (nonTrial) return nonTrial;
  const trials = records.filter((r) => r?.status === 'trial');
  if (trials.length > 0) {
    return trials.reduce((a, b) =>
      new Date(b.trial_end_date || 0) > new Date(a.trial_end_date || 0) ? b : a
    );
  }
  return records[0];
}

/** Pure verdict for one subscription record. Deterministic, timestamp-injected. */
export function hasPremiumAccess(sub, now = new Date()) {
  const status = sub?.status || null;
  if (status === 'active' || status === 'free') return true;
  if (status === 'trial') {
    const trialEnd = sub?.trial_end_date ? new Date(sub.trial_end_date) : null;
    return trialEnd != null && !Number.isNaN(trialEnd.getTime()) && trialEnd > now;
  }
  return false;
}

/**
 * I/O helper used by guarded backend functions: verifies the AUTHENTICATED
 * user's own entitlement from the server-side Subscription records.
 * Never trusts request input; identity comes from the session.
 */
export async function requirePremiumAccess(base44, user, now = new Date()) {
  if (!user) return false;
  if (user.role === 'admin') return true;
  const subs = await base44.asServiceRole.entities.Subscription.filter({
    created_by_id: user.id,
  });
  return hasPremiumAccess(pickSubscriptionRecord(subs), now);
}

/** Standard 403 response for guarded premium operations. */
export function premiumRequiredResponse() {
  return Response.json({ error: 'Premium subscription required' }, { status: 403 });
}