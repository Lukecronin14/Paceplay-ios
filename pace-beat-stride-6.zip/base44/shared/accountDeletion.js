/**
 * Pure account-deletion plan: every user-owned data entity and the exact
 * filter that scopes its deletion to one authenticated user.
 *
 * Kept pure (no I/O, no SDK) so vitest can verify the plan covers all
 * personal data, is scoped per user, and never touches shared catalog data.
 *
 * NOTE (reported limitation): deleting these records erases app data but does
 * NOT cancel a Wix-side billing subscription, and does not delete the Base44
 * sign-in account itself — both are handled outside this flow.
 */

// Entities owned by an individual user. 'ParkRun' (shared catalog) is
// deliberately absent. IntegrationSecret is scoped by its `user_id` field;
// every other entity by `created_by_id`.
export const USER_OWNED_ENTITIES = [
  'LiveRun',
  'RunPlan',
  'MusicPreference',
  'HealthRun',
  'Subscription',
  'IntegrationSecret',
];

export function buildDeletionPlan(userId) {
  if (!userId) throw new Error('userId is required');
  return [
    { entity: 'LiveRun', filter: { created_by_id: userId } },
    { entity: 'RunPlan', filter: { created_by_id: userId } },
    { entity: 'MusicPreference', filter: { created_by_id: userId } },
    { entity: 'HealthRun', filter: { created_by_id: userId } },
    { entity: 'Subscription', filter: { created_by_id: userId } },
    { entity: 'IntegrationSecret', filter: { user_id: userId } },
  ];
}

// Credential fields on the user record to clear at deletion.
export const USER_FIELDS_TO_CLEAR = {
  spotify_connected: false,
  spotify_token: null,
  spotify_profile: null,
  strava_connected: false,
  strava_token: null,
  apple_music_connected: false,
  apple_music_token: null,
};