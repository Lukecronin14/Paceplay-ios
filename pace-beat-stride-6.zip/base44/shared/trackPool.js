// Pure validation for the generate-track-pool backend function.
// No I/O — importable both by the Deno function and by Node unit tests.

const MAX_PROMPT_LENGTH = 30000;
const MAX_DISTANCE_KM = 50;

export function validateTrackPoolRequest(body) {
  if (!body || typeof body !== 'object') {
    return 'Invalid request body';
  }
  const { prompt, distance_km, response_json_schema } = body;

  if (typeof prompt !== 'string' || prompt.trim().length === 0) {
    return 'A prompt is required';
  }
  if (prompt.length > MAX_PROMPT_LENGTH) {
    return `Prompt too long (max ${MAX_PROMPT_LENGTH} characters)`;
  }

  if (typeof distance_km !== 'number' || !isFinite(distance_km) || distance_km <= 0) {
    return 'A positive distance_km is required';
  }
  if (distance_km > MAX_DISTANCE_KM) {
    return `Distance exceeds the ${MAX_DISTANCE_KM} km generation limit`;
  }

  if (
    response_json_schema !== undefined &&
    (typeof response_json_schema !== 'object' ||
      response_json_schema === null ||
      Array.isArray(response_json_schema))
  ) {
    return 'response_json_schema must be an object';
  }

  return null;
}