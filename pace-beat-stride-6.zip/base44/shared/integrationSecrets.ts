// Server-side vault for long-lived OAuth refresh tokens (Spotify, Strava).
// The IntegrationSecret entity is admin-RLS-locked, so the browser can never read
// or write these records — everything goes through backend functions using the
// service role, scoped to the calling user.

export async function getSecret(base44, userId, service) {
  const found = await base44.asServiceRole.entities.IntegrationSecret.filter({
    user_id: userId,
    service,
  });
  return found && found.length > 0 ? found[0] : null;
}

export async function upsertSecret(base44, userId, service, refreshToken) {
  const existing = await getSecret(base44, userId, service);
  if (existing) {
    await base44.asServiceRole.entities.IntegrationSecret.update(existing.id, {
      refresh_token: refreshToken,
    });
  } else {
    await base44.asServiceRole.entities.IntegrationSecret.create({
      user_id: userId,
      service,
      refresh_token: refreshToken,
    });
  }
}

export async function deleteSecret(base44, userId, service) {
  await base44.asServiceRole.entities.IntegrationSecret.deleteMany({
    user_id: userId,
    service,
  });
}