/**
 * Persistent sliding-window rate limiting (pure logic + thin entity adapter).
 *
 * Enforces: at most RATE_LIMIT_MAX successful mints per user+service in any
 * RATE_LIMIT_WINDOW_MS window, across separate backend invocations, backed by
 * RateLimitHit records (admin-only RLS — users cannot read or manipulate
 * their counters; the user id always comes from the authenticated session).
 *
 * Concurrency guarantee (converge-on-commit): a request pre-checks the
 * in-window count, mints, then records its slot and re-counts. A request
 * whose re-count observes more than RATE_LIMIT_MAX in-window records
 * withdraws its own slot and is denied. Since every request that records a
 * slot re-counts afterwards, the final state can never exceed the cap: the
 * last re-count to observe an over-cap state necessarily withdraws a slot.
 * Only requests whose re-count showed <= cap receive a token, so DELIVERED
 * tokens are capped too. The cost of the race is bounded on the safe side:
 * occasional wasted mints and conservative (over-strict) denials — never
 * over-admission.
 *
 * Failed authentication never reaches this module; failed token generation
 * never records a slot. Stored data is minimal: user id, service, timestamp,
 * nonce — expired slots are pruned on every acquire.
 */

export const RATE_LIMIT_MAX = 10;
export const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000;

export function windowStartFor(now) {
  return now - RATE_LIMIT_WINDOW_MS;
}

export function countInWindow(hits, now) {
  const start = windowStartFor(now);
  return (hits || []).filter((h) => h.t >= start).length;
}

export function makeNonce() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return 'n' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

/**
 * In-window record count. Uses filter (not the count() helper): the
 * service-role entity client inside backend functions does not expose count.
 * Slot counts per user are tiny (bounded by the cap + race), so one filter
 * call is cheap.
 */
async function countRecords(entity, query) {
  const records = await entity.filter(query);
  const items = Array.isArray(records) ? records : records.items;
  return (items || []).length;
}

/**
 * Pre-check + reserve a candidate slot (not yet recorded).
 * Returns { allowed: true, slot } or { allowed: false }.
 */
export async function acquireMintSlot(entity, userId, service, now) {
  const start = windowStartFor(now);
  // Best-effort prune of expired slots — keeps stored data minimal.
  await entity.deleteMany({ user_id: userId, service, t: { $lt: start } });
  const inWindow = await countRecords(entity, { user_id: userId, service, t: { $gte: start } });
  if (inWindow >= RATE_LIMIT_MAX) return { allowed: false };
  return { allowed: true, slot: { t: now, n: makeNonce() } };
}

/**
 * Record the slot after a SUCCESSFUL mint and verify the cap. Returns false
 * (and withdraws the slot) when concurrent requests pushed the in-window
 * count over the cap — the caller must then deny the request.
 */
export async function confirmSlot(entity, userId, service, slot, now) {
  const start = windowStartFor(now);
  await entity.create({ user_id: userId, service, t: slot.t, n: slot.n });
  const inWindow = await countRecords(entity, { user_id: userId, service, t: { $gte: start } });
  if (inWindow > RATE_LIMIT_MAX) {
    await entity.deleteMany({ user_id: userId, service, n: slot.n });
    return false;
  }
  return true;
}