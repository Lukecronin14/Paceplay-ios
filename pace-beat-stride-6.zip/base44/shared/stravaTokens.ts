// Shared Strava token helpers for backend functions.
//
// Strava rotates the refresh token on every refresh. Two concurrent refreshes
// (different tabs, useTokenRefresh in the background, the 401-retry inside an
// action) would invalidate one of the stored tokens and silently disconnect
// the user — the classic "profile won't load anymore" bug. Every refresh goes
// through this single-flight lock, keyed per user.
import { getSecret, upsertSecret } from './integrationSecrets.ts';

const STRAVA_TOKEN_URL = 'https://www.strava.com/oauth/token';

const inFlight = new Map<string, Promise<any>>();

export async function refreshStravaToken(base44, userId, clientId, clientSecret) {
  const existing = inFlight.get(userId);
  if (existing) return existing;
  const promise = (async () => {
    const secret = await getSecret(base44, userId, 'strava');
    if (!secret) return { ok: false, reason: 'not_connected' };
    try {
      const res = await fetch(STRAVA_TOKEN_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id: clientId,
          client_secret: clientSecret,
          refresh_token: secret.refresh_token,
          grant_type: 'refresh_token',
        }),
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) {
        const errText = await res.text();
        console.error('Strava token refresh failed:', res.status, errText);
        // 400/401 from the token endpoint means the stored refresh token is
        // gone or revoked — the user must reconnect. Anything else is transient.
        return { ok: false, reason: res.status === 400 || res.status === 401 ? 'reconnect' : 'transient' };
      }
      const fresh = await res.json();
      await upsertSecret(base44, userId, 'strava', fresh.refresh_token);
      return { ok: true, accessToken: fresh.access_token, expiresAt: fresh.expires_at };
    } catch (err) {
      console.error('Strava token refresh error:', err);
      return { ok: false, reason: 'transient' };
    }
  })();
  inFlight.set(userId, promise);
  try {
    return await promise;
  } finally {
    inFlight.delete(userId);
  }
}

// Returns a usable access token: passes the caller's through when it is still
// fresh, otherwise refreshes server-side (under the single-flight lock).
export async function getValidAccessToken(base44, userId, accessToken, expiresAt, clientId, clientSecret) {
  const expired = !accessToken || (expiresAt && Date.now() / 1000 > Number(expiresAt) - 60);
  if (!expired) return { ok: true, accessToken, refreshed: false };
  const refreshed = await refreshStravaToken(base44, userId, clientId, clientSecret);
  if (refreshed.ok) {
    return { ok: true, accessToken: refreshed.accessToken, expiresAt: refreshed.expiresAt, refreshed: true };
  }
  return refreshed;
}

// fetch with a single 429 retry honoring Retry-After (capped at 5s) — Strava
// rate-limits bursty pages, and a swallowed 429 shows up as "profile won't load".
export async function stravaFetch(url, token, options = {}) {
  const call = () => fetch(url, {
    ...options,
    headers: { ...(options.headers || {}), Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(15000),
  });
  const res = await call();
  if (res.status !== 429) return res;
  const retryAfterSec = Math.min(Number(res.headers.get('retry-after') || 1), 5);
  await new Promise((r) => setTimeout(r, retryAfterSec * 1000));
  return call();
}