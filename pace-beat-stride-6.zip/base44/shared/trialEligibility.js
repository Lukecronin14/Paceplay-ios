/**
 * Pure eligibility logic for promo-code trial grants.
 *
 * A prior trial redemption is reliably detectable from stored subscription
 * data alone:
 *   - redeem-promo writes trial_start_date / trial_end_date when it grants a
 *     trial, and never removes them.
 *   - the payments webhook only updates status / subscription_id, so those
 *     dates persist even after a trial converts to a paid subscription.
 * Therefore ANY subscription record for the user that carries trial dates, or
 * whose status is "trial", proves a trial was already redeemed on this
 * account. Nothing client-supplied is consulted.
 *
 * Inconsistent data (status "trial" but no dates) is treated as a prior trial
 * — failing closed is always safe against indefinite extension.
 */

export function hasPriorTrial(subscriptions) {
  if (!Array.isArray(subscriptions)) return false;
  return subscriptions.some(
    (s) =>
      s != null &&
      (s.status === 'trial' ||
        s.trial_start_date != null ||
        s.trial_end_date != null)
  );
}

export function trialEligibility(subscriptions) {
  return hasPriorTrial(subscriptions)
    ? { eligible: false, reason: 'trial_already_redeemed' }
    : { eligible: true };
}