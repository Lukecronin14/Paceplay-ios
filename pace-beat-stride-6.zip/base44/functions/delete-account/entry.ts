import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { buildDeletionPlan, USER_FIELDS_TO_CLEAR } from '../../shared/accountDeletion.js';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    // auth.me() THROWS (rather than returning null) with no valid session —
    // catch it and answer 401 instead of the outer 500.
    let user = null;
    try {
      user = await base44.auth.me();
    } catch {
      user = null;
    }
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const uid = user.id;

    // Delete every user-owned data entity, scoped strictly to this user
    // (the deletion plan lives in shared/accountDeletion.js and is unit-tested).
    // Service role bypasses RLS but every filter is the authenticated user's id,
    // so another user's data can never match.
    const deleted = {};
    for (const step of buildDeletionPlan(uid)) {
      await base44.asServiceRole.entities[step.entity].deleteMany(step.filter);
      deleted[step.entity] = true;
    }

    // Best-effort: clear stored integration credentials on the user record
    // (Spotify, Strava and Apple Music).
    try {
      await base44.asServiceRole.entities.User.update(uid, USER_FIELDS_TO_CLEAR);
    } catch (e) {
      console.error('Failed to clear integration credentials:', e.message);
    }

    return Response.json({
      success: true,
      deleted,
      // Honest limitations, surfaced to the caller:
      // - A Wix-side billing subscription is NOT cancelled by this call.
      // - The sign-in (auth) account itself is not deleted by this flow.
      limitations: ['wix_subscription_not_cancelled', 'auth_account_not_deleted'],
    });
  } catch (error) {
    console.error('delete-account error:', error.message);
    // Return a generic message — internal error details are logged, not echoed.
    return Response.json({ error: 'Unable to delete account' }, { status: 500 });
  }
}