import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { getSecret, upsertSecret, deleteSecret } from '../../shared/integrationSecrets.ts';
import { refreshStravaToken, getValidAccessToken, stravaFetch } from '../../shared/stravaTokens.ts';
import { requirePremiumAccess, premiumRequiredResponse } from '../../shared/subscriptionAccess.js';

const STRAVA_AUTH_URL = 'https://www.strava.com/oauth/authorize';
const STRAVA_TOKEN_URL = 'https://www.strava.com/oauth/token';
const STRAVA_API_URL = 'https://www.strava.com/api/v3';

// All token refreshes go through the server-side single-flight lock in
// shared/stravaTokens.ts, and API reads go through stravaFetch (429 backoff).

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { action, code, redirectUri, accessToken, activityId, expiresAt } = body;

    // Premium gate: these operations are only reachable from subscription-gated
    // UI (route lists/details, terrain prediction, GPX export). Connection,
    // token and athlete-profile actions stay open to free users.
    if (action === 'getActivities' || action === 'getActivity' || action === 'predictRoute' || action === 'uploadGpx') {
      if (!(await requirePremiumAccess(base44, user))) {
        console.log('stravaIntegration: premium required for action', action, 'user', user.id);
        return premiumRequiredResponse();
      }
    }

    const clientId = Deno.env.get('STRAVA_CLIENT_ID');
    const clientSecret = Deno.env.get('STRAVA_CLIENT_SECRET');

    if (!clientId || !clientSecret) {
      return Response.json({ error: 'Strava credentials not configured' }, { status: 500 });
    }

    // Action: Get OAuth URL
    if (action === 'getAuthUrl') {
      const params = new URLSearchParams({
        client_id: clientId,
        response_type: 'code',
        redirect_uri: redirectUri,
        approval_prompt: 'auto',
        scope: 'read,activity:read_all,profile:read_all'
      });
      return Response.json({ authUrl: `${STRAVA_AUTH_URL}?${params.toString()}` });
    }

    // Action: Exchange code for token (refresh token is stored server-side only)
    if (action === 'exchangeToken') {
      const tokenResponse = await fetch(STRAVA_TOKEN_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id: clientId,
          client_secret: clientSecret,
          code,
          grant_type: 'authorization_code',
        }),
        signal: AbortSignal.timeout(10000),
      });

      if (!tokenResponse.ok) {
        const errText = await tokenResponse.text();
        return Response.json({ error: 'Failed to exchange code', details: errText }, { status: 400 });
      }

      const tokenData = await tokenResponse.json();
      if (tokenData.refresh_token) {
        await upsertSecret(base44, user.id, 'strava', tokenData.refresh_token);
      }
      return Response.json({
        accessToken: tokenData.access_token,
        expiresAt: tokenData.expires_at,
      });
    }

    // Action: Refresh the access token using the server-stored refresh token
    if (action === 'refreshAccessToken') {
      const refreshed = await refreshStravaToken(base44, user.id, clientId, clientSecret);
      if (!refreshed.ok) {
        if (refreshed.reason === 'not_connected') {
          return Response.json({ error: 'Strava not connected. Reconnect from the home page.' }, { status: 401 });
        }
        if (refreshed.reason === 'reconnect') {
          return Response.json({ error: 'Strava session expired. Reconnect from the home page.' }, { status: 401 });
        }
        return Response.json({ error: 'Could not refresh the Strava session. Try again shortly.' }, { status: 502 });
      }
      return Response.json({
        accessToken: refreshed.accessToken,
        expiresAt: refreshed.expiresAt,
      });
    }

    // Action: Disconnect Strava (delete the server-stored refresh token)
    if (action === 'disconnect') {
      await deleteSecret(base44, user.id, 'strava');
      return Response.json({ success: true });
    }

    // Action: Get the authenticated athlete's profile
    if (action === 'getAthlete') {
      const guard = await getValidAccessToken(base44, user.id, accessToken, expiresAt, clientId, clientSecret);
      if (!guard.ok) {
        if (guard.reason === 'reconnect' || guard.reason === 'not_connected') {
          return Response.json({ error: 'Strava not connected. Reconnect from the home page.' }, { status: 401 });
        }
        return Response.json({ error: 'Failed to fetch Strava profile' }, { status: 502 });
      }

      let res = await stravaFetch(`${STRAVA_API_URL}/athlete`, guard.accessToken);
      if (!res.ok && res.status === 401) {
        const retry = await refreshStravaToken(base44, user.id, clientId, clientSecret);
        if (retry.ok) {
          res = await stravaFetch(`${STRAVA_API_URL}/athlete`, retry.accessToken);
        }
      }
      if (!res.ok) {
        console.error('Strava athlete fetch failed:', res.status);
        return Response.json({ error: 'Failed to fetch Strava profile' }, { status: 400 });
      }

      const a = await res.json();
      return Response.json({
        ...(guard.refreshed ? { accessToken: guard.accessToken, expiresAt: guard.expiresAt } : {}),
        profile: {
          id: a.id,
          name: [a.firstname, a.lastname].filter(Boolean).join(' '),
          avatar: a.profile || a.profile_medium || null,
          city: a.city || null,
          country: a.country || null,
        },
      });
    }

    // Action: Get recent activities (runs only)
    if (action === 'getActivities') {
      if (!accessToken) return Response.json({ error: 'Access token required' }, { status: 400 });

      const listActivities = async (token: string) =>
        stravaFetch(`${STRAVA_API_URL}/athlete/activities?per_page=30`, token);

      // Refresh up front if expired — the shared lock prevents concurrent
      // refreshes from rotating the refresh token into invalidation.
      const guard = await getValidAccessToken(base44, user.id, accessToken, expiresAt, clientId, clientSecret);
      if (!guard.ok) {
        if (guard.reason === 'reconnect' || guard.reason === 'not_connected') {
          return Response.json({ error: 'Strava session expired. Reconnect from the home page.' }, { status: 401 });
        }
        return Response.json({ error: 'Failed to refresh Strava session' }, { status: 502 });
      }

      let res = await listActivities(guard.accessToken);
      let refreshed = guard.refreshed
        ? { accessToken: guard.accessToken, expiresAt: guard.expiresAt }
        : null;

      // Token invalidated anyway (revoked elsewhere) — one locked refresh + retry.
      if (!res.ok && res.status === 401) {
        const retry = await refreshStravaToken(base44, user.id, clientId, clientSecret);
        if (retry.ok) {
          refreshed = { accessToken: retry.accessToken, expiresAt: retry.expiresAt };
          res = await listActivities(retry.accessToken);
        }
      }

      if (!res.ok) {
        console.error('Strava activities fetch failed:', res.status);
        return Response.json({ error: 'Failed to fetch activities' }, { status: 400 });
      }

      const activities = await res.json();
      // Strava deprecated the `type` field: newer activities (and trail/treadmill
      // runs) report `sport_type` instead, sometimes with `type` null. Match on
      // both so real runs never get filtered out.
      const isRunType = (t: any) => ['Run', 'VirtualRun', 'TrailRun', 'TreadmillRun'].includes(t);
      const runs = activities.filter((a: any) => isRunType(a.sport_type) || isRunType(a.type));

      return Response.json({
        ...refreshed,
        runs: runs.map((a: any) => ({
          id: a.id,
          name: a.name,
          type: a.type,
          distance: a.distance,
          movingTime: a.moving_time,
          elapsedTime: a.elapsed_time,
          startDate: a.start_date,
          averageSpeed: a.average_speed,
          totalElevationGain: a.total_elevation_gain,
          polyline: a.map?.summary_polyline || null,
          startLatlng: a.start_latlng,
        }))
      });
    }

    // Action: Get single activity with detailed splits
    if (action === 'getActivity') {
      if (!accessToken || !activityId) return Response.json({ error: 'Access token and activity ID required' }, { status: 400 });

      const guard = await getValidAccessToken(base44, user.id, accessToken, expiresAt, clientId, clientSecret);
      if (!guard.ok) {
        if (guard.reason === 'reconnect' || guard.reason === 'not_connected') {
          return Response.json({ error: 'Strava session expired. Reconnect from the home page.' }, { status: 401 });
        }
        return Response.json({ error: 'Failed to refresh Strava session' }, { status: 502 });
      }

      let res = await stravaFetch(`${STRAVA_API_URL}/activities/${activityId}`, guard.accessToken);
      if (!res.ok && res.status === 401) {
        const retry = await refreshStravaToken(base44, user.id, clientId, clientSecret);
        if (retry.ok) {
          res = await stravaFetch(`${STRAVA_API_URL}/activities/${activityId}`, retry.accessToken);
        }
      }
      if (!res.ok) {
        console.error('Strava activity fetch failed:', res.status);
        return Response.json({ error: 'Failed to fetch activity' }, { status: 400 });
      }

      const a = await res.json();

      return Response.json({
        id: a.id,
        name: a.name,
        type: a.type,
        distance: a.distance,
        movingTime: a.moving_time,
        elapsedTime: a.elapsed_time,
        startDate: a.start_date,
        averageSpeed: a.average_speed,
        maxSpeed: a.max_speed,
        totalElevationGain: a.total_elevation_gain,
        elevationHigh: a.elev_high,
        elevationLow: a.elev_low,
        polyline: a.map?.polyline || a.map?.summary_polyline || null,
        startLatlng: a.start_latlng,
        splits: (a.splits_metric || []).map((s: any) => ({
          distance: s.distance,
          movingTime: s.moving_time,
          elapsedTime: s.elapsed_time,
          elevationDifference: s.elevation_difference,
          averageSpeed: s.average_speed,
          averageGrade: s.average_grade,
        })),
      });
    }

    // Action: Predict route terrain from recent runs
    if (action === 'predictRoute') {
      if (!accessToken) return Response.json({ error: 'Access token required' }, { status: 400 });

      const { targetDistance } = body;
      if (!targetDistance || targetDistance <= 0) {
        return Response.json({ error: 'targetDistance required' }, { status: 400 });
      }

      // Fetch recent activities
      const activitiesRes = await stravaFetch(`${STRAVA_API_URL}/athlete/activities?per_page=30`, accessToken);
      if (!activitiesRes.ok) return Response.json({ error: 'Failed to fetch activities' }, { status: 400 });

      const activities = await activitiesRes.json();
      const runs = activities.filter((a: any) => a.type === 'Run' || a.type === 'VirtualRun');

      if (runs.length === 0) {
        return Response.json({ prediction: null, message: 'No recent runs found for route prediction' });
      }

      // Pick runs closest to the target distance (within 50% range), prefer most recent
      const targetMeters = targetDistance * 1000;
      const relevantRuns = runs
        .filter((r: any) => r.distance >= targetMeters * 0.5 && r.distance <= targetMeters * 2)
        .slice(0, 5);

      const runsToAnalyze = relevantRuns.length > 0 ? relevantRuns : runs.slice(0, 3);

      // Fetch detailed splits for each
      const perKmGrades: number[][] = [];
      for (const run of runsToAnalyze) {
        const detailRes = await stravaFetch(`${STRAVA_API_URL}/activities/${run.id}`, accessToken);
        if (!detailRes.ok) continue;
        const detail = await detailRes.json();
        const splits = detail.splits_metric || [];
        if (splits.length > 0) {
          perKmGrades.push(splits.map((s: any) => s.average_grade || 0));
        }
      }

      if (perKmGrades.length === 0) {
        return Response.json({ prediction: null, message: 'No split data available from recent runs' });
      }

      // Build a predicted terrain profile for the target distance
      // Average grades across runs, normalised to the target km count
      const targetKm = Math.ceil(targetDistance);
      const prediction: any[] = [];

      for (let km = 1; km <= targetKm; km++) {
        const gradesAtKm: number[] = [];
        for (const grades of perKmGrades) {
          if (km <= grades.length) {
            gradesAtKm.push(grades[km - 1]);
          }
        }
        const avgGrade = gradesAtKm.length > 0
          ? gradesAtKm.reduce((s, g) => s + g, 0) / gradesAtKm.length
          : 0;

        let gradient = 'flat';
        if (avgGrade >= 6) gradient = 'steep_uphill';
        else if (avgGrade >= 2) gradient = 'uphill';
        else if (avgGrade >= 0.5) gradient = 'slight_uphill';
        else if (avgGrade <= -6) gradient = 'steep_downhill';
        else if (avgGrade <= -2) gradient = 'downhill';
        else if (avgGrade <= -0.5) gradient = 'slight_downhill';

        // Pace adjustment: uphill slows you, downhill speeds you up
        let paceAdjustment = 0;
        if (avgGrade >= 6) paceAdjustment = 0.5;
        else if (avgGrade >= 2) paceAdjustment = 0.25;
        else if (avgGrade <= -6) paceAdjustment = -0.3;
        else if (avgGrade <= -2) paceAdjustment = -0.15;

        prediction.push({
          km,
          gradient,
          avg_grade: Math.round(avgGrade * 10) / 10,
          pace_adjustment_min_per_km: paceAdjustment,
          source_runs: gradesAtKm.length,
        });
      }

      // Overall stats
      const totalElevation = prediction.reduce((s: number, p: any) =>
        s + Math.max(0, p.avg_grade * 10), 0);
      const avgGrade = prediction.reduce((s: number, p: any) => s + p.avg_grade, 0) / prediction.length;

      return Response.json({
        prediction,
        summary: {
          avg_grade: Math.round(avgGrade * 10) / 10,
          elevation_gain_m: Math.round(totalElevation),
          terrain_type: avgGrade > 2 ? 'hilly' : avgGrade > 0.5 ? 'undulating' : avgGrade < -0.5 ? 'downhill' : 'flat',
          runs_analyzed: perKmGrades.length,
        },
      });
    }

    // Action: Upload a run's GPS route to Strava as a GPX activity
    if (action === 'uploadGpx') {
      const { name, description, route, startTime } = body;
      if (!accessToken) return Response.json({ error: 'Access token required' }, { status: 400 });
      if (!route || !Array.isArray(route) || route.length < 2) {
        return Response.json({ error: 'Route data required (at least 2 points)' }, { status: 400 });
      }

      const escapeXml = (s: string) => String(s).replace(/[<>&'"]/g, (c) => ({
        '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;'
      }[c]));

      const startISO = startTime
        ? new Date(startTime).toISOString()
        : (route[0]?.t ? new Date(route[0].t).toISOString() : new Date().toISOString());

      let gpx = '<?xml version="1.0" encoding="UTF-8"?>\n';
      gpx += '<gpx version="1.1" creator="PacePlay" xmlns="http://www.topografix.com/GPX/1/1">\n';
      gpx += `  <metadata><name>${escapeXml(name || 'PacePlay Run')}</name><time>${startISO}</time></metadata>\n`;
      gpx += '  <trk>\n';
      gpx += `    <name>${escapeXml(name || 'PacePlay Run')}</name>\n`;
      gpx += '    <trkseg>\n';
      for (const p of route) {
        const t = p.t ? new Date(p.t).toISOString() : startISO;
        gpx += `      <trkpt lat="${p.lat}" lon="${p.lng}"><time>${t}</time></trkpt>\n`;
      }
      gpx += '    </trkseg>\n  </trk>\n</gpx>';

      // Refresh under the shared lock if the token is expired or close to it.
      const guard = await getValidAccessToken(base44, user.id, accessToken, expiresAt, clientId, clientSecret);
      if (!guard.ok) {
        if (guard.reason === 'reconnect' || guard.reason === 'not_connected') {
          return Response.json({ error: 'Strava session expired. Please reconnect Strava from the home page.' }, { status: 401 });
        }
        return Response.json({ error: 'Could not refresh the Strava session' }, { status: 502 });
      }

      const formData = new FormData();
      formData.append('file', new Blob([gpx], { type: 'application/gpx+xml' }), 'paceplay-run.gpx');
      formData.append('data_type', 'gpx');
      formData.append('activity_type', 'run');
      if (name) formData.append('name', name);
      if (description) formData.append('description', description);

      const uploadRes = await stravaFetch(`${STRAVA_API_URL}/uploads`, guard.accessToken, {
        method: 'POST',
        body: formData,
      });

      if (!uploadRes.ok) {
        const errText = await uploadRes.text();
        console.error('Strava upload failed:', uploadRes.status, errText);
        if (uploadRes.status === 401) {
          return Response.json({ error: 'Strava session expired. Please reconnect Strava from the home page.' }, { status: 401 });
        }
        return Response.json({ error: 'Strava upload failed', details: errText }, { status: 400 });
      }

      const uploadData = await uploadRes.json();
      return Response.json({
        uploadId: uploadData.id,
        activityId: uploadData.activity_id,
        status: uploadData.status,
        ...(guard.refreshed ? { accessToken: guard.accessToken, expiresAt: guard.expiresAt } : {}),
      });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    console.error('stravaIntegration error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});