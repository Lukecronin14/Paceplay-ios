import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { requirePremiumAccess, premiumRequiredResponse } from '../../shared/subscriptionAccess.js';
import { validateTrackPoolRequest } from '../../shared/trackPool.js';

// Server-side gate for AI playlist/track-pool generation (Stage C4 Fix 1).
// The client builds the prompt exactly as before; this function authenticates
// the caller, verifies premium entitlement, validates bounds, and only then
// runs the LLM call — so generation can no longer be triggered client-side.

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    // auth.me() THROWS (rather than returning null) when the request has no
    // valid session — catch that and answer 401 instead of the outer 500.
    let user = null;
    try {
      user = await base44.auth.me();
    } catch {
      user = null;
    }
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    // Premium gate: AI generation is a subscription-only feature — verified
    // server-side from the user's own Subscription records.
    if (!(await requirePremiumAccess(base44, user))) {
      console.log('generate-track-pool: premium required for user', user.id);
      return premiumRequiredResponse();
    }

    const body = await req.json().catch(() => null);
    const validationError = validateTrackPoolRequest(body);
    if (validationError) {
      console.log('generate-track-pool: rejected input:', validationError);
      return Response.json({ error: validationError }, { status: 400 });
    }

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: body.prompt,
      response_json_schema: body.response_json_schema,
    });

    return Response.json(result);
  } catch (error) {
    console.error('generate-track-pool error:', error.message);
    return Response.json(
      { error: 'Failed to generate track pool' },
      { status: 500 }
    );
  }
}