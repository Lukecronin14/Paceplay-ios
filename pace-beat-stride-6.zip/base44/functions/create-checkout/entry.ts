import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const WIX_API_KEY = Deno.env.get("WIX_PAYMENTS_API_KEY");
const WIX_SITE_ID = Deno.env.get("WIX_PAYMENTS_SITE_ID");
const WIX_API_URL = "https://www.wixapis.com/payments";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { action } = body;

    // Action: Create a checkout session for £2.00/month subscription
    if (action === "createCheckout") {
      const user = await base44.auth.me();
      if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

      const appUrl = req.headers.get("X-Base44-App-Url") || Deno.env.get("WIX_CHECKOUT_APP_URL") || Deno.env.get("WIX_PAYMENTS_APP_URL");
      if (!appUrl) {
        console.error("Checkout return URL not configured (missing X-Base44-App-Url header and app URL env var)");
        return Response.json({ error: "Checkout return URL not configured" }, { status: 500 });
      }

      const price = "2.00";
      if (parseFloat(price) < 0.50) {
        return Response.json({ error: "Amount must be at least 0.50" }, { status: 400 });
      }

      // Find existing subscription record for this user
      // Trusted backend write path: subscription records are admin-only via RLS,
// so all read/writes here go through the service role. The caller's identity
// comes from their authenticated session, never from request input.
const subs = await base44.asServiceRole.entities.Subscription.filter({ created_by_id: user.id });

      // Create Wix checkout session
      const checkoutRes = await fetch(`${WIX_API_URL}/platform/v1/checkout-sessions/construct`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": WIX_API_KEY,
          "wix-site-id": WIX_SITE_ID,
        },
        body: JSON.stringify({
          cart: {
            items: [{
              name: "RunSync Premium Monthly",
              quantity: 1,
              price: price,
              subscriptionInfo: {
                subscriptionSettings: {
                  frequency: "MONTH",
                },
                title: "RunSync Premium",
                description: "Full access to all RunSync features, billed monthly at £2.00/month",
              },
            }],
            customerInfo: {
              email: user.email,
            },
          },
          callbackUrls: {
            postFlowUrl: `${appUrl}/subscribe`,
            thankYouPageUrl: `${appUrl}/thank-you`,
          },
        }),
      });

      if (!checkoutRes.ok) {
        const errData = await checkoutRes.json().catch(() => ({}));
        console.error("Wix checkout error:", JSON.stringify(errData));
        return Response.json({ error: "Failed to create checkout session", details: errData }, { status: 400 });
      }

      const checkoutData = await checkoutRes.json();
      const checkoutSession = checkoutData.checkoutSession;

      // Update or create subscription record
      if (subs.length > 0) {
        await base44.asServiceRole.entities.Subscription.update(subs[0].id, {
          status: "pending",
          checkout_id: checkoutSession.id,
        });
      } else {
        const now = new Date();
        const trialEnd = new Date();
        trialEnd.setDate(trialEnd.getDate() + 14);
        await base44.asServiceRole.entities.Subscription.create({
          created_by_id: user.id,
          status: "pending",
          trial_start_date: now.toISOString(),
          trial_end_date: trialEnd.toISOString(),
          checkout_id: checkoutSession.id,
        });
      }

      return Response.json({ redirectUrl: checkoutSession.redirectUrl });
    }

    // Action: Cancel the user's subscription
    if (action === "cancelSubscription") {
      const user = await base44.auth.me();
      if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

      // Trusted backend write path: subscription records are admin-only via RLS,
// so all read/writes here go through the service role. The caller's identity
// comes from their authenticated session, never from request input.
const subs = await base44.asServiceRole.entities.Subscription.filter({ created_by_id: user.id });
      const sub = subs[0];
      if (!sub || !sub.subscription_id) {
        return Response.json({ error: "No active subscription to cancel" }, { status: 400 });
      }

      // Try soft cancellation first
      let cancelRes = await fetch(`${WIX_API_URL}/base44/v1/subscriptions/${sub.subscription_id}/cancel`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": WIX_API_KEY,
          "wix-site-id": WIX_SITE_ID,
        },
        body: JSON.stringify({
          subscription_id: sub.subscription_id,
          immediate: false,
        }),
      });

      // If soft cancel fails, try immediate
      if (!cancelRes.ok) {
        cancelRes = await fetch(`${WIX_API_URL}/base44/v1/subscriptions/${sub.subscription_id}/cancel`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": WIX_API_KEY,
            "wix-site-id": WIX_SITE_ID,
          },
          body: JSON.stringify({
            subscription_id: sub.subscription_id,
            immediate: true,
          }),
        });

        if (!cancelRes.ok) {
          const errData = await cancelRes.json().catch(() => ({}));
          console.error("Wix cancel error:", JSON.stringify(errData));
          return Response.json({ error: "Failed to cancel subscription", details: errData }, { status: 400 });
        }
      }

      await base44.asServiceRole.entities.Subscription.update(sub.id, {
        status: "canceled",
      });

      return Response.json({ success: true });
    }

    // Action: Get subscription status from Wix
    if (action === "getSubscriptionStatus") {
      const user = await base44.auth.me();
      if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

      // Trusted backend write path: subscription records are admin-only via RLS,
// so all read/writes here go through the service role. The caller's identity
// comes from their authenticated session, never from request input.
const subs = await base44.asServiceRole.entities.Subscription.filter({ created_by_id: user.id });
      const sub = subs[0];
      if (!sub || !sub.subscription_id) {
        return Response.json({ status: sub?.status || "none" });
      }

      const statusRes = await fetch(`${WIX_API_URL}/base44/v1/subscriptions/${sub.subscription_id}`, {
        method: "GET",
        headers: {
          "Authorization": WIX_API_KEY,
          "wix-site-id": WIX_SITE_ID,
        },
      });

      if (!statusRes.ok) {
        return Response.json({ status: sub.status });
      }

      const statusData = await statusRes.json();
      return Response.json({ status: statusData.subscription?.status || sub.status });
    }

    return Response.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    console.error("create-checkout error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});