import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { requirePremiumAccess, premiumRequiredResponse } from '../../shared/subscriptionAccess.js';

// Lightweight run list for the History screen: strips the heavy GPS route and
// AI track pool fields before sending anything to the client.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Premium gate: run history is a subscription-only feature — verified
    // server-side from the user's own Subscription records.
    if (!(await requirePremiumAccess(base44, user))) {
      console.log('run-summaries: premium required for user', user.id);
      return premiumRequiredResponse();
    }

    // Explicit owner scoping: never rely on RLS (the backend client bypasses it).
    const runs = await base44.asServiceRole.entities.LiveRun.filter(
      { created_by_id: user.id },
      { sort: '-created_date', limit: 50 }
    );

    return Response.json({
      runs: runs.map((r) => ({
        id: r.id,
        status: r.status,
        created_date: r.created_date,
        start_time: r.start_time,
        target_distance_km: r.target_distance_km,
        target_time_min: r.target_time_min,
        target_pace_per_km: r.target_pace_per_km,
        actual_distance_km: r.actual_distance_km,
        actual_time_min: r.actual_time_min,
        actual_pace_per_km: r.actual_pace_per_km,
        has_route: Array.isArray(r.route) && r.route.length >= 2,
      })),
    });
  } catch (error) {
    console.error('run-summaries error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}