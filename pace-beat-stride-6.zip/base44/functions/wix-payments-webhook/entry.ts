import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import jwt from 'npm:jsonwebtoken@9.0.2';

Deno.serve(async (req) => {
  try {
    const requestBody = await req.text();
    const publicKey = Deno.env.get("WIX_PAYMENTS_WEBHOOK_PUBLIC_KEY");
    if (!publicKey) {
      console.error("Missing WIX_PAYMENTS_WEBHOOK_PUBLIC_KEY");
      return Response.json({ error: "Missing webhook public key" }, { status: 500 });
    }

    // Step 1: Verify JWT signature - fail closed if verification fails
    let rawPayload;
    try {
      rawPayload = jwt.verify(requestBody, publicKey, { algorithms: ["RS256"] });
    } catch (err) {
      console.error("JWT verification failed:", err.message);
      return Response.json({ error: "Invalid signature" }, { status: 401 });
    }

    // Step 2: Parse double-nested JSON
    const event = JSON.parse(rawPayload.data);
    const eventData = JSON.parse(event.data);

    const base44 = createClientFromRequest(req);

    // Step 3: Route by event type
    if (event.eventType === "wix.ecom.v1.order_approved") {
      const order = eventData.actionEvent.body.order;
      const checkoutId = order.checkoutId;

      // Extract subscription ID from line items
      let subscriptionId = null;
      for (const lineItem of order.lineItems) {
        if (lineItem.subscriptionInfo) {
          subscriptionId = lineItem.subscriptionInfo.id;
          break;
        }
      }

      // Activation is idempotent: Wix redelivers events, sometimes
      // concurrently. Update ALL records matching this checkout so duplicate
      // rows stay consistent, and only ever after the verified event.
      const updateFields = { status: "active" };
      if (subscriptionId) updateFields.subscription_id = subscriptionId;
      await base44.asServiceRole.entities.Subscription.updateMany(
        { checkout_id: checkoutId },
        { $set: updateFields }
      );

      console.log(`Subscription activated for checkout_id: ${checkoutId} (subscription_id: ${subscriptionId})`);
    } else if (event.eventType === "wix.ecom.subscription_contracts.v1.subscription_contract_canceled") {
      const subscriptionContract = eventData.actionEvent.body.subscriptionContract;
      const subscriptionId = subscriptionContract.id;

      await base44.asServiceRole.entities.Subscription.updateMany(
        { subscription_id: subscriptionId },
        { $set: { status: "canceled" } }
      );
      console.log(`Subscription ${subscriptionId} canceled`);
    } else if (event.eventType === "wix.ecom.subscription_contracts.v1.subscription_contract_expired") {
      const subscriptionContract = eventData.actionEvent.body.subscriptionContract;
      const subscriptionId = subscriptionContract.id;

      await base44.asServiceRole.entities.Subscription.updateMany(
        { subscription_id: subscriptionId },
        { $set: { status: "expired" } }
      );
      console.log(`Subscription ${subscriptionId} expired`);
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error("Webhook handler error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});