import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { hasPriorTrial } from '../../shared/trialEligibility.js';

// Promo codes are validated server-side only. Codes are read from app secrets
// (PROMO_CODE_FREE / PROMO_CODE_TRIAL) so they never ship in the client bundle
// or in exported source; the previous values remain as fallbacks until the
// secrets are set, so existing legitimate codes keep working unchanged.
// Codes are matched case-insensitively.
const PROMO_CODES = {
  [Deno.env.get('PROMO_CODE_FREE') || 'Nelliemae123!']: { grant: 'free' }, // permanent free access
  [Deno.env.get('PROMO_CODE_TRIAL') || 'Trialmethis']: { grant: 'trial' }, // one free month
};

const TRIAL_DAYS = 30;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Authentication required to redeem a promo code' }, { status: 401 });
    }

    const body = await req.json();
    const code = (body?.code || '').trim();

    const match = Object.entries(PROMO_CODES).find(
      ([key, cfg]) => key.toLowerCase() === code.toLowerCase()
    );
    if (!match) {
      return Response.json({ error: 'Invalid promo code' }, { status: 400 });
    }
    const { grant } = match[1];

    // Fetch the caller's subscriptions BEFORE granting: eligibility comes
    // only from trusted server-side data, never from client-supplied flags.
    // Trusted backend write path: subscription records are admin-only via
    // RLS, so read/writes go through the service role. The caller's identity
    // comes from their authenticated session, never from request input.
    const subs = await base44.asServiceRole.entities.Subscription.filter({ created_by_id: user.id });

    // Trial guard: a trial already redeemed on this account can never be
    // extended. trial_start_date/trial_end_date persist even after the trial
    // converts to a paid subscription (the payments webhook only updates
    // status/subscription_id), so prior trials stay detectable. Repeated or
    // concurrent requests are rejected by this check.
    if (grant === 'trial' && hasPriorTrial(subs)) {
      return Response.json(
        { error: 'Trial code has already been redeemed for this account' },
        { status: 409 }
      );
    }

    let data;
    if (grant === 'trial') {
      const now = new Date();
      const end = new Date(now.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
      data = {
        status: 'trial',
        trial_start_date: now.toISOString(),
        trial_end_date: end.toISOString(),
      };
    } else {
      data = { status: 'free' };
    }

    // Grant on the caller's own subscription (service role, user-scoped by
    // the authenticated identity above).
    if (subs.length > 0) {
      await base44.asServiceRole.entities.Subscription.update(subs[0].id, data);
    } else {
      await base44.asServiceRole.entities.Subscription.create({
        ...data,
        created_by_id: user.id,
      });
    }

    return Response.json({ success: true, grant, ...data });
  } catch (error) {
    console.error('redeem-promo error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}