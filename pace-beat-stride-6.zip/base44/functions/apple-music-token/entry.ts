import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { secrets } from 'base44:runtime';
import { mintDeveloperToken } from '../../shared/appleMusicToken.js';
import { acquireMintSlot, confirmSlot } from '../../shared/rateLimit.js';

// Persistent per-user rate limit: 10 successful mints in any 15-minute
// window, enforced across invocations via RateLimitHit records
// (base44/shared/rateLimit.js — the cap converges under concurrency).

export default async function(req) {
  try {
    // Only authenticated app users may mint a developer token — the endpoint
    // is otherwise publicly reachable at its function URL.
    const base44 = createClientFromRequest(req);
    // auth.me() THROWS (rather than returning null) when the request has no
    // valid session — catch that and answer 401 instead of the outer 500.
    let user = null;
    try {
      user = await base44.auth.me();
    } catch {
      user = null;
    }
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const rateEntity = base44.asServiceRole.entities.RateLimitHit;
    const slot = await acquireMintSlot(rateEntity, user.id, 'apple_music_token', Date.now());
    if (!slot.allowed) {
      return Response.json({ error: 'Too many requests. Please try again later.' }, { status: 429 });
    }

    const privateKeyPem = secrets.get('APPLE_MUSIC_PRIVATE_KEY');
    const keyId = secrets.get('APPLE_MUSIC_KEY_ID');
    const teamId = secrets.get('APPLE_MUSIC_TEAM_ID');

    if (!privateKeyPem || !keyId || !teamId) {
      console.error('apple-music-token: Apple Music credentials not configured');
      return Response.json({ error: 'Apple Music credentials not configured' }, { status: 500 });
    }

    try {
      console.log('apple-music-token: minting for authenticated user', user.id);
      const { token, expiresIn } = await mintDeveloperToken({ privateKeyPem, keyId, teamId });
      // Record the successful mint only now — failed generation never counts.
      // Under concurrent requests the cap converges here: excess slots are
      // withdrawn and their callers get 429 instead of a token.
      const recorded = await confirmSlot(rateEntity, user.id, 'apple_music_token', slot.slot, Date.now());
      if (!recorded) {
        return Response.json({ error: 'Too many requests. Please try again later.' }, { status: 429 });
      }
      return Response.json({ developerToken: token, expiresIn });
    } catch (err) {
      // Never echo key material or crypto details back to the client.
      console.error('apple-music-token: key rejected:', err.message);
      return Response.json(
        { error: 'Apple Music credentials are not configured correctly. Please re-check the saved .p8 key, key id and team id.' },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('apple-music-token error:', error.message);
    return Response.json({ error: 'Unable to generate token' }, { status: 500 });
  }
}