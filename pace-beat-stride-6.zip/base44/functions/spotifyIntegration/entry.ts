import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { getSecret, upsertSecret, deleteSecret } from '../../shared/integrationSecrets.ts';
import { requirePremiumAccess, premiumRequiredResponse } from '../../shared/subscriptionAccess.js';

const SPOTIFY_AUTH_URL = 'https://accounts.spotify.com/authorize';
const SPOTIFY_TOKEN_URL = 'https://accounts.spotify.com/api/token';
const SPOTIFY_API_URL = 'https://api.spotify.com/v1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { action, code, redirectUri, playlist, tracks } = body;

    // Premium gate: these operations are only reachable from subscription-gated
    // UI (live-run track pool, plan export). Connection, profile, playlist
    // listing/reading and token actions stay open to free users.
    if (action === 'searchTracks' || action === 'searchAndExportPlaylist' || action === 'createPlaylist') {
      if (!(await requirePremiumAccess(base44, user))) {
        console.log('spotifyIntegration: premium required for action', action, 'user', user.id);
        return premiumRequiredResponse();
      }
    }

    const clientId = Deno.env.get('SPOTIFY_CLIENT_ID');
    const clientSecret = Deno.env.get('SPOTIFY_CLIENT_SECRET');

    if (!clientId || !clientSecret) {
      return Response.json({ error: 'Spotify credentials not configured' }, { status: 500 });
    }

    // Action: Get OAuth URL
    if (action === 'getAuthUrl') {
      const params = new URLSearchParams({
        client_id: clientId,
        response_type: 'code',
        redirect_uri: redirectUri,
        scope: 'playlist-modify-public playlist-modify-private playlist-read-private playlist-read-collaborative user-library-read user-top-read user-read-recently-played user-read-email user-read-private streaming user-modify-playback-state user-read-playback-state'
      });
      const authUrl = `${SPOTIFY_AUTH_URL}?${params.toString()}`;
      return Response.json({ authUrl });
    }

    // Action: Exchange code for access token (refresh token is stored server-side only)
    if (action === 'getAccessToken') {
      const tokenParams = new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: redirectUri,
        client_id: clientId,
        client_secret: clientSecret
      });

      const tokenResponse = await fetch(SPOTIFY_TOKEN_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: tokenParams.toString()
      });

      if (!tokenResponse.ok) {
        return Response.json({ error: 'Failed to exchange code for token' }, { status: 400 });
      }

      const tokenData = await tokenResponse.json();
      if (tokenData.refresh_token) {
        await upsertSecret(base44, user.id, 'spotify', tokenData.refresh_token);
      }
      return Response.json({
        accessToken: tokenData.access_token,
        expiresIn: tokenData.expires_in || 3600,
      });
    }

    // Action: Refresh the access token using the server-stored refresh token
    if (action === 'refreshAccessToken') {
      const secret = await getSecret(base44, user.id, 'spotify');
      if (!secret) {
        return Response.json({ error: 'Spotify not connected. Reconnect from the home page.' }, { status: 401 });
      }

      const refreshResponse = await fetch(SPOTIFY_TOKEN_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'refresh_token',
          refresh_token: secret.refresh_token,
          client_id: clientId,
          client_secret: clientSecret
        }).toString()
      });

      if (!refreshResponse.ok) {
        const errText = await refreshResponse.text();
        console.error('Spotify token refresh failed:', refreshResponse.status, errText);
        return Response.json({ error: 'Spotify session expired. Reconnect from the home page.' }, { status: 401 });
      }

      const refreshed = await refreshResponse.json();
      if (refreshed.refresh_token) {
        await upsertSecret(base44, user.id, 'spotify', refreshed.refresh_token);
      }
      return Response.json({
        accessToken: refreshed.access_token,
        expiresIn: refreshed.expires_in || 3600,
      });
    }

    // Action: Disconnect Spotify (delete the server-stored refresh token)
    if (action === 'disconnect') {
      await deleteSecret(base44, user.id, 'spotify');
      return Response.json({ success: true });
    }

    // Action: Get user profile + enriched data
    if (action === 'getProfile') {
      const { accessToken } = body;
      if (!accessToken) return Response.json({ error: 'Access token required' }, { status: 400 });

      const headers = { 'Authorization': `Bearer ${accessToken}` };

      const [profileRes, topTracksRes, topArtistsRes, recentRes] = await Promise.all([
        fetch(`${SPOTIFY_API_URL}/me`, { headers }),
        fetch(`${SPOTIFY_API_URL}/me/top/tracks?limit=5&time_range=short_term`, { headers }),
        fetch(`${SPOTIFY_API_URL}/me/top/artists?limit=5&time_range=short_term`, { headers }),
        fetch(`${SPOTIFY_API_URL}/me/player/recently-played?limit=5`, { headers }),
      ]);

      if (!profileRes.ok) return Response.json({ error: 'Failed to fetch profile' }, { status: 400 });

      const profile = await profileRes.json();
      const topTracks = topTracksRes.ok ? (await topTracksRes.json()).items || [] : [];
      const topArtists = topArtistsRes.ok ? (await topArtistsRes.json()).items || [] : [];
      const recentTracks = recentRes.ok ? (await recentRes.json()).items || [] : [];

      return Response.json({
        name: profile.display_name,
        email: profile.email,
        image: profile.images?.[0]?.url || null,
        followers: profile.followers?.total || 0,
        plan: profile.product,
        country: profile.country,
        spotifyUrl: profile.external_urls?.spotify,
        topTracks: topTracks.map(t => ({
          name: t.name,
          artist: t.artists?.[0]?.name,
          album: t.album?.name,
          image: t.album?.images?.[2]?.url || t.album?.images?.[0]?.url,
          preview_url: t.preview_url,
          spotifyUrl: t.external_urls?.spotify,
        })),
        topArtists: topArtists.map(a => ({
          name: a.name,
          image: a.images?.[2]?.url || a.images?.[0]?.url,
          genres: a.genres?.slice(0, 2),
          spotifyUrl: a.external_urls?.spotify,
        })),
        recentTracks: recentTracks.map(item => ({
          name: item.track?.name,
          artist: item.track?.artists?.[0]?.name,
          image: item.track?.album?.images?.[2]?.url || item.track?.album?.images?.[0]?.url,
          playedAt: item.played_at,
        })),
      });
    }

    // Action: Get user's playlists (list only, no tracks)
    if (action === 'getPlaylists') {
      const { accessToken } = body;
      if (!accessToken) return Response.json({ error: 'Access token required' }, { status: 400 });

      const headers = { 'Authorization': `Bearer ${accessToken}` };
      const playlistsRes = await fetch(`${SPOTIFY_API_URL}/me/playlists?limit=50`, { headers });
      if (!playlistsRes.ok) return Response.json({ error: 'Failed to fetch playlists' }, { status: 400 });
      const playlistsData = await playlistsRes.json();

      return Response.json({
        playlists: (playlistsData.items || []).map(p => ({
          id: p.id,
          name: p.name,
          image: p.images?.[0]?.url || null,
          track_count: p.tracks?.total || 0,
          owner: p.owner?.display_name || '',
        })),
      });
    }

    // Action: Search tracks on Spotify and export as a playlist
    if (action === 'searchAndExportPlaylist') {
      const { accessToken, planName, parkrunName: prName, targetTimeMin, tracklist } = body;
      if (!accessToken) return Response.json({ error: 'Access token required' }, { status: 400 });

      const headers = { 'Authorization': `Bearer ${accessToken}` };

      // Get user ID
      const profileRes = await fetch(`${SPOTIFY_API_URL}/me`, { headers });
      if (!profileRes.ok) return Response.json({ error: 'Failed to fetch Spotify profile' }, { status: 400 });
      const profile = await profileRes.json();
      const userId = profile.id;

      // Search for each track to get its Spotify URI
      const trackUris = [];
      for (const track of tracklist) {
        const q = encodeURIComponent(`track:${track.title} artist:${track.artist}`);
        const searchRes = await fetch(`${SPOTIFY_API_URL}/search?q=${q}&type=track&limit=1`, { headers });
        if (searchRes.ok) {
          const searchData = await searchRes.json();
          const found = searchData.tracks?.items?.[0];
          if (found) trackUris.push(found.uri);
        }
      }

      if (trackUris.length === 0) {
        return Response.json({ error: 'Could not find any tracks on Spotify' }, { status: 400 });
      }

      // Create the playlist
      const playlistRes = await fetch(`${SPOTIFY_API_URL}/users/${userId}/playlists`, {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: `PacePlay: ${prName} – ${targetTimeMin}min`,
          description: `BPM-matched running playlist for ${prName} parkrun. Target: ${targetTimeMin} mins. Generated by PacePlay.`,
          public: false
        })
      });
      if (!playlistRes.ok) return Response.json({ error: 'Failed to create Spotify playlist' }, { status: 400 });

      const playlistData = await playlistRes.json();

      // Add tracks in batches of 100
      for (let i = 0; i < trackUris.length; i += 100) {
        await fetch(`${SPOTIFY_API_URL}/playlists/${playlistData.id}/tracks`, {
          method: 'POST',
          headers: { ...headers, 'Content-Type': 'application/json' },
          body: JSON.stringify({ uris: trackUris.slice(i, i + 100) })
        });
      }

      return Response.json({
        success: true,
        playlistUrl: playlistData.external_urls.spotify,
        tracksAdded: trackUris.length,
        totalTracks: tracklist.length
      });
    }

    // Action: Create playlist with tracks
    if (action === 'createPlaylist' && playlist && tracks) {
      const { accessToken } = body;

      if (!accessToken) {
        return Response.json({ error: 'Access token required' }, { status: 400 });
      }

      // Get user profile
      const profileRes = await fetch(`${SPOTIFY_API_URL}/me`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });

      if (!profileRes.ok) {
        return Response.json({ error: 'Failed to fetch user profile' }, { status: 400 });
      }

      const profile = await profileRes.json();
      const userId = profile.id;

      // Create playlist
      const playlistRes = await fetch(`${SPOTIFY_API_URL}/users/${userId}/playlists`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: playlist.name,
          description: playlist.description || 'Created by PacePlay',
          public: false
        })
      });

      if (!playlistRes.ok) {
        return Response.json({ error: 'Failed to create playlist' }, { status: 400 });
      }

      const playlistData = await playlistRes.json();
      const playlistId = playlistData.id;

      // Add tracks to playlist (in batches of 100)
      const trackUris = tracks.filter(t => t.spotify_uri).map(t => t.spotify_uri);
      const batches = [];
      for (let i = 0; i < trackUris.length; i += 100) {
        batches.push(trackUris.slice(i, i + 100));
      }

      for (const batch of batches) {
        const addRes = await fetch(`${SPOTIFY_API_URL}/playlists/${playlistId}/tracks`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ uris: batch })
        });

        if (!addRes.ok) {
          console.warn('Failed to add some tracks to playlist');
        }
      }

      return Response.json({
        success: true,
        playlistId,
        playlistUrl: playlistData.external_urls.spotify,
        tracksAdded: trackUris.length
      });
    }

    // Action: Search tracks to get Spotify URIs
    if (action === 'searchTracks') {
      const { accessToken, tracks } = body;
      if (!accessToken) return Response.json({ error: 'Access token required' }, { status: 400 });

      const headers = { 'Authorization': `Bearer ${accessToken}` };
      const results = [];

      for (const track of tracks) {
        const q = encodeURIComponent(`track:${track.title} artist:${track.artist}`);
        const searchRes = await fetch(`${SPOTIFY_API_URL}/search?q=${q}&type=track&limit=1`, { headers });
        let found = null;
        if (searchRes.ok) {
          const searchData = await searchRes.json();
          found = searchData.tracks?.items?.[0] || null;
        }
        // Relaxed fallback: exact field queries often miss AI-suggested
        // titles/artists — a plain text search still finds the right song.
        if (!found) {
          const fallbackRes = await fetch(
            `${SPOTIFY_API_URL}/search?q=${encodeURIComponent(`${track.title} ${track.artist}`)}&type=track&limit=1`,
            { headers }
          );
          if (fallbackRes.ok) {
            const fallbackData = await fallbackRes.json();
            found = fallbackData.tracks?.items?.[0] || null;
          }
        }
        if (found) {
          results.push({
            title: track.title,
            artist: track.artist,
            uri: found.uri,
            duration_ms: found.duration_ms,
          });
        }
      }

      return Response.json({ results });
    }

    // Action: Get user's playlist tracks for personalisation
    if (action === 'getPlaylistTracks') {
      const { accessToken } = body;
      if (!accessToken) return Response.json({ error: 'Access token required' }, { status: 400 });

      const headers = { 'Authorization': `Bearer ${accessToken}` };

      const { playlistIds } = body;

      // Fetch user's playlists
      const playlistsRes = await fetch(`${SPOTIFY_API_URL}/me/playlists?limit=50`, { headers });
      if (!playlistsRes.ok) return Response.json({ error: 'Failed to fetch playlists' }, { status: 400 });
      const playlistsData = await playlistsRes.json();

      // Fetch selected playlists (priority) plus other playlists for broad coverage
      let playlistsToFetch = playlistsData.items || [];
      if (playlistIds && playlistIds.length > 0) {
        const selected = playlistsToFetch.filter(p => playlistIds.includes(p.id));
        const others = playlistsToFetch.filter(p => !playlistIds.includes(p.id)).slice(0, 8);
        playlistsToFetch = [...selected, ...others];
      } else {
        playlistsToFetch = playlistsToFetch.slice(0, 10);
      }
      const selectedSet = new Set(playlistIds || []);

      const allTracks = [];
      const seen = new Set();

      // Fetch tracks from selected playlists (up to 10)
      for (const playlist of playlistsToFetch.slice(0, 10)) {
        const tracksRes = await fetch(`${SPOTIFY_API_URL}/playlists/${playlist.id}/tracks?limit=50&fields=items(track(name,artists(name),album(name),duration_ms,uri))`, { headers });
        if (!tracksRes.ok) continue;
        const tracksData = await tracksRes.json();

        for (const item of (tracksData.items || [])) {
          const track = item.track;
          if (!track?.uri || track.uri.includes('local')) continue;
          const key = track.uri;
          if (seen.has(key)) continue;
          seen.add(key);
          allTracks.push({
            title: track.name,
            artist: track.artists?.[0]?.name,
            album: track.album?.name,
            duration_ms: track.duration_ms,
            uri: track.uri,
            source_playlist: playlist.name,
            is_selected: selectedSet.has(playlist.id),
          });
        }
      }

      // Deduplicate by title+artist, keep first occurrence with URI
      const unique = [];
      const dedup = new Set();
      for (const t of allTracks) {
        const k = `${t.title}|${t.artist}`.toLowerCase();
        if (!dedup.has(k)) {
          dedup.add(k);
          unique.push(t);
        }
      }

      return Response.json({
        playlistCount: (playlistsData.items || []).length,
        tracks: unique.slice(0, 100),
      });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});